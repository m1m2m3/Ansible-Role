/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


#ifndef __TWNOTIFY_HANDLERS_H__
#define __TWNOTIFY_HANDLERS_H__


// user poitner type
#define USERPTR __user

#ifdef __powerpc64__
// These definitions are missing on PPC64 for some reason, so we just define them here
typedef __kernel_uid_t old_uid_t;
typedef __kernel_gid_t old_gid_t;

struct fdesc
{
    void * pFunc;
    void * pToc;
};

// Special PPC helper functions:
noinline unsigned long getR2( void );
noinline void setR2( unsigned long val );
noinline unsigned long  getTextAddr( void );

noinline int check_kernel_r2( unsigned long kernel_r2 );

// gloabal for saved kernel R2 value during init() call
extern unsigned long saved_kernel_r2;

#endif

// Debug helper memory dump routine
void dumpAddress( void** ptr );


#ifdef CONFIG_64BIT

// 64-bit only handlers (Intel and PPC - 32-bit compatibility handlers)
asmlinkage long twnotify32_sys_open( const char USERPTR *filename, int flags, int mode);
asmlinkage long twnotify32_sys_openat( unsigned int dfd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify32_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39
asmlinkage long twnotify32_sys_pwrite64( unsigned int fd, char USERPTR *ubuf, u32 count, u32 poslo, u32 poshi);
asmlinkage long twnotify32_sys_writev( unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen);
#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify32_sys_pwritev( unsigned long fd, const struct compat_iovec __user *vec, unsigned long vlen, u32 pos_low, u32 pos_high);
#endif
asmlinkage long twnotify32_sys_chown(const char USERPTR * filename, old_uid_t user, old_gid_t group);
asmlinkage long twnotify32_sys_chown32(const char USERPTR *filename, uid_t user, gid_t group);
asmlinkage long twnotify32_sys_fchown(unsigned int fd, old_uid_t user, old_gid_t group);
asmlinkage long twnotify32_sys_fchown32(unsigned int fd, uid_t user, gid_t group);
asmlinkage long twnotify32_sys_lchown(const char USERPTR * filename, old_uid_t user, old_gid_t group);
asmlinkage long twnotify32_sys_lchown32(const char USERPTR *filename, uid_t user, gid_t group);
asmlinkage long twnotify32_sys_utime(char USERPTR *filename, struct compat_utimbuf USERPTR *t);
asmlinkage long twnotify32_sys_utimes(char USERPTR *filename, struct compat_timeval USERPTR *t);
asmlinkage long twnotify32_sys_futimesat(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long twnotify32_sys_utimensat(int dfd, char USERPTR *filename, struct compat_timespec USERPTR *utimes, int flags);
#endif
asmlinkage long twnotify32_sys_truncate64(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high);
asmlinkage long twnotify32_sys_ftruncate64(unsigned int fd, unsigned long offset_low, unsigned long offset_high);
asmlinkage long twnotify32_sys_mount(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type, unsigned long flags, void USERPTR * data);
asmlinkage long twnotify32_sys_umount(char USERPTR * name);
asmlinkage long twnotify32_sys_umount2(char USERPTR * name, int flags);

#endif // CONFIG_64BIT


// our handlers for 32 and 64 bit (Intel and PPC):
asmlinkage long twnotify_sys_creat( const char USERPTR *filename, int mode);
asmlinkage long twnotify_sys_mkdir( const char USERPTR *pathname, int mode);
asmlinkage long twnotify_sys_mkdirat( int dfd, const char USERPTR *pathname, int mode);
asmlinkage long twnotify_sys_mknod( const char USERPTR *pathname, int mode, int dev);
asmlinkage long twnotify_sys_mknodat( int dfd, const char USERPTR *pathname, int mode, int dev);
asmlinkage long twnotify_sys_open( const char USERPTR *filename, int flags, int mode);
asmlinkage long twnotify_sys_openat( int dfd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify_sys_open_by_handle_at( int mount_fd, struct file_handle *handle, int flags );
#endif // KERNEL_GT_2_6_39
asmlinkage long twnotify_sys_link( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify_sys_linkat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags);
asmlinkage long twnotify_sys_symlink( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify_sys_symlinkat( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
asmlinkage long twnotify_sys_rmdir( const char USERPTR *pathname);
asmlinkage long twnotify_sys_unlink( const char USERPTR *pathname);
asmlinkage long twnotify_sys_unlinkat( int dfd, const char USERPTR * pathname, int flags);
asmlinkage long twnotify_sys_rename( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify_sys_renameat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
asmlinkage ssize_t twnotify_sys_pwrite64(int fd, const void USERPTR *buf, size_t count, loff_t offset);
asmlinkage ssize_t twnotify_sys_write(int fd, const void *buf, size_t count);
asmlinkage ssize_t twnotify_sys_writev(long fd, const struct iovec USERPTR * iov, long iovcnt);
#ifdef KERNEL_GT_2_6_17
asmlinkage long twnotify_sys_splice(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);
#endif
#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify_sys_pwritev(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h);
#endif
asmlinkage long twnotify_sys_chmod( const char USERPTR *filename, mode_t mode);
asmlinkage long twnotify_sys_fchmod( int fd, mode_t mode);
asmlinkage long twnotify_sys_fchmodat( int dfd, const char USERPTR *pathname, mode_t mode, int flags);
asmlinkage long twnotify_sys_chown( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_sys_chown32( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_sys_fchown( int fd, int owner, int group);
asmlinkage long twnotify_sys_fchown32( int fd, int owner, int group);
asmlinkage long twnotify_sys_fchownat( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
asmlinkage long twnotify_sys_lchown( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_sys_lchown32( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_sys_futimesat( int dfd, const char USERPTR *pathname, const struct timeval times[2]);
asmlinkage long twnotify_sys_utime(const char USERPTR *filename, const struct utimbuf USERPTR *buf);
asmlinkage long twnotify_sys_utimes(const char USERPTR *filename, const struct timeval times[2]);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long twnotify_sys_utimensat(int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags);
#endif
asmlinkage long twnotify_sys_fremovexattr( int fd, const char USERPTR *name);
asmlinkage long twnotify_sys_fsetxattr(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify_sys_lremovexattr(const char USERPTR *path, const char USERPTR *name);
asmlinkage long twnotify_sys_lsetxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify_sys_removexattr(const char USERPTR *path, const char USERPTR *name);
asmlinkage long twnotify_sys_setxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify_sys_ftruncate( int fd, unsigned long length);
asmlinkage long twnotify_sys_ftruncate64( int fd, loff_t length);
asmlinkage long twnotify_sys_truncate( const char USERPTR *path, unsigned long length);
asmlinkage long twnotify_sys_truncate64( const char USERPTR *path, loff_t length);
asmlinkage long twnotify_sys_mount( const char USERPTR *source, const char USERPTR *target,
                                    const char USERPTR *filesystemtype,
                                    unsigned long mountflags, const void USERPTR *data);
asmlinkage long twnotify_sys_umount(const char USERPTR *target);
asmlinkage long twnotify_sys_umount2(const char USERPTR *target, int flags);

// Close hooked for housekeeping
asmlinkage long twnotify_sys_close(unsigned int fd);


#ifdef __powerpc64__

// On PPC we have to do this odd double-call thing in order to implement the workaround for
//   dealing with the function descriptors, r2 TOC register and syscall calling convention.
//   This results in a new stub function for each handler and each bitness.  These stubs will
//   be the first thing that the kernel calls from the syscall table fro each entry we hook.  They
//   do the special PPC stuff then call the coded hander twnotify_sys_xxx or twnotify32_sys_xxxx

// the 64 bit table entry handlers
asmlinkage long twnotify_ppc_sys_creat( const char USERPTR *filename, int mode);
asmlinkage long twnotify_ppc_sys_open( const char USERPTR *filename, int flags, int mode);
asmlinkage long twnotify_ppc_sys_openat( int dfd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify_ppc_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39
asmlinkage long twnotify_ppc_sys_mkdir( const char USERPTR *pathname, int mode);
asmlinkage long twnotify_ppc_sys_mkdirat( int dfd, const char USERPTR *pathname, int mode);
asmlinkage long twnotify_ppc_sys_mknod( const char USERPTR *pathname, int mode, int dev);
asmlinkage long twnotify_ppc_sys_mknodat( int dfd, const char USERPTR *pathname, int mode, int dev);
asmlinkage long twnotify_ppc_sys_link( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify_ppc_sys_linkat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags);
asmlinkage long twnotify_ppc_sys_symlink( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify_ppc_sys_symlinkat( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
asmlinkage long twnotify_ppc_sys_rmdir( const char USERPTR *pathname);
asmlinkage long twnotify_ppc_sys_unlink( const char USERPTR *pathname);
asmlinkage long twnotify_ppc_sys_unlinkat( int dfd, const char USERPTR * pathname, int flags);
asmlinkage long twnotify_ppc_sys_rename( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify_ppc_sys_renameat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
asmlinkage ssize_t twnotify_ppc_sys_pwrite64(int fd, const void USERPTR *buf, size_t count, loff_t offset);
asmlinkage ssize_t twnotify_ppc_sys_write(int fd, const void *buf, size_t count);
asmlinkage ssize_t twnotify_ppc_sys_writev(long fd, const struct iovec USERPTR * iov, long iovcnt);
#ifdef KERNEL_GT_2_6_17
asmlinkage long twnotify_ppc_sys_splice(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);
#endif
#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify_ppc_sys_pwritev(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h);
#endif
asmlinkage long twnotify_ppc_sys_truncate( const char USERPTR *path, unsigned long length);
asmlinkage long twnotify_ppc_sys_truncate64( const char USERPTR *path, loff_t length);
asmlinkage long twnotify_ppc_sys_ftruncate( int fd, unsigned long length);
asmlinkage long twnotify_ppc_sys_ftruncate64( int fd, loff_t length);
asmlinkage long twnotify_ppc_sys_chmod( const char USERPTR *filename, mode_t mode);
asmlinkage long twnotify_ppc_sys_fchmod( int fd, mode_t mode);
asmlinkage long twnotify_ppc_sys_fchmodat( int dfd, const char USERPTR *pathname, mode_t mode, int flags);
asmlinkage long twnotify_ppc_sys_chown( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_ppc_sys_chown32( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_ppc_sys_fchown( int fd, int owner, int group);
asmlinkage long twnotify_ppc_sys_fchown32( int fd, int owner, int group);
asmlinkage long twnotify_ppc_sys_fchownat( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
asmlinkage long twnotify_ppc_sys_lchown( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_ppc_sys_lchown32( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify_ppc_sys_utime(const char USERPTR *filename, const struct utimbuf USERPTR *buf);
asmlinkage long twnotify_ppc_sys_utimes(const char USERPTR *filename, const struct timeval times[2]);
asmlinkage long twnotify_ppc_sys_futimesat( int dfd, const char USERPTR *pathname, const struct timeval times[2]);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long twnotify_ppc_sys_utimensat(int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags);
#endif
asmlinkage long twnotify_ppc_sys_fremovexattr( int fd, const char USERPTR *name);
asmlinkage long twnotify_ppc_sys_fsetxattr(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify_ppc_sys_lremovexattr(const char USERPTR *path, const char USERPTR *name);
asmlinkage long twnotify_ppc_sys_lsetxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify_ppc_sys_removexattr(const char USERPTR *path, const char USERPTR *name);
asmlinkage long twnotify_ppc_sys_setxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify_ppc_sys_mount( const char USERPTR *source, const char USERPTR *target,
                                    const char USERPTR *filesystemtype,
                                    unsigned long mountflags, const void USERPTR *data);
asmlinkage long twnotify_ppc_sys_umount(const char USERPTR *target);
asmlinkage long twnotify_ppc_sys_umount2(const char USERPTR *target, int flags);
asmlinkage long twnotify_ppc_sys_close(unsigned int fd);

// and the 32-bit ones....
asmlinkage long twnotify32_ppc_sys_creat( const char USERPTR *filename, int mode);
asmlinkage long twnotify32_ppc_sys_open( const char USERPTR *filename, int flags, int mode);
asmlinkage long twnotify32_ppc_sys_openat( unsigned int dfd, const char USERPTR *filename, int flags, int mode); // note unsigned fd
#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify32_ppc_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39
asmlinkage long twnotify32_ppc_sys_mkdir( const char USERPTR *pathname, int mode);
asmlinkage long twnotify32_ppc_sys_mkdirat( int dfd, const char USERPTR *pathname, int mode);
asmlinkage long twnotify32_ppc_sys_mknod( const char USERPTR *pathname, int mode, int dev);
asmlinkage long twnotify32_ppc_sys_mknodat( int dfd, const char USERPTR *pathname, int mode, int dev);
asmlinkage long twnotify32_ppc_sys_link( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify32_ppc_sys_linkat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags);
asmlinkage long twnotify32_ppc_sys_symlink( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify32_ppc_sys_symlinkat( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
asmlinkage long twnotify32_ppc_sys_rmdir( const char USERPTR *pathname);
asmlinkage long twnotify32_ppc_sys_unlink( const char USERPTR *pathname);
asmlinkage long twnotify32_ppc_sys_unlinkat( int dfd, const char USERPTR * pathname, int flags);
asmlinkage long twnotify32_ppc_sys_rename( const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long twnotify32_ppc_sys_renameat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
asmlinkage ssize_t twnotify32_ppc_sys_pwrite64(int fd, void USERPTR *buf, u32 count, u32 poslo, u32 poshi);  // size_t count, loff_t offset);
asmlinkage ssize_t twnotify32_ppc_sys_write(int fd, const void *buf, size_t count);
asmlinkage ssize_t twnotify32_ppc_sys_writev( unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen); //(long fd, const struct iovec USERPTR * iov, long iovcnt);
#ifdef KERNEL_GT_2_6_17
asmlinkage long twnotify32_ppc_sys_splice(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);
#endif
#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify32_ppc_sys_pwritev(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h);
#endif
asmlinkage long twnotify32_ppc_sys_truncate( const char USERPTR *path, unsigned long length);
asmlinkage long twnotify32_ppc_sys_truncate64(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high); //( const char USERPTR *path, loff_t length);
asmlinkage long twnotify32_ppc_sys_ftruncate( int fd, unsigned long length);
asmlinkage long twnotify32_ppc_sys_ftruncate64(unsigned int fd, unsigned long offset_low, unsigned long offset_high); // ( int fd, loff_t length);
asmlinkage long twnotify32_ppc_sys_chmod( const char USERPTR *filename, mode_t mode);
asmlinkage long twnotify32_ppc_sys_fchmod( int fd, mode_t mode);
asmlinkage long twnotify32_ppc_sys_fchmodat( int dfd, const char USERPTR *pathname, mode_t mode, int flags);
asmlinkage long twnotify32_ppc_sys_chown(const char USERPTR * filename, old_uid_t user, old_gid_t group); // ( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify32_ppc_sys_chown32( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify32_ppc_sys_fchown(unsigned int fd, old_uid_t user, old_gid_t group); // ( int fd, int owner, int group);
asmlinkage long twnotify32_ppc_sys_fchown32( int fd, uid_t owner, gid_t group);
asmlinkage long twnotify32_ppc_sys_fchownat( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
asmlinkage long twnotify32_ppc_sys_lchown( const char USERPTR *path, old_uid_t owner, old_gid_t group);
asmlinkage long twnotify32_ppc_sys_lchown32( const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long twnotify32_ppc_sys_utime( char USERPTR *filename, struct compat_utimbuf USERPTR *buf);
asmlinkage long twnotify32_ppc_sys_utimes( char USERPTR *filename, struct compat_timeval USERPTR *t);
asmlinkage long twnotify32_ppc_sys_futimesat(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t); //( int dfd, const char USERPTR *pathname, const struct timeval times[2]);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long twnotify32_ppc_sys_utimensat(int dfd, char USERPTR *filename, struct compat_timespec USERPTR *utimes, int flags);
#endif
asmlinkage long twnotify32_ppc_sys_fremovexattr( int fd, const char USERPTR *name);
asmlinkage long twnotify32_ppc_sys_fsetxattr(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify32_ppc_sys_lremovexattr(const char USERPTR *path, const char USERPTR *name);
asmlinkage long twnotify32_ppc_sys_lsetxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify32_ppc_sys_removexattr(const char USERPTR *path, const char USERPTR *name);
asmlinkage long twnotify32_ppc_sys_setxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long twnotify32_ppc_sys_mount(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type, unsigned long flags, void USERPTR * data); // ( const char USERPTR *source, const char USERPTR *target, const char USERPTR *filesystemtype, unsigned long mountflags, const void USERPTR *data);
asmlinkage long twnotify32_ppc_sys_umount(char USERPTR *target);
asmlinkage long twnotify32_ppc_sys_umount2( char USERPTR *target, int flags);
asmlinkage long twnotify32_ppc_sys_close(unsigned int fd);


// These are special function pointer types used to call the original handlers
//   from the syscall table with the correct argument list loaded into the registers

typedef long (*creat_ptr)( const char USERPTR *filename, int mode);
typedef long (*open_ptr)( const char USERPTR *filename, int flags, int mode);
typedef long (*openat_ptr)( int dfd, const char USERPTR *filename, int flags, int mode);
typedef long (*open_by_handle_at_ptr)(int mount_fd, struct file_handle *handle, int flags);
typedef long (*mkdir_ptr)( const char USERPTR *pathname, int mode);
typedef long (*mkdirat_ptr)( int dfd, const char USERPTR *pathname, int mode);
typedef long (*mknod_ptr)( const char USERPTR *pathname, int mode, int dev);
typedef long (*mknodat_ptr)( int dfd, const char USERPTR *pathname, int mode, int dev);
typedef long (*link_ptr)( const char USERPTR *oldpath, const char USERPTR *newpath);
typedef long (*linkat_ptr)( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags);
typedef long (*symlink_ptr)( const char USERPTR *oldpath, const char USERPTR *newpath);
typedef long (*symlinkat_ptr)( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
typedef long (*rmdir_ptr)( const char USERPTR *pathname);
typedef long (*unlink_ptr)( const char USERPTR *pathname);
typedef long (*unlinkat_ptr)( int dfd, const char USERPTR * pathname, int flags);
typedef long (*rename_ptr)( const char USERPTR *oldpath, const char USERPTR *newpath);
typedef long (*renameat_ptr)( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
typedef ssize_t (*pwrite64_ptr)(int fd, const void USERPTR *buf, size_t count, loff_t offset);
typedef ssize_t (*write_ptr)(int fd, const void *buf, size_t count);
typedef ssize_t (*writev_ptr)(long fd, const struct iovec USERPTR * iov, long iovcnt);
typedef long (*truncate_ptr)( const char USERPTR *path, unsigned long length);
typedef long (*truncate64_ptr)( const char USERPTR *path, loff_t length);
typedef long (*ftruncate_ptr)( int fd, unsigned long length);
typedef long (*ftruncate64_ptr)( int fd, loff_t length);
typedef long (*chmod_ptr)( const char USERPTR *filename, mode_t mode);
typedef long (*fchmod_ptr)( int fd, mode_t mode);
typedef long (*fchmodat_ptr)( int dfd, const char USERPTR *pathname, mode_t mode, int flags);
typedef long (*chown_ptr)( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*chown32_ptr)( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*fchown_ptr)( int fd, int owner, int group);
typedef long (*fchown32_ptr)( int fd, int owner, int group);
typedef long (*fchownat_ptr)( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
typedef long (*lchown_ptr)( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*lchown32_ptr)( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*utime_ptr)(const char USERPTR *filename, const struct utimbuf USERPTR *buf);
typedef long (*utimes_ptr)(const char USERPTR *filename, const struct timeval times[2]);
typedef long (*futimesat_ptr)( int dfd, const char USERPTR *pathname, const struct timeval times[2]);
typedef long (*utimensat_ptr)( int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags);
typedef long (*fremovexattr_ptr)( int fd, const char USERPTR *name);
typedef long (*fsetxattr_ptr)(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
typedef long (*lremovexattr_ptr)(const char USERPTR *path, const char USERPTR *name);
typedef long (*lsetxattr_ptr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
typedef long (*removexattr_ptr)(const char USERPTR *path, const char USERPTR *name);
typedef long (*setxattr_ptr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
typedef long (*mount_ptr)( const char USERPTR *source, const char USERPTR *target, const char USERPTR *filesystemtype, unsigned long mountflags, const void USERPTR *data);
typedef long (*umount_ptr)(const char USERPTR *target);
typedef long (*umount2_ptr)(const char USERPTR *target, int flags);
typedef long (*close_ptr)(unsigned int fd);
typedef long (*creat_ptr_32)( const char USERPTR *filename, int mode);
typedef long (*open_ptr_32)( const char USERPTR *filename, int flags, int mode);
typedef long (*openat_ptr_32)( unsigned int dfd, const char USERPTR *filename, int flags, int mode); // note unsigned fd
typedef long (*open_by_handle_at_ptr_32)( int mount_fd, struct file_handle *handle, int flags );
typedef long (*mkdir_ptr_32)( const char USERPTR *pathname, int mode);
typedef long (*mkdirat_ptr_32)( int dfd, const char USERPTR *pathname, int mode);
typedef long (*mknod_ptr_32)( const char USERPTR *pathname, int mode, int dev);
typedef long (*mknodat_ptr_32)( int dfd, const char USERPTR *pathname, int mode, int dev);
typedef long (*link_ptr_32)( const char USERPTR *oldpath, const char USERPTR *newpath);
typedef long (*linkat_ptr_32)( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags);
typedef long (*symlink_ptr_32)( const char USERPTR *oldpath, const char USERPTR *newpath);
typedef long (*symlinkat_ptr_32)( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
typedef long (*rmdir_ptr_32)( const char USERPTR *pathname);
typedef long (*unlink_ptr_32)( const char USERPTR *pathname);
typedef long (*unlinkat_ptr_32)( int dfd, const char USERPTR * pathname, int flags);
typedef long (*rename_ptr_32)( const char USERPTR *oldpath, const char USERPTR *newpath);
typedef long (*renameat_ptr_32)( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath);
typedef ssize_t (*pwrite64_ptr_32)(int fd, const void USERPTR *buf, u32 count, u32 poslo, u32 poshi);  // size_t count, loff_t offset);
typedef ssize_t (*write_ptr_32)(int fd, const void *buf, size_t count);
typedef ssize_t (*writev_ptr_32)( unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen); //(long fd, const struct iovec USERPTR * iov, long iovcnt);
typedef long (*splice_ptr)(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);
typedef long (*pwritev_ptr)(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h);

typedef long (*truncate_ptr_32)( const char USERPTR *path, unsigned long length);
typedef long (*truncate64_ptr_32)(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high); //( const char USERPTR *path, loff_t length);
typedef long (*ftruncate_ptr_32)( int fd, unsigned long length);
typedef long (*ftruncate64_ptr_32)(unsigned int fd, unsigned long offset_low, unsigned long offset_high); // ( int fd, loff_t length);
typedef long (*chmod_ptr_32)( const char USERPTR *filename, mode_t mode);
typedef long (*fchmod_ptr_32)( int fd, mode_t mode);
typedef long (*fchmodat_ptr_32)( int dfd, const char USERPTR *pathname, mode_t mode, int flags);
typedef long (*chown_ptr_32)(const char USERPTR * filename, old_uid_t user, old_gid_t group); // ( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*chown32_ptr_32)( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*fchown_ptr_32)(unsigned int fd, old_uid_t user, old_gid_t group); // ( int fd, int owner, int group);
typedef long (*fchown32_ptr_32)( int fd, uid_t owner, gid_t group);
typedef long (*fchownat_ptr_32)( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
typedef long (*lchown_ptr_32)( const char USERPTR *path, old_uid_t owner, old_gid_t group);
typedef long (*lchown32_ptr_32)( const char USERPTR *path, uid_t owner, gid_t group);
typedef long (*utime_ptr_32)(const char USERPTR *filename, const struct compat_utimbuf USERPTR *buf);
typedef long (*utimes_ptr_32)(const char USERPTR *filename, struct compat_timeval USERPTR *t);
typedef long (*futimesat_ptr_32)(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t); //( int dfd, const char USERPTR *pathname, const struct timeval times[2]);
typedef long (*utimensat_ptr_32)( int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags);
typedef long (*fremovexattr_ptr_32)( int fd, const char USERPTR *name);
typedef long (*fsetxattr_ptr_32)(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
typedef long (*lremovexattr_ptr_32)(const char USERPTR *path, const char USERPTR *name);
typedef long (*lsetxattr_ptr_32)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
typedef long (*removexattr_ptr_32)(const char USERPTR *path, const char USERPTR *name);
typedef long (*setxattr_ptr_32)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
typedef long (*mount_ptr_32)(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type, unsigned long flags, void USERPTR * data); // ( const char USERPTR *source, const char USERPTR *target, const char USERPTR *filesystemtype, unsigned long mountflags, const void USERPTR *data);
typedef long (*umount_ptr_32)(const char USERPTR *target);
typedef long (*umount2_ptr_32)(const char USERPTR *target, int flags);
typedef long (*close_ptr_32)(unsigned int fd);


#endif // _powerpc64__


// ***************************************************************************
// function pointers for original values in syscalltable - filled in when we hook:
// this is the list of native functions
// note: some of these are not used in the 64b syscall table

// These are declared in this header to keep maintenance simple.

// TWNOTIFY_CREAT
extern asmlinkage long (*original_sys_creat)(const char USERPTR *filename, int mode);
extern asmlinkage long (*original_sys_mkdir)(const char USERPTR *pathname, int mode);
extern asmlinkage long (*original_sys_mkdirat)(int dirfd, const char USERPTR *pathname, int mode);
extern asmlinkage long (*original_sys_mknod)(const char USERPTR *pathname, int mode, int dev);
extern asmlinkage long (*original_sys_mknodat)(int dirfd, const char USERPTR *pathname, int mode, int dev);
extern asmlinkage long (*original_sys_open)(const char USERPTR *filename, int flags, int mode);
extern asmlinkage long (*original_sys_openat)(int fd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
extern asmlinkage long (*original_sys_open_by_handle_at)(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39


// TWNOTIFY_LINK
extern asmlinkage long (*original_sys_link)(const char USERPTR *oldpath, const char USERPTR *newpath);
extern asmlinkage long (*original_sys_linkat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath, int flags);
extern asmlinkage long (*original_sys_symlink)(const char USERPTR *oldpath, const char USERPTR *newpath);
extern asmlinkage long (*original_sys_symlinkat)(const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_DELETE
extern asmlinkage long (*original_sys_rmdir)(const char USERPTR *pathname);
extern asmlinkage long (*original_sys_unlink)(const char USERPTR *pathname);
extern asmlinkage long (*original_sys_unlinkat)(int dirfd, const char USERPTR * pathname, int flags);

// TWNOTIFY_RENAME
extern asmlinkage long (*original_sys_rename)(const char USERPTR *oldpath, const char USERPTR *newpath);
extern asmlinkage long (*original_sys_renameat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_WRITE
// - 2.2 and 2.4 kernel only: extern asmlinkage long (*original_sys_pwrite)(int fd, const void USERPTR *buf, int count, int offset);
extern asmlinkage ssize_t (*original_sys_pwrite64)(int fd, const void USERPTR *buf, size_t count, loff_t offset);
extern asmlinkage ssize_t (*original_sys_write)(int fd, const void USERPTR *buf, size_t count);
extern asmlinkage ssize_t (*original_sys_writev)(long fd, const struct iovec USERPTR * iov, long iovcnt);
extern asmlinkage long (*original_sys_splice)(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);
extern asmlinkage long (*original_sys_pwritev)(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h);

// TWNOTIFY_CHMOD
extern asmlinkage long (*original_sys_chmod)( const char USERPTR *path, mode_t mode);
extern asmlinkage long (*original_sys_fchmod)(int fd, mode_t mode);
extern asmlinkage long (*original_sys_fchmodat)(int dirfd, const char USERPTR *pathname, mode_t mode, int flags);

// TWNOTIFY_CHOWN
extern asmlinkage long (*original_sys_chown)( const char USERPTR *path, int owner, int group);
extern asmlinkage long (*original_sys_chown32)( const char USERPTR *path, int owner, int group);
extern asmlinkage long (*original_sys_fchown)(int fd, int owner, int group);
extern asmlinkage long (*original_sys_fchown32)(int fd, int owner, int group);
extern asmlinkage long (*original_sys_fchownat)(int dirfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
extern asmlinkage long (*original_sys_lchown)(const char USERPTR *path, uid_t owner, gid_t group);
extern asmlinkage long (*original_sys_lchown32)(const char USERPTR *path, uid_t owner, gid_t group);

// TWNOTIFY_TIMES
extern asmlinkage long (*original_sys_futimesat)(int dirfd, const char USERPTR *pathname, const struct timeval times[2]);
extern asmlinkage long (*original_sys_utime)(const char USERPTR *filename, const struct utimbuf USERPTR *buf);
extern asmlinkage long (*original_sys_utimes)(const char USERPTR *filename, const struct timeval times[2]);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
extern asmlinkage long (*original_sys_utimensat)(int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags);
#endif

// TWNOTIFY_XATTRCHANGE
extern asmlinkage long (*original_sys_fremovexattr)(int fd, const char USERPTR *name);
extern asmlinkage long (*original_sys_fsetxattr)(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
extern asmlinkage long (*original_sys_lremovexattr)(const char USERPTR *path, const char USERPTR *name);
extern asmlinkage long (*original_sys_lsetxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
extern asmlinkage long (*original_sys_removexattr)(const char USERPTR *path, const char USERPTR *name);
extern asmlinkage long (*original_sys_setxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);

// TWNOTIFY_TRUNCATE
extern asmlinkage long (*original_sys_ftruncate)(int fd, unsigned long length);
extern asmlinkage long (*original_sys_ftruncate64)(int fd, loff_t length);
extern asmlinkage long (*original_sys_truncate)(const char USERPTR *path, unsigned long length);
extern asmlinkage long (*original_sys_truncate64)(const char USERPTR *path, loff_t length);

// TWNOTIFY_MOUNT
extern asmlinkage long (*original_sys_mount)(const char USERPTR *source, const char USERPTR *target, const char USERPTR *filesystemtype,
                        unsigned long mountflags, const void USERPTR *data);

// TWNOTIFY_UNMOUNT
extern asmlinkage long (*original_sys_umount)(const char USERPTR *target);
extern asmlinkage long (*original_sys_umount2)(const char USERPTR *target, int flags);


// HOUSEKEEPING
extern asmlinkage long (*original_sys_close)(unsigned int fd);




#ifdef CONFIG_64BIT

// function pointers for original values in ia32 syscalltable - filled in when we hook:
// these are for the ia32 entries that are the same as the native entries
// there are not twnotify_xxxx implementations for these bacause we reuse the native ones

// TWNOTIFY_CREAT
extern asmlinkage long (*original32_sys_creat)(const char USERPTR *filename, int mode);
extern asmlinkage long (*original32_sys_mkdir)(const char USERPTR *pathname, int mode);
extern asmlinkage long (*original32_sys_mkdirat)(int dirfd, const char USERPTR *pathname, int mode);
extern asmlinkage long (*original32_sys_mknod)(const char USERPTR *pathname, int mode, int dev);
extern asmlinkage long (*original32_sys_mknodat)(int dirfd, const char USERPTR *pathname, int mode, int dev);

// TWNOTIFY_LINK
extern asmlinkage long (*original32_sys_link)(const char USERPTR *oldpath, const char USERPTR *newpath);
extern asmlinkage long (*original32_sys_linkat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath, int flags);
extern asmlinkage long (*original32_sys_symlink)(const char USERPTR *oldpath, const char USERPTR *newpath);
extern asmlinkage long (*original32_sys_symlinkat)(const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_DELETE
extern asmlinkage long (*original32_sys_rmdir)(const char USERPTR *pathname);
extern asmlinkage long (*original32_sys_unlink)(const char USERPTR *pathname);
extern asmlinkage long (*original32_sys_unlinkat)(int dirfd, const char USERPTR * pathname, int flags);

// TWNOTIFY_RENAME
extern asmlinkage long (*original32_sys_rename)(const char USERPTR *oldpath, const char USERPTR *newpath);
extern asmlinkage long (*original32_sys_renameat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_WRITE
// - 2.2 and 2.4 kernel only: extern asmlinkage long (*original_sys_pwrite)(int fd, const void USERPTR *buf, int count, int offset);
extern asmlinkage ssize_t (*original32_sys_write)(int fd, const void USERPTR *buf, size_t count);
extern asmlinkage long (*original32_sys_splice)(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);

// TWNOTIFY_CHMOD
extern asmlinkage long (*original32_sys_chmod)( const char USERPTR *path, mode_t mode);
extern asmlinkage long (*original32_sys_fchmod)(int fd, mode_t mode);
extern asmlinkage long (*original32_sys_fchmodat)(int dirfd, const char USERPTR *pathname, mode_t mode, int flags);

// TWNOTIFY_CHOWN
extern asmlinkage long (*original32_sys_fchownat)(int dirfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);

// TWNOTIFY_TIMES

// TWNOTIFY_XATTRCHANGE
extern asmlinkage long (*original32_sys_fremovexattr)(int fd, const char USERPTR *name);
extern asmlinkage long (*original32_sys_fsetxattr)(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
extern asmlinkage long (*original32_sys_lremovexattr)(const char USERPTR *path, const char USERPTR *name);
extern asmlinkage long (*original32_sys_lsetxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
extern asmlinkage long (*original32_sys_removexattr)(const char USERPTR *path, const char USERPTR *name);
extern asmlinkage long (*original32_sys_setxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);

// TWNOTIFY_TRUNCATE
extern asmlinkage long (*original32_sys_ftruncate)(int fd, unsigned long length);
extern asmlinkage long (*original32_sys_truncate)(const char USERPTR *path, unsigned long length);

// TWNOTIFY_MOUNT

// TWNOTIFY_UNMOUNT


// HOUSEKEEPING
extern asmlinkage long (*original32_sys_close)(unsigned int fd);



// These are ia32 emulation entry points that don't just call the 64b funcs
// or that aren't in the 64b syscall table but are in the 32b table


/*  now in compat.h */
/*
struct compat_utimbuf {
        compat_time_t           actime;
        compat_time_t           modtime;
};

struct compat_iovec {
        compat_uptr_t   iov_base;
        compat_size_t   iov_len;
};
*/


extern asmlinkage long (*original32_sys_open)(const char USERPTR *filename, int flags, int mode);
extern asmlinkage long (*original32_sys_openat)(unsigned int dfd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
extern asmlinkage long (*original32_sys_open_by_handle_at)(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39



extern asmlinkage long (*original32_sys_writev)(unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen);
extern asmlinkage long (*original32_sys_pwritev)(unsigned long fd, const struct compat_iovec __user *vec, unsigned long vlen, u32 pos_low, u32 pos_high);
extern asmlinkage long (*original32_sys_pwrite64)(unsigned int fd, char USERPTR *ubuf, u32 count, u32 poslo, u32 poshi);


extern asmlinkage long (*original32_sys_chown)(const char USERPTR *filename, old_uid_t user, old_gid_t group);
extern asmlinkage long (*original32_sys_lchown)(const char USERPTR *filename, old_uid_t user, old_gid_t group);
extern asmlinkage long (*original32_sys_fchown)(unsigned int fd, old_uid_t user, old_gid_t group);

extern asmlinkage long (*original32_sys_chown32)(const char USERPTR *filename, uid_t user, gid_t group);
extern asmlinkage long (*original32_sys_lchown32)(const char USERPTR *filename, uid_t user, gid_t group);
extern asmlinkage long (*original32_sys_fchown32)(unsigned int fd, uid_t user, gid_t group);


extern asmlinkage long (*original32_sys_utime)(char USERPTR *filename, struct compat_utimbuf USERPTR *t);
extern asmlinkage long (*original32_sys_futimesat)(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t);
extern asmlinkage long (*original32_sys_utimes)(char USERPTR *filename, struct compat_timeval USERPTR *t);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
extern asmlinkage long (*original32_sys_utimensat)(int dfd, char USERPTR *filename, struct compat_timespec USERPTR *utimes, int flags);
#endif

extern asmlinkage long (*original32_sys_truncate64)(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high);
extern asmlinkage long (*original32_sys_ftruncate64)(unsigned int fd, unsigned long offset_low, unsigned long offset_high);


extern asmlinkage long (*original32_sys_mount)(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type, unsigned long flags, void USERPTR * data);
extern asmlinkage long (*original32_sys_umount)(char USERPTR * name);
extern asmlinkage long (*original32_sys_umount2)(char USERPTR * name, int flags);


#endif // CONFIG_64_BIT

#endif // __TWNOTIFY_HANDLERS_H__


