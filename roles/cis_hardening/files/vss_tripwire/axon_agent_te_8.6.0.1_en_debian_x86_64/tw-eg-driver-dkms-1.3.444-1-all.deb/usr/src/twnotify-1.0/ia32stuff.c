/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


// stuff needed for ia32 support on 64b

#ifdef CONFIG_64BIT


// these defines taken from the 386 unistd.h
// renamed to have 32 in the name

// below each are the ia32 table entries for the above sys call number
// these were copied from ia32entry.S
// listed here just so we can check the args of the target functions



#define __NR32_write                4
//  .quad sys_write

#define __NR32_open                 5
//  .quad compat_sys_open

#define __NR32_close                6
//  .quad sys_close

#define __NR32_creat                8
//  .quad sys_creat

#define __NR32_link                 9
//  .quad sys_link

#define __NR32_unlink              10
//  .quad sys_unlink

#define __NR32_mknod               14
//  .quad sys_mknod

#define __NR32_chmod               15
//  .quad sys_chmod

#define __NR32_lchown              16
//  .quad sys_lchown16

#define __NR32_mount               21
//  .quad compat_sys_mount

#define __NR32_umount              22
//  .quad sys_oldumount

#define __NR32_utime               30
//  .quad compat_sys_utime

#define __NR32_rename              38
//  .quad sys_rename

#define __NR32_mkdir               39
//  .quad sys_mkdir

#define __NR32_rmdir               40
//  .quad sys_rmdir

#define __NR32_umount2             52
//  .quad sys_umount

#define __NR32_symlink             83
//  .quad sys_symlink

#define __NR32_mmap                90
//  .quad sys32_mmap

#define __NR32_truncate            92
//  .quad sys_truncate

#define __NR32_ftruncate           93
//  .quad sys_ftruncate

#define __NR32_fchmod              94
//  .quad sys_fchmod

#define __NR32_fchown              95
//  .quad sys_fchown16

#define __NR32_msync              144
//  .quad sys_msync

#define __NR32_writev             146
//  .quad compat_sys_writev

#define __NR32_pwrite64           181
//  .quad sys32_pwrite

#define __NR32_chown              182
//  .quad sys_chown16

#define __NR32_mmap2              192
//  .quad sys32_mmap2

#define __NR32_truncate64         193
//  .quad sys32_truncate64

#define __NR32_ftruncate64        194
//  .quad sys32_ftruncate64

#define __NR32_lchown32           198
//  .quad sys_lchown

#define __NR32_fchown32           207
//  .quad sys_fchown

#define __NR32_chown32            212
//  .quad sys_chown

#define __NR32_setxattr           226
//  .quad sys_setxattr

#define __NR32_lsetxattr          227
//  .quad sys_lsetxattr

#define __NR32_fsetxattr          228
//  .quad sys_fsetxattr

#define __NR32_removexattr        235
//  .quad sys_removexattr

#define __NR32_lremovexattr       236
//  .quad sys_lremovexattr

#define __NR32_fremovexattr       237
//  .quad sys_fremovexattr

#define __NR32_utimes             271
//  .quad compat_sys_utimes

#define __NR32_openat             295
//  .quad compat_sys_openat

#define __NR32_mkdirat            296
//  .quad sys_mkdirat

#define __NR32_mknodat            297
//  .quad sys_mknodat

#define __NR32_fchownat           298
//  .quad sys_fchownat

#define __NR32_futimesat          299
//  .quad compat_sys_futimesat

#define __NR32_unlinkat           301
//  .quad sys_unlinkat

#define __NR32_renameat           302
//  .quad sys_renameat

#define __NR32_linkat             303
//  .quad sys_linkat

#define __NR32_symlinkat          304
//  .quad sys_symlinkat

#define __NR32_fchmodat           306
//  .quad sys_fchmodat

#define __NR32_splice             313
//  .quad sys_splice

#define __NR32_utimensat          320
//  .quad compat_sys_utimensat

#define __NR32_pwritev            334
//  .quad compat_sys_pwritev

#define __NR32_open_by_handle_at  342
//  .quad compat_sys_open_by_handle_at

/*
    just for checking here are the 64b syscalls
    re-ordered for compare with the 32b table
    also, show which 32b calls are missing
    note, no new calls for 64b

 17 #define __NR_write                1
 19 #define __NR_open                 2
 21 #define __NR_close                3
195 #define __NR_creat               85
197 #define __NR_link                86
199 #define __NR_unlink              87
298 #define __NR_mknod              133
206 #define __NR_chmod               90
214 #define __NR_lchown              94
379 #define __NR_mount              165
// umount
296 #define __NR_utime              132
189 #define __NR_rename              82
191 #define __NR_mkdir               83
193 #define __NR_rmdir               84
381 #define __NR_umount2            166
202 #define __NR_symlink             88
 34 #define __NR_mmap                 9
176 #define __NR_truncate            76
178 #define __NR_ftruncate           77
208 #define __NR_fchmod              91
212 #define __NR_fchown              93
 70 #define __NR_msync               26
 57 #define __NR_writev              20
 53 #define __NR_pwrite64            18
210 #define __NR_chown               92
// mmap2
// trunc64
// ftrunc64
// lchown32
// fchown32
// chown32
446 #define __NR_setxattr           188
448 #define __NR_lsetxattr          189
450 #define __NR_fsetxattr          190
464 #define __NR_removexattr        197
466 #define __NR_lremovexattr       198
468 #define __NR_fremovexattr       199
540 #define __NR_utimes             235
584 #define __NR_openat             257
586 #define __NR_mkdirat            258
588 #define __NR_mknodat            259
590 #define __NR_fchownat           260
592 #define __NR_futimesat          261
596 #define __NR_unlinkat           263
598 #define __NR_renameat           264
600 #define __NR_linkat             265
602 #define __NR_symlinkat          266
606 #define __NR_fchmodat           268
*/


#endif
