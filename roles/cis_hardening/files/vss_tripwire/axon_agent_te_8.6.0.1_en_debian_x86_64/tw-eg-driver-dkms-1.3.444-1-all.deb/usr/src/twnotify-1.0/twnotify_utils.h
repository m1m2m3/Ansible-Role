/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */

#ifndef __TWNOTIFY_UTILS_H__
#define __TWNOTIFY_UTILS_H__

#include "twnotify_main.h"

// user poitner type
#define USERPTR __user

// generic function pointer type fro Intel
typedef void (*funcptr) (void);

// Driver-level context tracking structure:
struct twnotify_smr_context_record
{
    uint64_t    fdid;
    u64         last_write_report_time;
};


// Fixed sixe array size.
#define TWNOTIFY_SMR_CACHE_SIZE 3000

extern struct twnotify_smr_context_record _smr_cache[];
extern int _cur_smr_id;

// for protecting smr list/array
extern spinlock_t smr_protect;




struct twnotify* twnotify_alloc_event( int fd, const char* str1, const char* str2, const char* str3, int*size );

char * twnotify_getfilename2( const char* ctx, unsigned int dfd, const char USERPTR *filename, int nofollow, int noerr);

char * twnotify_get_fd_filename(const char* ctx, unsigned int fd);

struct twnotify* twnotify_prep_event_1fd( const char* ctx, int etype, int fd );
struct twnotify* twnotify_prep_event_1file( const char* ctx, int etype, int dfd, const char USERPTR *filename );
struct twnotify* twnotify_prep_event_l1file( const char* ctx, int etype, int dfd, const char USERPTR *filename );
struct twnotify* twnotify_prep_event_1filex( const char* ctx, int etype, const char *full );
struct twnotify* twnotify_prep_event_2files( const char* ctx, int etype, int dfd, const char USERPTR *filename, int dfd2, const char USERPTR *filename2 );
struct twnotify* twnotify_prep_event_l2files( const char* ctx, int etype, int dfd, const char USERPTR *filename, int dfd2, const char USERPTR *filename2 );
struct twnotify* twnotify_prep_event_2filesx( const char* ctx, int etype, const char *full, int dfd2, const char USERPTR *filename2 );
uint64_t twnotify_get_fdid( const char* ctx, int fd, int noerr );
int twnotify_get_mode(int fd);
int twnotify_need_write_report( const char* ctx,  int fd );




#endif
