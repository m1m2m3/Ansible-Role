/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/security.h>
#include <linux/usb.h>
#include <linux/string.h>
#include <linux/syscalls.h>
#include <asm/page.h>
#include <asm/cacheflush.h>
#include <asm/unistd.h>
#include <linux/types.h>
#include <linux/mount.h>
#include <linux/file.h>
#include <asm/uaccess.h>
#include <linux/sched.h>
#include <linux/jiffies.h>
#include <linux/namei.h>
#include <linux/dcache.h>

// our includes
#include "twnotify.h"
#include "twnotify_user.h"
#include "twnotify_utils.h"


// necessary to get right configuration of the audit interface to audit_get_loginuid()
#ifndef CONFIG_AUDITSYSCALL
#define CONFIG_AUDITSYSCALL
#endif // CONFIG_AUDITSYSCALL

#include <linux/audit.h>


#ifdef KERNEL_GT_2_6_29
// need these files on newer kernels
#include "linux/path.h"
#include "linux/fs_struct.h"
#include "linux/spinlock_types.h"
#endif


#undef MY_NAME
#define MY_NAME "twnotify_utils"


// size of SMR cache:  (NOTE: Now defined in the header)
//  #define TWNOTIFY_SMR_CACHE_SIZE 3000


struct twnotify_smr_context_record _smr_cache[TWNOTIFY_SMR_CACHE_SIZE];
int _cur_smr_id = 1;

// for protecting smr list/array
spinlock_t smr_protect;



/*****************************************************************************
*
* FUNCTION: twnotify_alloc_event( )
*
*****************************************************************************/

struct twnotify* twnotify_alloc_event( int fd, const char* str1, const char* str2, const char* str3, int*size )
{
    struct twnotify *ntf;
    int len1 = 0;
    int len2 = 0;
    int len3 = 0;
    char * pstr = NULL;

    *size = TWNOTIFY_SIZE;

    // calculate the size needed for the struct
    if( str1 )
    {
        len1 = strlen(str1) + 1;
        *size += len1;
    }
    if( str2 )
    {
        len2 = strlen(str2) + 1;
        *size += len2;
    }
    if( str3 )
    {
        len3 = strlen(str3) + 1;
        *size += len3;
    }

    // allocate it
    ntf = kmalloc(*size, GFP_ATOMIC);
    memset( ntf, 0, *size );

    // fill in the basic info for all structs
    ntf->size = *size;
    ntf->pid = current->pid;
    ntf->tgid = current->tgid;

#if defined(CONFIG_UIDGID_STRICT_TYPE_CHECKS) || defined(KERNEL_GT_3_5_0)
  #ifndef UEK_R3
    #define USE_NEW_UIDGID_STRUCT 1
  #endif
#endif

#ifdef KERNEL_GT_2_6_29
       #if defined(USE_NEW_UIDGID_STRUCT)
		// Starting in 3.5.0 this structure is different
		ntf->uid = current->real_cred->uid.val; // could be ->cred?
		ntf->euid = current->real_cred->euid.val;
		ntf->fsuid = current->real_cred->fsuid.val;
	#else
		// Starting in 2.6.29 this structure is different
		ntf->uid = current->real_cred->uid; // could be ->cred?
		ntf->euid = current->real_cred->euid;
		ntf->fsuid = current->real_cred->fsuid;
	#endif
#else
    // Prior to 2.6.29 we use this format
    ntf->uid = current->uid;
    ntf->euid = current->euid;
    ntf->fsuid = current->fsuid;
#endif

    // Get the loginuid for the logged in user

    // First, default to the UID field, then change it if there is an audit loginuid to replace it
    ntf->loginuid = ntf->uid;

#ifdef KERNEL_GT_2_6_24

    // In kernels greater than 2.6.24 (2.6.25 +) the loginuid can be obtained by calling
    //   audit_get_loginuid( struct task_struct t ).  This is defined as a macro for t->loginuid
    //   but may change, so we use the macro from audit.h rather than accessing the value directly

#if defined(USE_NEW_UIDGID_STRUCT)
    if( audit_get_loginuid( current ).val != -1 )
        ntf->loginuid = audit_get_loginuid( current ).val;
#else
    if( audit_get_loginuid( current ) != -1 )
        ntf->loginuid = audit_get_loginuid( current );
#endif

#else
    // in kernels 2.6.24 and prior audit_get_loginuid() is an actual function call which takes
    //   struct audit_context as the parameter.  We pass the one from the current task struct
    //   get the loginuid
    if( audit_get_loginuid( current->audit_context ) != -1 )
        ntf->loginuid = audit_get_loginuid( current->audit_context );


#endif


    ntf->fd = fd;
    memcpy( ntf->exe_name, current->comm, TASK_COMM_LEN);

    // Fill in variable length string values:
    if( str1 )
    {
        pstr = (char*)ntf + TWNOTIFY_SIZE;
        ntf->str1_offset = TWNOTIFY_SIZE;
        strcpy(pstr, str1);
    }
    if( str2 )
    {
        pstr += len1;
        ntf->str2_offset = TWNOTIFY_SIZE + len1;
        strcpy(pstr, str2);
    }
    if( str3 )
    {
        pstr += len2;
        ntf->str3_offset = TWNOTIFY_SIZE + len1 + len2;
        strcpy(pstr, str3);
    }
    return ntf;
}

/*****************************************************************************
*
* FUNCTION: twnotify_getfilename2( )
*
*****************************************************************************/

char * twnotify_getfilename2( const char* ctx, unsigned int dfd, const char USERPTR *filename, int nofollow, int noerr)
{
    int err = 0;
    char *ret = NULL;
    int follow_flag = LOOKUP_FOLLOW;
    struct dentry * myf_dentry = NULL;
    struct inode * my_inode = NULL;
    int do_d_path = 0;

#ifdef KERNEL_GT_2_6_24
    struct path my_path;
#else
    struct nameidata nd;
#endif

    //root_spew( "%s: getting name for fd %d, name %s \n", ctx, dfd, filename);

    // ask kernel for a nameidata
    if( nofollow)
    {
        follow_flag = 0;
    }

#ifndef KERNEL_GT_2_6_24
    // earlier kernel way
    err = __user_walk_fd( dfd, filename, follow_flag, &nd);
    if( !err )
    {
        myf_dentry = dget(nd.dentry);
    }
#else
    // later kernels use a diferent internal structure and API
    err = user_path_at( dfd, filename, follow_flag, &my_path );
    if( !err )
    {
        myf_dentry = dget(my_path.dentry);
    }
#endif

    if (!err)
    {
        // we have a dentry, so walk it and build the path
        char *page = NULL;

        root_spew( "%s: Getting physical path \n", ctx);
        page = (char *) __get_free_page(GFP_USER);
        if (page)
        {

/*
    NOTE : d_path() takes on two forms

    // old kernels < 2.6.24
    char * d_path(struct dentry *dentry, struct vfsmount *vfsmnt, char *buf, int buflen)

    // after 2.6.24
    char *d_path(const struct path *path, char *buf, int buflen)

*/
            my_inode = myf_dentry->d_inode;
            if( my_inode )
            {
                /// SOCKETS!!!!!
                if( S_ISSOCK(my_inode->i_mode) )
                {
                    // valid inode and mode, so this is good.
                    do_d_path = 0;
                }
                else
                {
                    do_d_path = 1;
                }
            }
            else
            {
                // do the dpath thing just like the old code would have  (trying to make sure we don't change
                //    behavior in corner cases)
                do_d_path = 1;
            }

            if( do_d_path )
            {

#ifndef KERNEL_GT_2_6_24
                // This works on kernels older than 2.6.24
                char* name = d_path( nd.dentry, nd.mnt, page, PAGE_SIZE);

#else
                // newer way - use new form of kernels own __d_path()
                char* name = d_path( &my_path, page, PAGE_SIZE);
#endif

                if( !IS_ERR(name))
                {
                    unsigned long len2;
                    char * ret2;
                    // d_path builds path backwards from the end of the buffer
                    len2 = PAGE_SIZE + page - name;
                    root_spew( "%s: name: %s \n", ctx, name);

                    ret2 = kmalloc( len2, GFP_ATOMIC);
                    if( ret2 && len2)
                    {
                        memcpy( ret2, name, len2);
                        ret = ret2;
                        root_spew( "%s: full: %s \n", ctx, ret);
                    }
                    else
                    {
                        root_warn( "%s: kmalloc failed \n", ctx);
                    }
                }
                else
                {
                    root_warn( "%s: d_path failed \n", ctx);
                }
            }

            free_page( (unsigned long) page);
        }
        else
        {
            root_warn( "%s: getfreepage failed \n", ctx);
        }

        dput(myf_dentry);

#ifndef KERNEL_GT_2_6_24
        path_release(&nd);
#else
        path_put(&my_path);
#endif

    }
    else
    {
        // mount accepts server:filename names.  Also, symlink can point to
        //  non-existent files, so in each case we return the filename the user used...
        if( 0 == strcmp( ctx, "mount") || 0 == strcmp( ctx, "32mount")
            || 0 == strcmp( ctx, "symlink") || 0 == strcmp( ctx, "symlinkat"))
        {
            int size = 0;
            ret = kmalloc( PATH_MAX, GFP_ATOMIC);
            if( ret)
            {
                size = strncpy_from_user( ret, filename, PATH_MAX);
                if( size < 0 )
                {
                    kfree(ret);
                    ret = NULL;
                    root_warn( "%s: strncpy_from_user failed err=%d\n", ctx, size);
                }
            }
            else
            {
                root_warn( "%s: kmalloc2(%d) failed \n", ctx, size);
            }
        }
        else
        {
            root_dbg( "%s: userwalk failed: %d for fd %d, name %s \n", ctx, err, dfd, filename);
        }
    }

    if (!ret && !noerr)
    {
        root_dbg("%s: couldn't find file name \n", ctx);
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_get_fd_filename( )
*
*****************************************************************************/

char * twnotify_get_fd_filename(const char* ctx, unsigned int fd)
{
    char *ret = NULL;
    char *page = (char *) __get_free_page(GFP_USER);
    if (page)
    {
        // lock the file struct associated with this fd
        struct file *file = fget(fd);
        if (file)
        {
            struct vfsmount *myf_mnt = NULL;
            struct dentry *myf_dentry = NULL;
            struct inode * my_inode = NULL;

#ifndef KERNEL_GT_2_6_24  // not necessary for use
            myf_mnt = mntget(file->f_vfsmnt);
#endif

#ifdef KERNEL_GT_3_5_0
            myf_dentry = dget(file->f_path.dentry);
#else
            myf_dentry = dget(file->f_dentry);
#endif

            my_inode = myf_dentry->d_inode;

            // Has the current directory been unlinked?
            if( (myf_dentry->d_parent == myf_dentry || !d_unhashed(myf_dentry)) && (my_inode) &&
              (! S_ISSOCK(my_inode->i_mode)) )
            {

#ifndef KERNEL_GT_2_6_24
                // This works on kernels older than 2.6.24
                char* name = d_path( myf_dentry, myf_mnt, page, PAGE_SIZE);
#else
                // newer way - use new form of kernels own __d_path()
                char* name = d_path( &file->f_path, page, PAGE_SIZE);
#endif

                if (!IS_ERR(name))
                {
                    // d_path builds path backwards from the end of the buffer
                    unsigned long len = PAGE_SIZE + page - name;
                    root_spew("path: %s\n", name);
                    if( len)
                    {
                        ret = kmalloc( len, GFP_ATOMIC);
                        if( ret)
                        {
                            memcpy( ret, name, len);
                        }
                        else
                        {
                            root_warn( "%s: kmalloc failed \n", ctx);
                        }
                    }
                    else
                    {
                        root_dbg( "%s: d_path len is 0 \n", ctx);
                    }
                }
                else
                {
                    root_dbg( "%s: d_path failed \n", ctx);
                }
            }

            if( myf_dentry) dput(myf_dentry);
            if( myf_mnt) mntput(myf_mnt);
            if( file ) fput(file);
        }
        else
        {
            root_dbg( "%s: fget failed \n", ctx);
        }

        free_page((unsigned long) page);
    }
    else
    {
        root_warn( "%s: getfreepage failed \n", ctx);
    }

    if (!ret)
    {
        root_dbg( "%s: couldn't get file name for %x \n", ctx, fd);
    }
    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_1fd( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_1fd( const char* ctx, int etype, int fd )
{
    struct twnotify* ntf = NULL;
    char* full = twnotify_get_fd_filename( ctx, fd);
    if( full )
    {
        if ( !is_excluded(current->tgid, full))
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, NULL, NULL, &size );
            ntf->type = etype;
        }
        kfree(full);
        full = NULL;
    }
    return ntf;
}


/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_1file( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_1file( const char* ctx, int etype, int dfd, const char USERPTR *filename )
{
    struct twnotify* ntf = NULL;
    char* full = NULL;

    if( filename == NULL )
    {
        // use dfd as the fd and get it that way:
        return twnotify_prep_event_1fd( ctx, etype, dfd );
    }

    full = twnotify_getfilename2( ctx, dfd, filename, 0, 0);

    if( full )
    {
        if ( !is_excluded(current->tgid, full))
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, NULL, NULL, &size );
            ntf->type = etype;
        }
        kfree(full);
        full = NULL;
    }
    return ntf;
}


/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_l1file( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_l1file( const char* ctx, int etype, int dfd, const char USERPTR *filename )
{
    struct twnotify* ntf = NULL;
    char* full = NULL;

    if( filename == NULL )
    {
        // use dfd as the fd and get it that way:
        return twnotify_prep_event_1fd( ctx, etype, dfd );
    }

    full = twnotify_getfilename2( ctx, dfd, filename, 1, 0);
    if( full )
    {
        if ( !is_excluded(current->tgid, full))
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, NULL, NULL, &size );
            ntf->type = etype;
        }
        kfree(full);
        full = NULL;
    }
    return ntf;
}


/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_1filex( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_1filex( const char* ctx, int etype, const char *full )
{
    struct twnotify* ntf = NULL;

    if( full )
    {
        if ( !is_excluded(current->tgid, full))
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, NULL, NULL, &size );
            ntf->type = etype;
        }
        kfree(full);
        full = NULL;
    }
    return ntf;
}


/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_2files( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_2files( const char* ctx, int etype, int dfd, const char USERPTR *filename, int dfd2, const char USERPTR *filename2 )
{

    struct twnotify* ntf = NULL;
    char *full = twnotify_getfilename2( ctx, dfd, filename, 0, 0);
    char *full2 = twnotify_getfilename2( ctx, dfd2, filename2, 0, 0);

    if( full && full2)
    {
        // we don't want to exclude the path if this is a mount event
        if ( !is_excluded( current->tgid, etype == TWNOTIFY_MOUNT ? "" : full) )
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, full2, NULL, &size );
            ntf->type = etype;
        }
    }
    if( full)
    {
        kfree(full);
        full = NULL;
    }
    if( full2)
    {
        kfree(full2);
        full2 = NULL;
    }

    return ntf;
}


/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_l2files( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_l2files( const char* ctx, int etype, int dfd, const char USERPTR *filename, int dfd2, const char USERPTR *filename2 )
{

    struct twnotify* ntf = NULL;
    char *full = twnotify_getfilename2( ctx, dfd, filename, 0, 0);
    char *full2 = twnotify_getfilename2( ctx, dfd2, filename2, 1, 0);

    if( full && full2)
    {
        // we don't want to exclude the path if this is a mount event
        if ( !is_excluded( current->tgid, etype == TWNOTIFY_MOUNT ? "" : full) )
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, full2, NULL, &size );
            ntf->type = etype;
        }
    }
    if( full)
    {
        kfree(full);
        full = NULL;
    }
    if( full2)
    {
        kfree(full2);
        full2 = NULL;
    }

    return ntf;
}


/*****************************************************************************
*
* FUNCTION: twnotify_prep_event_2filesx( )
*
*****************************************************************************/

struct twnotify* twnotify_prep_event_2filesx( const char* ctx, int etype, const char *full, int dfd2, const char USERPTR *filename2 )
{
    struct twnotify* ntf = NULL;
    int nofollow = 0;
    char* full2 = NULL;

    // NOTE: If this guy is called from a rename handler, we
    // want to no-follow links in case the renamed thing is the link
    if( 0 == strcmp( ctx, "rename") || 0 == strcmp( ctx, "renameat") )
        nofollow = 1;

    full2 = twnotify_getfilename2( ctx, dfd2, filename2, nofollow, 0);

    if( full && full2)
    {
        if ( !is_excluded(current->tgid, full))
        {
            int size = 0;
            ntf = twnotify_alloc_event( 9999, full, full2, NULL, &size );
            ntf->type = etype;
        }
    }
    if( full)
    {
        kfree(full);
        full = NULL;
    }
    if( full2)
    {
        kfree(full2);
        full2 = NULL;
    }

    return ntf;
}





/*****************************************************************************
*
* FUNCTION: twnotify_get_fdid( )
*
*****************************************************************************/

uint64_t twnotify_get_fdid( const char* ctx, int fd, int noerr )
{
    uint64_t ret = 0;
    struct dentry *myf_dentry = NULL;
    struct inode * my_inode = NULL;
    struct file *file = NULL;
    if( fd >=0 )
    {
        file = fget(fd);
        if( file )
        {
#ifdef KERNEL_GT_3_5_0
            if( file->f_path.dentry )
#else
            if( file->f_dentry )
#endif
            {
#ifdef KERNEL_GT_3_5_0
                myf_dentry = dget(file->f_path.dentry);
#else
                myf_dentry = dget(file->f_dentry);
#endif
                if( myf_dentry )
                {
                    my_inode = myf_dentry->d_inode;
                    if( my_inode )
                    {
                        // use the inode number plus shifted pid as unique identifier for this open file context
                        ret = (((uint64_t)current->pid) << 32) + (uint64_t)my_inode->i_ino;
                    }
                    dput(myf_dentry);
                }
            }
            fput(file);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_get_mode( )
*
*****************************************************************************/

int twnotify_get_mode(int fd)
{
 //   struct file *file;
 //   int fput_needed;
    int mode = 0;

    // TODO:  noop till more testing...
    return mode;
/* - This code was not being used and does not compile with Kernel 4.1
    file = fget_light(fd, &fput_needed);
    if (file)
    {
        struct dentry *dent = file->f_path.dentry;
        struct inode *inod = dent->d_inode;
        if (inod)
        {
            mode = inod->i_mode;
        }
        fput_light(file, fput_needed);
    }
    return mode;
    */
}

/*****************************************************************************
*
* FUNCTION: twnotify_find_existing_smr( )
*
*****************************************************************************/

struct twnotify_smr_context_record * twnotify_find_existing_smr( uint64_t fdid )
{
    // returns pointer to existing smr if there is one, otherwise NULL

    int i = 0;
    for( i = 0; i < TWNOTIFY_SMR_CACHE_SIZE; i++ )
    {
        if( _smr_cache[i].fdid == fdid )
        {
            return &_smr_cache[i];
        }
    }
    return NULL;
}

/*****************************************************************************
*
* FUNCTION: twnotify_get_new_smr( )
*
*****************************************************************************/

struct twnotify_smr_context_record * twnotify_get_new_smr( uint64_t fdid )
{
    // returns a pointer to the smr to use no matter what, always return something!

    int oldest_slot = 0;
    int i = 0;
    u64 oldest_time = 0x7fffffffffffffff;

    for( i = 0; i < TWNOTIFY_SMR_CACHE_SIZE; i++ )
    {
        if( _smr_cache[i].last_write_report_time < oldest_time )
        {
            oldest_slot = i;
            oldest_time = _smr_cache[oldest_slot].last_write_report_time;
        }
    }
    return &_smr_cache[oldest_slot];
}



/*****************************************************************************
*
* FUNCTION: twnotify_need_write_report( )
*
*****************************************************************************/

int twnotify_need_write_report( const char* ctx,  int fd )
{

    struct twnotify_smr_context_record* pSmr = NULL;
    uint64_t fdid = 0;

    // check to se if we can just ignore this because it's not a type we care about
    int mode = twnotify_get_mode(fd);
    if( !ignorespecial && (S_ISSOCK(mode) || S_ISFIFO(mode)) )
    {
        return 0;
    }

    // see if we can find the fd in the smr cache:
    fdid = twnotify_get_fdid( ctx, fd, 1 );

    if( fdid )
    {
        // see if we can find an smr entry for this fdid
        pSmr = twnotify_find_existing_smr( fdid );
        if( pSmr )
        {
            // found existing one, so check the time delta and see if we need to report:
            u64 nowJiffies = get_jiffies_64();
            u64 diff = nowJiffies - pSmr->last_write_report_time;

            if( diff > write_interval )
            {
                // this is a tracked open file and we DO need to report a write due to time delta since last

                // grab the lock:
                spin_lock(&smr_protect);

                // re-search the list with lock held to make sure nobody else modified it:
                pSmr = twnotify_find_existing_smr( fdid );
                if( pSmr )
                {
                    // update time of report
                    pSmr->last_write_report_time = nowJiffies;
                }
                // NOTE: It's okay if we didn't find it in the list the second time, we still report this write and it
                //  will catch it next time if another write happens.

                // let go of the lock
                spin_unlock(&smr_protect);
                // tell caller we DO need a write report
                return 1;
            }
            else
            {
                // If we get here, this is a tracked open file whose re-report delta has not been reached,
                //  so we SUPRESS the write by returning 0 here
                return 0;
            }
        }

        // if we get here, then we do NOT have an existing smr cache entry for this fdid.  We need to make one and
        //  fill it in, and return 1 so a write is reported.

        // grab the lock:
        spin_lock(&smr_protect);

        // get the first empty or oldest smr entry that we'll fill in for this new one:
        pSmr = twnotify_get_new_smr( fdid );

        // fill in basics:
        pSmr->fdid = fdid;
        pSmr->last_write_report_time =  get_jiffies_64();

        // relase thr lock, all done modifying:
        spin_unlock(&smr_protect);
        return 1;
    }

    return 0;
}






