/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


#ifndef __TWNOTIFY_MAIN_H__
#define __TWNOTIFY_MAIN_H__




/*****************************************************************************
*
* Kernel Version Support:
*
*****************************************************************************/


#include <linux/version.h>

//*************************************************************
/********  Linux Kernel Versions supported by this source code:
   (Please try to keep this list up to date)

RHEL 5.0  2.6.18-8.el5
RHEL 5.1  2.6.18-53.el5
RHEL 5.2  2.6.18-92.el5
RHEL 5.3  2.6.18-128.el5
RHEL 5.4  2.6.18-164.el5
RHEL 5.5  2.6.18-194.el5
RHEL 5.6  2.6.18-238.el5
RHEL 5.7  2.6.18-274.el5
RHEL 6.0  2.6.32-71.el6
RHEL 6.1  2.6.32-131.0.15.el6

SLES 10.0  2.6.16.21-0.8  (NOT supported by TW)
SLES 10.1  2.6.16.46-0.12 (NOT supported by TW)
SLES 10.2  2.6.16.60-0.21
SLES 10.3  2.6.16.60-0.54.5

SLES 11.0  2.6.27.19-5
SLES 11.1  2.6.32.12-0.7

SLES "Current" (as of 3/30/2011)
SLES 10.current 2.6.16.60-0.66.1
SLES 11.current 2.6.32.13-0.5


****************************************************************/

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
// special handling in code for stuff that appeared in 2.6.17 (splice system call)
#define KERNEL_GT_2_6_17
#endif


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,24)
// special handling in code for kernel structure changes that happened in 2.6.24 and greater
//   so far through at least the 2.6.32 in SuSE 11.1
#define KERNEL_GT_2_6_24
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,29)
// special handling in code for other kernel structure changes that happened in 2.6.29 and greater
//   so far through at least the 2.6.32 in SuSE 11.1 and RHEL 6
#define KERNEL_GT_2_6_29
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,30)
// special handling in code for stuff that appeared in 2.6.30 (prwritev system call)
#define KERNEL_GT_2_6_30
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,39)
// special handling in code for stuff that appeared in 2.6.39 (open_by_handle_at system call)
#define KERNEL_GT_2_6_39
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,5,0)
// special handling in code for kernel API changes that happened in 3.5.0 and greater
#define KERNEL_GT_3_5_0
#endif


#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,0,0)
// special handling in code for kernel API changes that happened in 4.0.0 and greater
#define KERNEL_GT_4_0_0
#endif

// UEK is passed in from the Makefile.
#if defined(KERNEL_GT_3_5_0) && UEK > 0
  #define UEK_3_OR_GREATER
  #if !defined(KERNEL_GT_4_0_0)
    #define UEK_R3
  #endif
#endif

/*****************************************************************************
*
* Debug output macros  (/var/log/messages)
*
*****************************************************************************/


#undef MY_NAME
#define MY_NAME "twnotify"

#define root_extra  (1)
//#define root_extra (current->tgid>3000)

#define root_err(fmt, arg...)                            \
                do {if (1)                                  \
                        printk( "%5d %s: %s: " fmt ,         \
                                current->tgid, MY_NAME , __FUNCTION__ , \
                                ## arg);  } while(0);
#define root_warn(fmt, arg...)                           \
                do {if (warn && root_extra)                               \
                        printk( "%5d %s: %s: " fmt ,         \
                                current->tgid, MY_NAME , __FUNCTION__ , \
                                ## arg);  } while(0);
#define root_dbg(fmt, arg...)                            \
                do {if (debug && root_extra)                              \
                        printk( "%5d %s: %s: " fmt ,         \
                                current->tgid, MY_NAME , __FUNCTION__ , \
                                ## arg);  } while(0);
#define root_spew(fmt, arg...)                           \
                do {if (spew && root_extra)                               \
                        printk( "%5d %s: %s: " fmt ,         \
                                current->tgid, MY_NAME , __FUNCTION__ , \
                                ## arg);  } while(0);

#define root_spewuser(fmt, arg...)                           \
                do {if (spewuser && root_extra)                               \
                        printk( "%5d %s: %s: " fmt ,         \
                                current->tgid, MY_NAME , __FUNCTION__ , \
                                ## arg);  } while(0);


// other global state stuff
extern int spew;
extern int spewuser;
extern int debug;
extern int warn;
extern int nommap;
extern int ignorespecial;
extern int bypass_mode;
extern int write_interval;
extern int version;
extern int ishooked;

#endif // __TWNOTIFY_MAIN_H__
