/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


#ifndef __TWNOTIFY_H__
#define __TWNOTIFY_H__


// Our version
#include "version.h"

#define MAX_EXCLUDE_PATH_SIZE 200

// these are ioctl messages to the driver

// arg is pointer to int
#define TWNOTIFY_IOCTL_SETQLIMIT        _IOW(32, 1, int)

// arg is pointer to int
// 0 - no bypass - normal operation
// non-zero - bypass - no notifications and free pending ones
#define TWNOTIFY_IOCTL_SETBYPASS        _IOW(32, 2, int)

// arg is pointer to int size followed by char path
#define TWNOTIFY_IOCTL_EXCLUDE_PATH     _IOW(32, 3, char)

// arg is pointer to a PID
#define TWNOTIFY_IOCTL_EXCLUDE_PID      _IOW(32, 4, long)

// arg is pointer to int - not used
#define TWNOTIFY_IOCTL_CLEAR_EXCLUSIONS _IO(32, 5)
#define TWNOTIFY_IOCTL_CLEAR_PID_EXCLUSIONS _IO(32, 6)
#define TWNOTIFY_IOCTL_CLEAR_PATH_EXCLUSIONS _IO(32, 7)

#define TWNOTIFY_IOCTL_GET_VERSION  _IOR(32, 8, int)
#define TWNOTIFY_IOCTL_GET_HOOKED   _IOR(32, 9, int)
#define TWNOTIFY_IOCTL_SET_HOOK_ADDR _IOW(32, 10, long)
#define TWNOTIFY_IOCTL_SET_WRITE_INTERVAL _IOW(32, 11, long)

// arg is pointer to int - sets the finish flag
#define TWNOTIFY_IOCTL_FINISH_READ _IOW(32, 12, int)

// Default queue size at initialization:
#define TWNOTIFY_DEFAULT_QUEUE_SIZE 10000

// Notification types to user land
enum NOTIFY_TYPE
{
    TWNOTIFY_CREAT,     // creat, mkdir, mkdirat, mknod, mknod2, mknodat, open (w/create flag), openat (w/create flag), (plus unix domain bind?)
    TWNOTIFY_LINK,      // link, linkat, symlink, symlinkat
    TWNOTIFY_DELETE,    // rmdir, unlink, unlinkat
    TWNOTIFY_RENAME,    // rename, renameat
    TWNOTIFY_WRITE,     // pwrite, pwrite64, sendfile, sendfile64, write, writev
    TWNOTIFY_CHMOD,     // chmod, fchmod, fchmodat
    TWNOTIFY_CHOWN,     // chown, chown32, fchown, fchown32, fchownat, lchown, lchown32
    TWNOTIFY_TIMES,     //futimesat, utime, utimes
    TWNOTIFY_XATTRCHANGE, //fremovexattr, fsetxattr, lremovexattr, lsetexattr, removexattr, setxattr
    TWNOTIFY_TRUNCATE,  //ftruncate, ftruncate64, truncate, truncate4
    TWNOTIFY_MOUNT,     // mount
    TWNOTIFY_UNMOUNT,   // umount, umount2
    TWNOTIFY_MMAP,      // mmap, mmap2, msync
};


struct twnotify {
    // Fixed header
    short type;         // notification type from enum above
    short size;         // total size of this struct
    int timestamp;      // timestamp this event was created
    int file_id;        // identifier of file context
    int qsize;          // nubmer of items in the queue currently
    int sequence;       // sequence number of this event (starts at 1000)
    int pid;            // process event created by
    int tgid;           // thread group ID
    int uid;            // user id of the user
    int euid;           // effective uid
    int fsuid;          // filesystem uid
    int loginuid;       // loginuid from audit
    int fd;
    int is_directory;   // is this file object a directory?
    int mode;
    int flags;
    int owner;
    int group;
    int write_length;   // length of write
    int write_offset;   // offset of write in file
    char exe_name[16 /*TASK_COMM_LEN*/ + 1]; // 16-byte process exe name

    // space for 3 strings whose value depending on context - zero offset means no string data for that string value:
    int str1_offset;    // path of file in most cases, or oldpath for link
    int str2_offset;    // rename new name, link new name, or xattr name
    int str3_offset;    // xattr string value;

    // only used by userland, 0 init only by us
    int user_flags;


    // remaining data is strings accessed as TWNOTIFY_GETSTRING

};

//#define TWNOTIFY_SIZE(arg) (sizeof(struct twnotify) - sizeof(union twnotify_data) + sizeof(struct twnotify_##arg))
#define TWNOTIFY_SIZE (sizeof(struct twnotify))

//#define TWNOTIFY_ADDSTRING(ptr, type, data) strcpy((char *)ptr + TWNOTIFY_SIZE(type), data)

#define TWNOTIFY_GETSTRING(ptr, offset) ( ptr->offset ? ((char*)ptr + ptr->offset) : 0 )


#endif // __TWNOTIFY_H__
