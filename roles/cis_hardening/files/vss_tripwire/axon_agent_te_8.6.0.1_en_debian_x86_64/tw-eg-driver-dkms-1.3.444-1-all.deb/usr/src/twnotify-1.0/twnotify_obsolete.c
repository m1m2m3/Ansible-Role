/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2009 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */




#undef MY_NAME
#define MY_NAME "twnotify_obsolete"




static inline pte_t *lookup_address(unsigned long address)
{
	pgd_t *pgd = pgd_offset_k(address);
	pud_t *pud;
	pmd_t *pmd;
	pte_t *pte;
	if (pgd_none(*pgd))
		return NULL;
	pud = pud_offset(pgd, address);
	if (!pud_present(*pud))
		return NULL;
	pmd = pmd_offset(pud, address);
	if (!pmd_present(*pmd))
		return NULL;
	if (pmd_large(*pmd))
		return (pte_t *)pmd;
	pte = pte_offset_kernel(pmd, address);
	if (pte && !pte_present(*pte))
		pte = NULL;
	return pte;
}




static struct page *deferred_pages; // protected by init_mm.mmap_sem


static inline void save_page(struct page *fpage)
{
	fpage->lru.next = (struct list_head *)deferred_pages;
	deferred_pages = fpage;
}

//
// No more special protections in this 2/4MB area - revert to a
// large page again.
//

static void revert_page(unsigned long address, pgprot_t ref_prot)
{
	pgd_t *pgd;
	pud_t *pud;
	pmd_t *pmd;
	pte_t large_pte;

	pgd = pgd_offset_k(address);
	BUG_ON(pgd_none(*pgd));
	pud = pud_offset(pgd,address);
	BUG_ON(pud_none(*pud));
	pmd = pmd_offset(pud, address);
	BUG_ON(pmd_val(*pmd) & _PAGE_PSE);
	pgprot_val(ref_prot) |= _PAGE_PSE;
	large_pte = mk_pte_phys(__pa(address) & LARGE_PAGE_MASK, ref_prot);
	set_pte((pte_t *)pmd, large_pte);
}



static struct page *split_large_page(unsigned long address, pgprot_t prot,
				     pgprot_t ref_prot)
{
	int i;
	unsigned long addr;
	struct page *base = alloc_pages(GFP_KERNEL, 0);
	pte_t *pbase;
	if (!base)
		return NULL;

//	 * page_private is used to track the number of entries in
//	 * the page table page have non standard attributes.

	SetPagePrivate(base);
	page_private(base) = 0;

	address = __pa(address);
	addr = address & LARGE_PAGE_MASK;
	pbase = (pte_t *)page_address(base);
	for (i = 0; i < PTRS_PER_PTE; i++, addr += PAGE_SIZE) {
		pbase[i] = pfn_pte(addr >> PAGE_SHIFT,
				   addr == address ? prot : ref_prot);
	}
	return base;
}




static inline void my_set_pte(pte_t *dst, pte_t val)
{
	printk( "set_pte  \n");
//	mm_track_pte(dst);
	pte_val(*dst) = pte_val(val);
}



static int x__change_page_attr( unsigned long address, unsigned long pfn, pgprot_t prot, pgprot_t ref_prot)
{
	pte_t *kpte;
	struct page *kpte_page;
	unsigned kpte_flags;
	pgprot_t ref_prot2;

	printk( "__cpa: addr = 0x%lx, pfn = 0x%lx, prot = 0x%lx, ref_prot = 0x%lx \n", address, pfn, prot.pgprot, ref_prot.pgprot);

	kpte = lookup_address(address);
	if (!kpte)
	{
		printk( "   lookup addr failed \n");
		return 0;
	}

	kpte_page = virt_to_page( ((unsigned long)kpte) & PAGE_MASK);

	kpte_flags = pte_val(*kpte);

	if (pgprot_val(prot) != pgprot_val(ref_prot))
	{
		if ((kpte_flags & _PAGE_PSE) == 0)
		{
			printk( "   case1a: \n" );
			printk( "   case1a: set_pte: kpte = 0x%lx, pfnpte = 0x%lx \n", kpte->pte, pfn_pte(pfn, prot).pte );
			set_pte( kpte, pfn_pte(pfn, prot));
		}
		else
		{
 			/*
			 * split_large_page will take the reference for this
			 * change_page_attr on the split page.
 			 */

			struct page *split;
			printk( "   case1b: \n" );
			ref_prot2 = __pgprot(pgprot_val(pte_pgprot(*lookup_address(address))) & ~(1<<_PAGE_BIT_PSE));

			split = split_large_page(address, prot, ref_prot2);
			if (!split)
				return -ENOMEM;
			set_pte(kpte,mk_pte(split, ref_prot2));
			kpte_page = split;
		}
		page_private(kpte_page)++;
	}
	else if ((kpte_flags & _PAGE_PSE) == 0)
	{
		printk( "   case2: \n" );
		printk( "   case2: private = 0x%lx, set_pte: kpte = 0x%lx, pfnpte = 0x%lx \n", page_private(kpte_page), kpte->pte, pfn_pte(pfn, prot).pte );

		my_set_pte( kpte, pfn_pte( pfn, ref_prot) );

		printk( "   case2: private = 0x%lx, set_pte: kpte = 0x%lx, pfnpte = 0x%lx \n", page_private(kpte_page), kpte->pte, pfn_pte(pfn, prot).pte );

//		BUG_ON( page_private(kpte_page) == 0 );
//		page_private(kpte_page)--;
	}
	else
	{
		printk( "   case3: \n" );
		BUG();
	}

	/* on x86-64 the direct mapping set at boot is not using 4k pages */

	printk( "   reserved = %d \n", PageReserved(kpte_page) );
// 	BUG_ON( PageReserved(kpte_page) );

	if( page_private(kpte_page) == 0)
	{
		printk( "   saving: \n" );
		printk( "   saving: 0x%lx, reverting: 0x%lx, 0x%lx", (unsigned long)kpte_page, address, ref_prot.pgprot);
		save_page(kpte_page);
		revert_page(address, ref_prot);
 	}


	return 0;
}





int dummy( unsigned long address )
{
	printk( "dummy \n");
	return 0;
}



int xxxchange_page_attr_addr( unsigned long address, int numpages, pgprot_t prot)
{
	int err = 0;
	int i;

	printk( "cpaa   \n");

	down_write(&init_mm.mmap_sem);

	for (i = 0; i < numpages; i++, address += PAGE_SIZE)
	{
		unsigned long pfn = __pa(address) >> PAGE_SHIFT;

		err = x__change_page_attr(address, pfn, prot, PAGE_KERNEL);
		if (err)
			break;
		/* Handle kernel mapping too which aliases part of the
		 * lowmem */
		if (__pa(address) < KERNEL_TEXT_SIZE)
		{
			unsigned long addr2;
			pgprot_t prot2 = prot;

			printk( "xcpa: addr < kernel_text_size \n");
			addr2 = __START_KERNEL_map + __pa(address);
 			pgprot_val(prot2) &= ~_PAGE_NX;
			err = x__change_page_attr(addr2, pfn, prot2, PAGE_KERNEL_EXEC);
		}
	}

	up_write(&init_mm.mmap_sem);
	return err;
}


/*
int xxxchange_page_attr( struct page *page, int numpages, pgprot_t prot)
{
	int err = 0;
	unsigned long addr = 0;

	printk( "cpa  &err=0x%p \n", &err);

//	addr = (unsigned long)page_address(page);

	printk( "cpa2  &err=0x%p, addr=0x%lx \n", &err, addr);

	return 0;

	err = dummy( addr ); //addr, numpages, prot);
//	err = xxxchange_page_attr_addr( addr, numpages, prot);

	return err;
}
*/


