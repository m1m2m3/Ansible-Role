/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/security.h>
#include <linux/usb.h>
#include <linux/string.h>
#include <linux/syscalls.h>
#include <asm/page.h>
#include <asm/pgtable.h>
#include <asm/cacheflush.h>
#include <linux/compat.h>
#include <asm/unistd.h>
#include <linux/types.h>
#include <linux/delay.h>
#include <linux/highuid.h>
#ifdef CONFIG_KDB
#include <linux/kdb.h>
#endif
#include <asm/mman.h>

#ifdef KERNEL_GT_2_6_17
#include <linux/sysfs.h>
#include <linux/kobject.h>
#endif

// needed for shadow page table code
#include <asm/page.h>
#include <asm/cacheflush.h>
#include <linux/vmalloc.h>

#include "twnotify_main.h"
#include "twnotify.h"
#include "twnotify_handlers.h"
#include "twnotify_utils.h"
#include "twnotify_user.h"

// Syscall definitions for 64-bit stuff:
#include "ia32stuff.c"



/*****************************************************************************
*
* Module parameters
*
*****************************************************************************/

// printk level enables...

int spew = 0;
module_param( spew, int, 0600);
MODULE_PARM_DESC( spew, "Verbose kernel output enabled or not");

int spewuser = 0;
module_param( spewuser, int, 0600);
MODULE_PARM_DESC( spewuser, "Verbose kernel output for user module enabled or not");

int debug = 0;
module_param( debug, int, 0600);
MODULE_PARM_DESC( debug, "Debug kernel output enabled or not");

int warn = 1;
module_param( warn, int, 0600);
MODULE_PARM_DESC( warn, "Warning kernel output enabled or not");

// address of the sys_call_table
// should be set, but we will try a few hardcoded locations if it is not
static ulong syscall_addr = 0;
module_param( syscall_addr, ulong, 0400);
MODULE_PARM_DESC(syscall_addr, "Sys call table address");

// address of the ia32 sys_call_table on 64b
static ulong ia32syscall_addr = 0;
module_param( ia32syscall_addr, ulong, 0400);
MODULE_PARM_DESC( ia32syscall_addr, "ia32 Sys call table address");

// Address of the beginning of the rodata section in the kernel (__start_rodata symbol)
static ulong start_rodata_addr = 0;
module_param( start_rodata_addr, ulong, 0400);
MODULE_PARM_DESC( start_rodata_addr, "__start_rodata address");

// Address of the end of the rodata section in the kernel (__end_rodata symbol)
static ulong end_rodata_addr = 0;
module_param( end_rodata_addr, ulong, 0400);
MODULE_PARM_DESC( end_rodata_addr, "__end_rodata address");

// Address of the end of the phys_base variable in the kernel (phys_base symbol)
static ulong phys_base_addr = 0;
module_param( phys_base_addr, ulong, 0400);
MODULE_PARM_DESC( phys_base_addr, "phys_base address");

// other test/debug flags
int nommap = 1;
module_param( nommap, int, 0600);
MODULE_PARM_DESC( nommap, "Disable mmap handling");

int ignorespecial = 1;
module_param( ignorespecial, int, 0600);
MODULE_PARM_DESC( ignorespecial, "Ignore special files");

// some older kernels don't have this defined:
#ifndef DIV_ROUND_UP
#define DIV_ROUND_UP(n,d) (((n) + (d) - 1) / (d))
#endif

#if defined(__powerpc64__) || defined(UEK_3_OR_GREATER)
  #define DIRECT_SYSCALL_HOOKING
#endif

/*****************************************************************************
*
* Other misc variables
*
*****************************************************************************/

// ptr to native sys call table
void **sys_call_table = NULL;

// ptr to ia32 sys call table on 64b
void **ia32sys_call_table = NULL;

// offset between actual syscall table and the shadow
static long rwshadow_offset = 0;

// Variables used by all files
int bypass_mode = 1;
int write_interval = 30 * HZ;  // kept in jiffies
int version = TWNOTIFY_VERSION;
int ishooked = 0;

// re-set our name

#undef MY_NAME
#define MY_NAME "twnotify"

/*****************************************************************************
*
* FUNCTION: is_readable_address( )
*
*****************************************************************************/

static int is_readable_address(void *iaddress, int length)
{

#ifndef __powerpc64__

#ifndef KERNEL_GT_2_6_24
    // For kernels < 2.6.24, we still do this the old tried and true way.
    //  Later kernels we use the inline assembly override of the CR bit and just return 1 here.

    unsigned long address = (unsigned long )iaddress;
    pgd_t *pgd = pgd_offset_k(address);
#ifdef PUD_SIZE
    pud_t *pud;
#endif
    pmd_t *pmd;
    pte_t *pte;

    if (pgd_none(*pgd))
        return -1;
#ifdef PUD_SIZE
    pud = pud_offset(pgd, address);
    if (pud_none(*pud))
        return -1;
    pmd = pmd_offset(pud, address);
#else
    pmd = pmd_offset(pgd, address);
#endif
    if (pmd_none(*pmd))
        return -1;

    if (pmd_large(*pmd))
        pte = (pte_t *)pmd;
    else
        pte = pte_offset_kernel(pmd, address);

    if (!pte || !pte_present(*pte))
        return -1;

#endif // ifndef KERNEL_GT_2_6_24
#endif // __powerpc64__

    return 1;
}

/*****************************************************************************
*
* FUNCTION: make_writable_page_mappings( )
*
*****************************************************************************/

#ifndef DIRECT_SYSCALL_HOOKING

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,16) && LINUX_VERSION_CODE < KERNEL_VERSION(2,6,22) && defined(CONFIG_64BIT)
    // 64 bit kernels after 2.6.16 and prior to 2.6.22 (RHEL Backport of relocatable kernel) have a bug in
    //   virt_to_page, so we use the pfn_to_page macro in this case (for older 64 bit kernels):
#undef  virt_to_page
#define virt_to_page(page_address) (pfn_to_page( __pa_symbol(page_address) >> PAGE_SHIFT))

// only need to supply our own if not xen kernel
#ifndef CONFIG_XEN
#define NEED_PHYSBASE
// the macro above indirectly references the kernel variable phys_base
// module local var (hidden in kernel), this is initialized in init if needed
unsigned long phys_base = 0;
#endif

#endif

void * make_writable_page_mappings( void *address, size_t len )
{
    void *virt_address = NULL;
    int num_pages = 0;
    struct page **pages = NULL;
    void *page_address = NULL;
    int i = 0;

    num_pages = DIV_ROUND_UP( offset_in_page(address) + len, PAGE_SIZE );
    pages = kmalloc( num_pages * sizeof(*pages), GFP_KERNEL );
    page_address = (void *)((unsigned long)address & PAGE_MASK);
    // alloc check:
    if( pages == NULL )
    {
        return NULL;
    }
    // loop through, grab page table entries
    for (i = 0; i < num_pages; i++)
    {
        pages[i] = virt_to_page( page_address );

        WARN_ON(!PageReserved(pages[i]));

        //  This vmalloc to page call works on some older and newer 32 bit kernels....
        //pages[i] = vmalloc_to_page( address );

        if( pages[i] == NULL )
        {
            kfree( pages );
            return NULL;
        }
        page_address += PAGE_SIZE;
    }
    virt_address = vmap( pages, num_pages, VM_MAP, PAGE_KERNEL);
    kfree( pages );
    if( virt_address == NULL )
    {
        return NULL;
    }
    return virt_address + offset_in_page( address );
}

#endif // DIRECT_SYSCALL_HOOKING

/*****************************************************************************
*
* FUNCTION: prepare_write( )
*
*****************************************************************************/

int prepare_write( void *addr)
{

#ifndef DIRECT_SYSCALL_HOOKING

    unsigned long rwshadow = 0;
    rwshadow = (unsigned long) make_writable_page_mappings( (void*)start_rodata_addr, end_rodata_addr-start_rodata_addr );

    if( !rwshadow )
    {
        root_spew("prepare_write() FAILED\n");
        return -1;
    }
    rwshadow_offset = rwshadow - start_rodata_addr;

    /*
            This code was too cool to delete... leaving here just in case......

                // This tricky inline assembly will force set the WP bit in the control register (CR)
                DEFINE_SPINLOCK(reg_lock);
                unsigned long flags = 0;

                // save interrupt state, disable interrupts and lock
                //  note that flags isn't really passed by value as spin_lock_irqsave() is a macro
                spin_lock_irqsave( &reg_lock, flags );

                // set the WP bit in the control register
                unsigned long value;
                asm volatile( "mov %%cr0,%0" : "=r" (value) );
                if( value & 0x00010000)
                {
                    value &= ~0x00010000;
                    asm volatile( "mov %0,%%cr0": : "r" (value) );
                }

                // unlock and restore interrupt state:
                spin_unlock_irqrestore( &reg_lock, flags );
    */

    root_spew("prepare_write() succeeded\n");
#endif // DIRECT_SYSCALL_HOOKING
    return 0;
}

/*****************************************************************************
*
* FUNCTION: finalize_write( )
*
*****************************************************************************/

void finalize_write( void *addr, int writable)
{

#ifndef DIRECT_SYSCALL_HOOKING

    // in this case, all we have to do is unmap the virtual memory now that we're done:
    vunmap((void *)( ((unsigned long)(start_rodata_addr + rwshadow_offset)) & PAGE_MASK));

    /*   cool code - keeping here just in case .............
                    // This inline assembly will clear the WP bit in the control register (CR)
                    DEFINE_SPINLOCK( reg_lock );
                    unsigned long flags = 0;

                    // save interrupt state, disable interrupts and lock
                    //  note that flags isn't really passed by value as spin_lock_irqsave() is a macro
                    spin_lock_irqsave( &reg_lock, flags );

                    // clear the WP bit in the control register
                    unsigned long value;
                    asm volatile( "mov %%cr0,%0" : "=r" (value) );
                    if (!(value & 0x00010000))
                    {
                        value |= 0x00010000;
                        asm volatile( "mov %0,%%cr0": : "r" (value) );
                    }

                    // unlock and restore interrupt state:
                    spin_unlock_irqrestore( &reg_lock, flags );
    */

#endif // DIRECT_SYSCALL_HOOKING

}


/*****************************************************************************
*
* FUNCTION: get_table_size( )
*
*****************************************************************************/

static int get_table_size( void)
{
    int ncalls = 0;
    int table_size = 0;

#ifdef NR_syscalls
    ncalls = NR_syscalls;
#else
  #ifdef NR_syscall_max
    ncalls = NR_syscall_max;
  #else
    ncalls = 400;
  #endif
#endif

    table_size = ncalls * sizeof(void *);

    return table_size;
}

/*****************************************************************************
*
* FUNCTION: verify_table( )
*
*****************************************************************************/

static int verify_table( void** tab, int idx)
{
    void *pClose = NULL;
    int rd = -1;
    int tabsize = get_table_size();

    if( tab == NULL)
        return -3;

    root_dbg( "trying: %p...\n", tab);
    rd = is_readable_address( tab, tabsize);
    root_dbg( "   rd=%d \n", rd);

    if( rd != 1 )
    {
        root_dbg( "  read failed \n" );
	return -2;
    }

    root_dbg( "  read success \n" );

#ifdef __powerpc64__
    // PPC64 has the syscall table layed out interleaved with 32 bit compatibility
    //  entry points, so the index into the table itself needs to be doubled:
    idx = idx * 2;

    // Also, on PPC the sys_close symbol is really a function descriptor address, so to verify
    //   the code entry point from the table, we need to dereference that to get the actual
    //   address that matches the entry from the syscall table itself

    pClose = *((void**)(sys_close));
#else
    pClose = sys_close;
#endif
    if( tab[idx] != pClose)
    {
      printk("twnotify: Expected sys_close (%p) but got %p instead. Something else has hooked the syscall table!\n", pClose, tab[idx]);
      printk("twnotify: If %p does not belong to a legitimate kernel module's address space, this may be evidence of a rootkit.\n", tab[idx]);
    }

    printk("twnotify:verify_table sys_close=%p *sys_close=%p\n", sys_close, *((void**)sys_close) );

    return 0;
}


/*****************************************************************************
*
* FUNCTION: verify_tables( )
*
*****************************************************************************/

static int verify_tables( void)
{
    int err = 0;

    err = verify_table( sys_call_table, __NR_close);
    if( err)
        return err;


#ifdef CONFIG_64BIT
#ifndef __powerpc64__
    // Only for 64-bit Intel platforms:
    err = verify_table( ia32sys_call_table, __NR32_close);
    if( err)
        return err;
        #endif
#endif

    return 0;
}

/**
 * Initialize the sys_call_table and ia32sys_call_table variables using the provided module
 * parameter.
 */

static void setup_syscall_tables(void)
{
    // Assign our internal variable to the value passed in to the module parameter:
    sys_call_table = (void*)syscall_addr;
    ia32sys_call_table = (void*)ia32syscall_addr;

#ifdef __powerpc64__
    // The PPC64 sys_call_table exported symbol is really address of a pointer to the table,
    //    not the address of the table itself, so we dereference that pointer here
    sys_call_table = (void**)(*sys_call_table);

    // This is tricky and hacky, but prevents a lot more worse hackiness. On PPC64 there isn't
    //   really a separate 32-bit syscall table.  The system call table is interleaved with
    //   one entry for 64-bit calling processes then the next entry for 32-bit processes.  This
    //   trick will allow the doubled indexing in teh hooking code to work for 32-bit handlers
    //   as well.
    ia32sys_call_table = sys_call_table + 1;
#endif
}


/*****************************************************************************
*
* FUNCTION: do_hook( )
*
*****************************************************************************/


static int do_hook( void** sys_call_table, char* name, int idx, funcptr* savefunc, funcptr newfunc)
{
    unsigned long target = 0;

#ifdef __powerpc64__
    // The PPC 64 bit syscall table has interleaved entries for the 64 then 32-bit entry points.
    //   This mens we multiply the index by 2 for the 64-bit one, then add 1 for the index ofthe 32-bit one.
    idx = idx * 2;
    // We also have to de-reference the function pointer passed in in this weird way in order to
    //  get the actual code address of our handler function in place.  This is because of the indirected
    //  'function desscriptor' calling convention on power.  The compiler will generate the address of our
    //  function descriptor for our handler based on the symbol, but we need the actual code address to stick
    //  in the syscall table.

    root_dbg( "do_hook: newfunc=%p *newfunc=%p\n", newfunc, (funcptr)(*((unsigned long*)(newfunc))) );

    newfunc = (funcptr)(*((unsigned long*)(newfunc)));
#endif

    root_spew( "do_hook sys_call_table=%p name=%s idx=%d newfunc=%p\n", sys_call_table, name, idx, newfunc );

    if( sys_call_table[idx] == newfunc)
    {
        root_err("system call %s already hooked, skipping\n", name);
        return -1;
    }

    // store off the old value from the table:
    *savefunc = sys_call_table[idx];

#ifdef DIRECT_SYSCALL_HOOKING
    // poke the new value into the table (PPC)
    sys_call_table[idx] = newfunc;
#else
    // poke the new value into the re-mapped shadow table (intel arch)
    target = (unsigned long)(&sys_call_table[idx]);
    target += rwshadow_offset;
    *(void **)target = newfunc;
#endif

    root_dbg( "hooked %s \n", name);
    return 0;
}


/*****************************************************************************
*
* FUNCTION: do_unhook( )
*
*****************************************************************************/

static void do_unhook( void ** sys_call_table, char* name, int idx, funcptr* savefunc, funcptr newfunc)
{
    unsigned long target = 0;

#ifdef __powerpc64__
    // The PPC 64 bit syscall table has interleaved entries for the 64 then 32-bit entry points.
    //   This mens we multiply the index by 2 for the 64-bit one, then add 1 for the index ofthe 32-bit one.
    idx = idx * 2;
    // We also have to de-reference the function pointer passed in in this weird way in order to
    //  get the actual code address of our handler function in place.  This is because of the indirected
    //  'function desscriptor' calling convention on power.  The compiler will generate the address of our
    //  function descriptor for our handler based on the symbol, but we need the actual code address to stick
    //  in the syscall table.
    root_dbg( "do_unhook: newfunc=%p *newfunc=%p\n", newfunc, (funcptr)(*((unsigned long*)(newfunc))) );
    newfunc = (funcptr)(*((unsigned long*)(newfunc)));
#endif

    root_spew( "do_unhook sys_call_table=%p name=%s idx=%d newfunc=%p\n", sys_call_table, name, idx, newfunc );

    if( *savefunc == NULL)
    {
        root_err( "no saved hook for system call %s, skipping\n", name);
        return;
    }

    if( sys_call_table[idx] == *savefunc)
    {
        root_err( "system call %s already unhooked, skipping\n", name);
        // fall through
    }


    if( sys_call_table[idx] != newfunc)
    {
        root_err( "system call %s has been changed (system may be left in an unstable state!)\n", name);
    }

#ifdef DIRECT_SYSCALL_HOOKING
    // PPC just replace the value:
    sys_call_table[idx] = *savefunc;
#else
    // Intel use teh shadow address to replace teh value:
    target = (unsigned long)(&sys_call_table[idx]);
    target += rwshadow_offset;
    *(void **)target = *savefunc;
#endif // DIRECT_SYSCALL_HOOKING


    *savefunc = NULL;
    root_dbg( "unhooked %s \n", name);
}


/*****************************************************************************
*
* New hook table (one entry for both hook and unhook, native and 32b emulation
*
*****************************************************************************/


#ifdef CONFIG_64BIT

#ifndef __powerpc64__

//////  INTEL x86_64

// for Intel x86_64 64bit, some are the same impl, just diff numbers

// This variant is for same exact Intel handler for 32 and 64 bit tables:
#define HOOKENT(syscall)                \
{                                       \
    #syscall,                           \
    __NR_##syscall,                     \
    (funcptr*)&original_sys_##syscall,  \
    (funcptr)twnotify_sys_##syscall,    \
    __NR32_##syscall,                   \
    (funcptr*)&original32_sys_##syscall,\
    (funcptr)twnotify_sys_##syscall,    \
}

// This 'a' version is for cases where the 32-bit handler is different than
//   the 64-bit one (note the twnotify32_sys_##syscall at the end)
#define HOOKENTa(syscall)               \
{                                       \
    #syscall,                           \
    __NR_##syscall,                     \
    (funcptr*)&original_sys_##syscall,  \
    (funcptr)twnotify_sys_##syscall,    \
    __NR32_##syscall,                   \
    (funcptr*)&original32_sys_##syscall,\
    (funcptr)twnotify32_sys_##syscall,  \
}

// This 'b' version is used where there is no handler for the 64-bit, only for
//   compatibility with 32-bit processes (e.g. truncate64)
#define HOOKENTb(syscall)               \
{                                       \
    #syscall,                           \
    -1,                                 \
    NULL,                               \
    NULL,                               \
    __NR32_##syscall,                   \
    (funcptr*)&original32_sys_##syscall,\
    (funcptr)twnotify32_sys_##syscall,  \
}

#else // __powerpc64__

///// Power PC

// For PPC we have a slightly different situation than x86_64.  With the interleaved syscall
//   table, there is always a 32 and 64 bit entry point.  There are still cases where
//   we know there are no 64-bit versions of calls (e.g. truncate64 can only be called from
//   a 32-bit application, so the 64-bit slot is never actually used), but we handle them all
//   the same way with separate twnotify32_ppc_sys_xxxx for every one.
//
//   So, the different case handling that we end up doing for Intel isn't necessary on PPC
//   because there are distinct slots for each one.
//
//   The struct hookent is also different in order to hold the kernel TOC address so we can
//   use the stored safefuc value address as a function descriptor


#define HOOKENT(syscall)                        \
{                                               \
    #syscall,                                   \
    __NR_##syscall,                             \
    (funcptr*)&original_sys_##syscall,          \
    (funcptr)(twnotify_ppc_sys_##syscall),      \
    __NR_##syscall,                             \
    (funcptr*)&original32_sys_##syscall,        \
    (funcptr)(twnotify32_ppc_sys_##syscall),    \
    NULL,                                       \
    NULL,                                       \
    NULL,                                       \
    NULL,                                       \
    NULL,                                       \
    NULL,                                       \
}

#define HOOKENTa(syscall)   HOOKENT(syscall)
#define HOOKENTb(syscall)   HOOKENT(syscall)

#endif // __powerpc64__


#else
// for 32bit Intel these are all the same

#define HOOKENT(syscall)                \
{                                       \
    #syscall,                           \
    __NR_##syscall,                     \
    (funcptr*)&original_sys_##syscall,  \
    (funcptr)twnotify_sys_##syscall,    \
    -1,                                 \
    NULL,                               \
    NULL,                               \
}

#define HOOKENTa(syscall)   HOOKENT(syscall)
#define HOOKENTb(syscall)   HOOKENT(syscall)


#endif


#ifndef __powerpc64__
// Hook entry structure definition for Intel
struct hookent {
    char*       name;
    int         idx;
    funcptr*    savefunc;
    funcptr     newfunc;
    int         idx2;
    funcptr*    savefunc2;
    funcptr     newfunc2;
};
#else
// Hook entry structure definition for PPC - note additional kernel_toc members
struct hookent {
    char*       name;
    int         idx;
    funcptr*    savefunc;
    funcptr     newfunc;
    int         idx2;
    funcptr*    savefunc2;
    funcptr     newfunc2;
    funcptr     funcdesc64;
    void*       kernel_toc;
    void*       kernel_penv;
    funcptr     funcdesc32;
    void*       kernel_toc_32;
    void*       kernel_penv_32;
};

#endif

// Table of hooked entries by name using the hookent struct macros to initialize
struct hookent hooktab[] = {

// This #if is here for development debug purposes only - hook JUST chmod for testing
#if 0  // 1

    HOOKENTa  ( open        ),
    HOOKENT   ( chmod       ),
    HOOKENT   ( fchmodat    ),
    HOOKENT   ( close       ),


#else

    // The read table of all syscalls we hook:
    HOOKENT   ( creat       ),
    HOOKENTa  ( open        ),
    HOOKENTa  ( openat      ),
    HOOKENT   ( mkdir       ),
    HOOKENT   ( mkdirat     ),
    HOOKENT   ( rmdir       ),
    HOOKENT   ( mknod       ),
    HOOKENT   ( mknodat     ),
    HOOKENT   ( link        ),
    HOOKENT   ( linkat      ),
    HOOKENT   ( unlink      ),
    HOOKENT   ( unlinkat    ),
    HOOKENT   ( symlink     ),
    HOOKENT   ( symlinkat   ),

    HOOKENT   ( rename      ),
    HOOKENT   ( renameat    ),

    HOOKENTa  ( pwrite64    ),
    HOOKENT   ( write       ),
    HOOKENTa  ( writev      ),
    HOOKENT   ( truncate    ),
    HOOKENT   ( ftruncate   ),

#ifdef KERNEL_GT_2_6_17
    // Splice was introduced in 2.6.17, but we still support 2.6.16.60 for SuSE 10.2 and 10.3
    HOOKENT   ( splice   ),
#endif // KERNEL_GT_2_6_17

#ifdef KERNEL_GT_2_6_30
    // new syscall introduced in 2.6.30 can produce a write event
    HOOKENTa  ( pwritev     ),
#endif // KERNEL_GT_2_6_30

#ifdef KERNEL_GT_2_6_39
    HOOKENTa  ( open_by_handle_at ),
#endif //KERNEL_GT_2_6_39

#ifndef __powerpc64__
// The following are not implemented in 64-bit PPC at all:

    HOOKENTb  ( truncate64  ),
    HOOKENTb  ( ftruncate64 ),
    HOOKENTb  ( chown32     ),
    HOOKENTb  ( fchown32    ),
    HOOKENTb  ( lchown32    ),

#endif // __powerpc64__

    HOOKENT   ( chmod       ),
    HOOKENT   ( fchmod      ),
    HOOKENT   ( fchmodat    ),
    HOOKENTa  ( chown       ),
    HOOKENTa  ( fchown      ),
    HOOKENT   ( fchownat    ),
    HOOKENTa  ( lchown      ),


    HOOKENTa  ( utime       ),
    HOOKENTa  ( utimes      ),
    HOOKENTa  ( futimesat   ),

#ifdef KERNEL_GT_2_6_24  // originally implemented in 2.6.22, but 24 is good for our purposes....
    HOOKENTa  ( utimensat   ),
#endif

    HOOKENT   ( fremovexattr),
    HOOKENT   ( fsetxattr   ),
    HOOKENT   ( lremovexattr),
    HOOKENT   ( lsetxattr   ),
    HOOKENT   ( removexattr ),
    HOOKENT   ( setxattr    ),


    HOOKENTa  ( mount       ),
    HOOKENTb  ( umount      ),
    HOOKENTa  ( umount2     ),

    HOOKENT   ( close       ),

#endif

    { 0 },  // must be last
};

/*****************************************************************************
*
* FUNCTION: fixup_ppc_function_descriptors( )
*
*****************************************************************************/

#ifdef __powerpc64__

void fixup_ppc_function_descriptors( void )
{
    struct hookent* p = NULL;
    unsigned long * pfuncdesc = (unsigned long*) ((void**)(sys_close));
    saved_kernel_r2 = (unsigned long)pfuncdesc[1];

    printk( "fixup_ppc_function_descriptors kernel_r2 = %p\n", (void*)saved_kernel_r2 );

    p = hooktab;
    // loop through and pre-load all of the hookent function descriptors with
    //   the known kernel R2 value for the toc entry:
    while( p->name)
    {
        p->kernel_toc = (unsigned long*)saved_kernel_r2;
        p->kernel_toc_32 = (unsigned long*)saved_kernel_r2;
        p++;
    }
    root_spew( "fixup_ppc_function_descriptors DONE.\n" );

}

#endif

/*****************************************************************************
*
* FUNCTION: hookunhook
*
*****************************************************************************/

static int hookunhook( struct hookent* hooktab, void** sys_call_table, int hook)
{
    struct hookent* p = NULL;
    int err = 0;

    // NOTE for PPC64:  This works for both 64 and 32-bit compatibility interfaces
    //   because ia32_sys_call_table variable is set to the address of the first interleaved
    //   32bit compatibility (sys_call_table + 1) and the hook code doubles the index
    //
    // NOTE for 32-bit x86 - this works for 32-bit only Intel because the hooktab entries
    //   of the struct hookent contain -1 for the p->idx2 value

#ifndef __powerpc64__
    // Intel version:

    p = hooktab;
    while( p->name)
    {
        if( hook)
        {
            if( p->idx != -1)
            {
                err = err | do_hook( sys_call_table, p->name, p->idx, p->savefunc, p->newfunc);
            }
            if( p->idx2 != -1)
            {
                err = err | do_hook( ia32sys_call_table, p->name, p->idx2, p->savefunc2, p->newfunc2);
            }
        }
        else
        {
            if( p->idx != -1)
            {
                do_unhook( sys_call_table, p->name, p->idx, p->savefunc, p->newfunc);
            }
            if( p->idx2 != -1)
            {
                do_unhook( ia32sys_call_table, p->name, p->idx2, p->savefunc2, p->newfunc2);
            }
        }
        p++;
    }

#else
    // PPC version - some special handling to deal with function descriptors
    p = hooktab;
    while( p->name)
    {
        if( hook)
        {
            if( p->idx != -1)
            {
                err = err | do_hook( sys_call_table, p->name, p->idx, p->savefunc, p->newfunc);
                // now create the function descriptor to call through:
                p->funcdesc64 = (funcptr) *p->savefunc;
                *p->savefunc = (funcptr) (&(p->funcdesc64));
                root_dbg( "hook: p=%p p->funcdesc64=%p *p->savefunc=%p  &p->funcdesc64=%p\n", p, p->funcdesc64, *p->savefunc, &p->funcdesc64 );
            }
            if( p->idx2 != -1)
            {
                err = err | do_hook( ia32sys_call_table, p->name, p->idx2, p->savefunc2, p->newfunc2);
                // now create the function descriptor to call through:
                p->funcdesc32 = (funcptr) *p->savefunc2;
                *p->savefunc2 = (funcptr) (&(p->funcdesc32));
                root_dbg( "hook: p->funcdesc32=%p *p->savefunc2=%p\n", p->funcdesc32, *p->savefunc2 );
            }
            root_spew( "hookent data:\n"
                    "  p->name             = %s\n"
                    "  p->idx              = %d\n"
                    "  p->savefunc         = %p\n"
                    "  p->newfunc          = %p\n"
                    "  p->idx2             = %d\n"
                    "  p->savefunc2        = %p\n"
                    "  p->newfunc2         = %p\n"
                    "  p->funcdesc64       = %p\n"
                    "  p->kernel_toc       = %p\n"
                    "  p->kernel_penv      = %p\n"
                    "  p->funcdesc32       = %p\n"
                    "  p->kernel_toc_32    = %p\n"
                    "  p->kernel_penv_32   = %p\n",
                    p->name, p->idx, p->savefunc, p->newfunc, p->idx2, p->savefunc2, p->newfunc2, p->funcdesc64, p->kernel_toc,
                    p->kernel_penv, p->funcdesc32, p->kernel_toc_32, p->kernel_penv_32 );
        }
        else
        {
            if( p->idx != -1)
            {
                // before calling do_unhook() we need to replace the value at p->savefunc to have the value
                //   that came from the syscall table originally:
                *p->savefunc = (funcptr)p->funcdesc64;
                root_dbg( "unhook: restored *p->savefunc to %p\n", *p->savefunc );
                do_unhook( sys_call_table, p->name, p->idx, p->savefunc, p->newfunc);

            }
            if( p->idx2 != -1)
            {
                // before calling do_unhook() we need to replace the value at p->savefunc2 to have the value
                //   that came from the syscall table originally:
                *p->savefunc2 = (funcptr)p->funcdesc32;
                root_dbg( "unhook: restored *p->savefunc2 to %p\n", *p->savefunc2 );
                do_unhook( ia32sys_call_table, p->name, p->idx2, p->savefunc2, p->newfunc2);
            }
        }
        p++;
    }

#endif

    return err;
}

/**
 * Validate that the given entry in the given syscall table matches the
 * expected value.
 *
 * Returns true (1) if valid, 0 if invalid.
 */
static int validate_table_entry(void **table, int entry, funcptr expected)
{
#ifdef __powerpc64__
    entry *= 2;
    expected = (funcptr)(*((unsigned long*)(expected)));
#endif // __powerpc64__

    return (table[entry] == expected);
}

/**
 * Given a syscall table pointer and an entry number, get the requested entry.
 */
static void *get_syscall_table_entry(void **table, int entry)
{
#ifdef __powerpc64__
    entry *= 2;
#endif
    return table[entry];
}

#ifdef CONFIG_64BIT
#define PRIMARY_HOOK_TYPE "64-bit"
#define SECONDARY_HOOK_TYPE "32-bit"
#else
#define PRIMARY_HOOK_TYPE "32-bit"
#endif

/**
 * Perform an integrity check on the specified hook. If the hook is no longer in place in the syscall table,
 * write its name and address to the supplied buffer.
 *
 * Returns the number of bytes written to the buffer.
 */
static ssize_t hook_integrity_check(struct hookent *hook, char *buf, ssize_t bytesAlreadyWritten)
{
    ssize_t bytesWritten = 0;
    ssize_t bytesRemaining = PAGE_SIZE - bytesAlreadyWritten - 1;
    root_dbg("hook_integrity_check: checking %s. Bytes remaining: %zd\n", hook->name, bytesRemaining);

    if(hook->idx != -1 && !validate_table_entry(sys_call_table, hook->idx, hook->newfunc))
    {
      bytesWritten = snprintf(buf, bytesRemaining, "%s (%s):%p\n", hook->name, PRIMARY_HOOK_TYPE, get_syscall_table_entry(sys_call_table, hook->idx));
      // move the buffer pointer
      bytesRemaining -= bytesWritten;
      buf += bytesWritten;
    }
#ifdef CONFIG_64BIT
    if(hook->idx2 != -1 && !validate_table_entry(ia32sys_call_table, hook->idx2, hook->newfunc2) && bytesRemaining > 0)
    {
      bytesWritten += snprintf(buf, bytesRemaining, "%s (%s):%p\n", hook->name, SECONDARY_HOOK_TYPE, get_syscall_table_entry(ia32sys_call_table, hook->idx2));
    }
#endif
    root_dbg("hook_integrity_check: wrote %zd bytes\n", bytesWritten);
    return bytesWritten;
}

/**
 * Write a list of our hooks that have been overwritten by something else.
 *
 * buf is passed in from sysfs and is guaranteed to be PAGE_SIZE in length.
 * https://www.kernel.org/doc/Documentation/filesystems/sysfs.txt ("Reading/Writing Attribute Data")
 */
static ssize_t list_overwritten_hooks(char *buf)
{
    struct hookent *hook = NULL;
    ssize_t totalBytesWritten = 0;

    if(!ishooked) {
      return -1;
    }

    for(hook = hooktab; hook->name != NULL; hook++)
    {
        ssize_t bytesWritten = hook_integrity_check(hook, buf, totalBytesWritten);
        totalBytesWritten += bytesWritten;
        buf += bytesWritten;
    }

    // if at least one line has been written, append instructions for how to tell what has
    // overwritten twnotify's syscall hooks.
    if(totalBytesWritten > 0) {
        totalBytesWritten += snprintf(buf, (PAGE_SIZE - totalBytesWritten), "\nExamine /proc/modules to identify which modules have overwritten Tripwire's system call hooks.\n");
    }

    return totalBytesWritten;
}

/*****************************************************************************
*
* FUNCTION: hook_all
*
* 1. Do a sanity check of the current state of the syscall table
* 2. Make the page of memory containing the syscall table writable
* 3. Do the hooking
*
* hooktab is defined via the HOOKENT macros above.
* sys_call_table is initialized in setup_syscall_tables()
*
* Returns 0 on success, non-zero on error
*
*****************************************************************************/

static int  hook_all( void)
{
    int err = 0;
    int writable = 0;

    root_dbg( "verifying syscall table(s)...\n");

    err = verify_tables( );

    if( err == 0)
    {
        root_dbg("hooking...\n");
        writable = prepare_write( &sys_call_table[0] );
        if( writable >= 0 )
        {
            err = hookunhook( hooktab, sys_call_table, 1);
            root_dbg("hooking done: %d \n", err);
        }
        else
        {
            root_err("cannot hook syscall table\n");
            err = -9;
        }
    }
    else
    {
        root_err("cannot hook syscall table\n");
        err = -9;
    }

    return err;
}


/*****************************************************************************
*
* FUNCTION: unhook_all
*
*****************************************************************************/

static void unhook_all( void)
{
    hookunhook( hooktab, sys_call_table, 0);
    finalize_write( &sys_call_table[0], 1 );
    root_dbg("unhooking done\n");
}
#ifdef KERNEL_GT_2_6_24
static ssize_t twnotify_syscallstate_show(struct kobject *kobj, struct kobj_attribute *attr,
                      char *buf)
{
    return list_overwritten_hooks(buf);
}

static struct kobject *syscallState;
static struct kobj_attribute twnotify_syscallstate_attribute = __ATTR(overwritten_syscall_entries, 0400, twnotify_syscallstate_show, NULL);
#endif

static int init_sysfs(void) {
    int result = 0;

#ifdef KERNEL_GT_2_6_24
    if( (syscallState = kobject_create_and_add("twnotify", NULL)) == NULL) {
        return -ENOMEM;
    }
    printk("twnotify: Successfully created twnotify sysfs kobject.\n");
    
    if( (result = sysfs_create_file(syscallState, &twnotify_syscallstate_attribute.attr)) != 0 ) {
        printk("twnotify: Failed to create sysfs file: %d\n", result);
        kobject_put(syscallState);
        syscallState = NULL;
    }
#endif
    return result;
}

/*****************************************************************************
*
* FUNCTION: twnotify_init( )
*
*****************************************************************************/

static int twnotify_init (void)
{
    int err = 0;

#ifdef __powerpc64__
    // PPC vars used only on PPC
    unsigned long r2, txt;
#endif

    printk( "twnotify: in init \n" );
    printk( "   spew     = %d \n", spew);
    printk( "   spewuser = %d \n", spew);
    printk( "   debug    = %d \n", debug);
    printk( "   warn     = %d \n", warn);
    printk( "   syscall_addr      = 0x%lx \n", syscall_addr);
    printk( "   ia32syscall_addr  = 0x%lx \n", ia32syscall_addr);
    printk( "   start_rodata_addr  = 0x%lx \n", start_rodata_addr);
    printk( "   end_rodata_addr  = 0x%lx \n", end_rodata_addr);
    printk( "   phys_base_addr  = 0x%lx \n", phys_base_addr);


#ifdef CONFIG_KDB
    //brkpoint();
#endif

     // zero out some memory for the smr cache:
    memset( _smr_cache, 0, sizeof(struct twnotify_smr_context_record) * TWNOTIFY_SMR_CACHE_SIZE );

    // init our cache lock
    spin_lock_init( &smr_protect);

    // check for any needed module params

    if( !syscall_addr )
    {
        printk( "twnotify: ERROR loading module - no syscall_addr argument passed. \n");
        err = -2;
    }

    if( !start_rodata_addr )
    {
        printk( "twnotify: ERROR loading module - no start_rodata_addr argument passed. \n");
        err = -4;
    }
    if( !end_rodata_addr )
    {
        printk( "twnotify: ERROR loading module - no end_rodata_addr argument passed. \n");
        err = -5;
    }

#ifdef CONFIG_64BIT
#ifndef __powerpc64__
    // the ia32_sys_call_table is only used on Intel 64b platforms.  The PPC 64 bit platform has
    //   the 32-bit compatibility entry points interleaved with the 64 bit ones.
    if( !ia32syscall_addr )
    {
        printk( "twnotify: ERROR loading module - no ia32syscall_addr argument passed. \n");
        err = -3;
    }
#endif // __powerpc64__
#endif // #ifdef CONFIG_64BIT

#ifdef NEED_PHYSBASE
    if( !phys_base_addr )
    {
        printk( "twnotify: ERROR loading module - no phys_base_addr argument passed. \n");
        err = -6;
    }
    else
    {
        phys_base = *(unsigned long*)phys_base_addr;
    }
#endif

    if( err)
    {
        return err;
    }
    else
    {
        // looking good:

#ifdef __powerpc64__
        // some extra initialization required for PPC

        // First, we read our R2 value, which is set to correctly point to the TOC
        //   for our module when this init routine is called
        r2 = getR2();
        root_dbg( "twnotify: init() our r2 = 0x%lx \n", r2);

        // Now we get the address of the special storage location to stash our r2 TOC value
        txt = getTextAddr();
        root_dbg( "twnotify: init() txt = 0x%lx (%ld) \n", txt, *(long*)txt);

        // save our r2 value in the code segment
        *(long*)txt = r2;

        // save off the kernel's r2 value and store it in our hooennt array function descriptors
        fixup_ppc_function_descriptors( );

        // some extra debug output for now:
        root_dbg( "twnotify: init() saved our r2 txt = 0x%lx (%lx) \n", txt, *(long*)txt);
        root_dbg( "Module R2 values: prepare_write=%p twnotify_get_mode=%p path_match=%p getR2=%p\n",
                ((void**)prepare_write)[1], ((void**)twnotify_get_mode)[1], ((void**)path_match)[1], ((void**)getR2)[1] );

#endif // __powerpc64__

        // init the char device for user land:
	setup_syscall_tables();
        err = twnotify_init_module();
        if( err == 0 )
        {
	    printk("twnotify: Preparing to hook the syscall table.\n");

            err = hook_all();
            if( err == 0)
            {
                ishooked = 1;
                // some extra debug out:
                printk( "twnotify: syscall table hooked successfully.\n" );
                //dumpAddress( sys_call_table );
                printk("twnotify: init_sysfs result: %d\n", init_sysfs());
            }
            else
            {
                printk( "twnotify: ERROR loading module - syscall hook failed. (%d)\n", err);
                err = -4;
                // make sure to clean up the char dev:
                twnotify_cleanup_module( );
            }
        }
        else
        {
            printk( "twnotify: ERROR loading module - char dev init failed. \n");
        }
    }

    printk( "twnotify: init done: returning %d \n", err);
    return err;
}

/*****************************************************************************
*
* FUNCTION: twnotify_exit( )
*
*****************************************************************************/

static void twnotify_exit (void)
{
    printk( "twnotify: exit \n" );
#ifdef KERNEL_GT_2_6_24
    if(syscallState != NULL) {
      kobject_put(syscallState);
    }
#endif

    root_dbg("unhooking syscalltable\n");

    unhook_all();
    root_dbg("unhooking syscalltable done\n");

    // Call msleep() NOT mdelay() here because mdelay() ties up the calling thread and
    //   will fail to allow other threads in the kernel to finish syscalls on single
    //   proc systems.  The reason for this delay is to allow other threads that may be
    //   in the middle of syscalls into the kernel to back out before we unload, and to
    //   ensure all new threads entering the kernel through syscalls do so after we've
    //   unhooked.
    msleep(10000);

    twnotify_cleanup_module();

    printk( "twnotify: exit done \n");
}

module_init (twnotify_init);
module_exit (twnotify_exit);

MODULE_AUTHOR("Tripwire, Inc.");
MODULE_DESCRIPTION("Tripwire realtime notification module");
MODULE_LICENSE("GPL");

