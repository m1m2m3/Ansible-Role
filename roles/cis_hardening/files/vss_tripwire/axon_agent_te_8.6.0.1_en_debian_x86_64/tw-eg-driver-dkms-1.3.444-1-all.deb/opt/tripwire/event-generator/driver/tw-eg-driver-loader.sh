#!/bin/sh

COMMAND=$1
DRIVER_NAME="twnotify"
DKMS_MODULE_NAME_AND_VERSION="${DRIVER_NAME}/1.0"
DRIVER_SYMLINK_NAME="${DRIVER_NAME}.ko"

exitIfTwnotifyLoaded() {
    lsmod | grep -q ${DRIVER_NAME}
    if [ $? -eq 0 ]; then
        echo "Note: the driver was already loaded."
        exit 0
    fi 
}

dkmsInstall() {
    dkms status ${DKMS_MODULE_NAME_AND_VERSION} | grep -q ${DRIVER_NAME}
    if [ $? -ne 0 ]; then
       dkms install ${DKMS_MODULE_NAME_AND_VERSION} 
    fi
}

invokeModprobe() {
    SYSCALL_ADDR_ARG=$(grep -E " sys_call_table$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${SYSCALL_ADDR_ARG}" ]; then
        SYSCALL_ADDR_ARG="syscall_addr=0x${SYSCALL_ADDR_ARG}"
    fi

    RODATA_START_ARG=$(grep -E " __start_rodata$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${RODATA_START_ARG}" ]; then
        RODATA_START_ARG="start_rodata_addr=0x${RODATA_START_ARG}"
    fi

    RODATA_END_ARG=$(grep -E " __end_rodata$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${RODATA_END_ARG}" ]; then
        RODATA_END_ARG="end_rodata_addr=0x${RODATA_END_ARG}"
    fi

    PHYS_BASE_ARG=$(grep -E " phys_base$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${PHYS_BASE_ARG}" ]; then
        PHYS_BASE_ARG="phys_base_addr=0x${PHYS_BASE_ARG}"
    fi

    IA32_SYSCALL_ADDR_ARG=$(grep -E " ia32_sys_call_table$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${IA32_SYSCALL_ADDR_ARG}" ]; then
        IA32_SYSCALL_ADDR_ARG="ia32syscall_addr=0x${IA32_SYSCALL_ADDR_ARG}"
    fi

    MODPROBE_COMMAND_LINE="/sbin/modprobe ${DRIVER_NAME} ${SYSCALL_ADDR_ARG} ${RODATA_START_ARG} ${RODATA_END_ARG} ${PHYS_BASE_ARG} ${IA32_SYSCALL_ADDR_ARG}"
    echo "Attemping to run command: ${MODPROBE_COMMAND_LINE}"
    $MODPROBE_COMMAND_LINE
}

load() {
    echo "Loading Tripwire Event Generator driver..."
    exitIfTwnotifyLoaded
    dkmsInstall
    invokeModprobe
}

unload() {
    echo "Unloading Tripwire Event Generator driver..."
    rmmod ${DRIVER_NAME}
}

uninstall() {
    unload
    dkms remove --all ${DKMS_MODULE_NAME_AND_VERSION}
    find /lib/modules -name ${DRIVER_SYMLINK_NAME} -delete
}

case "${COMMAND}" in
    'load')
        load
        ;;
    'unload')
        unload
        ;;
    'uninstall')
        uninstall
        ;;
    *)
        echo "Error: unrecognized command ${COMMAND}"
        echo "Usage: $0 [load|unload|uninstall]"
        exit 1
        ;;
esac
