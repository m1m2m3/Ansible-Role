/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


#ifndef __TWNOTIFY_USER_H__
#define __TWNOTIFY_USER_H__


// User space helper functions:
int twnotify_open (struct inode *inode, struct file *file);

int twnotify_release (struct inode *inode, struct file *file);

ssize_t twnotify_read (struct file *file, char *buf, size_t count, loff_t *ppos);

void twnotify_set_qlimit(int newsize);

int twnotify_exclude_path(int size, void *name);

void twnotify_exclude_pid(int pid);

void twnotify_clear_all_exclusions (void);

void twnotify_clear_exclusions (int type);

int path_match( const char *path, const char *pattern);

int is_excluded( long pid, const char *path);

long twnotify_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

void twnotify_fire_event(struct twnotify *xd);

int __init twnotify_init_module (void);

void __exit twnotify_cleanup_module (void);


#endif // __TWNOTIFY_USER_H__
