#!/bin/sh

COMMAND=$1
CUSTOM_DRIVER_PATH=$2
DRIVER_NAME="twnotify"
DRIVER_SYMLINK_NAME="${DRIVER_NAME}.ko"
KERNEL_DIRECTORY=/lib/modules/`uname -r`/kernel/tripwire
DRIVER_SYMLINK_PATH="${KERNEL_DIRECTORY}/${DRIVER_SYMLINK_NAME}"
UNKNOWN_OS="UNKNOWN"
OPT_PATH="/opt/tripwire"

exitIfTwnotifyLoaded() {
    lsmod | grep -q ${DRIVER_NAME}
    if [ $? -eq 0 ]; then
        echo "Note: the driver was already loaded."
        exit 0
    fi 
}

detectRhelVersion() {
    grep -q "release 5" /etc/redhat-release
    if [ $? -eq 0 ]; then
        echo "RHEL5"
        return
    fi

    grep -q "release 6\.[0-4]" /etc/redhat-release
    if [ $? -eq 0 ]; then
        echo "RHEL6"
        return
    fi

    grep -q "release 6" /etc/redhat-release
    if [ $? -eq 0 ]; then
        echo "RHEL6-5"
        return
    fi

    grep -q "release 7\.[0-2]" /etc/redhat-release
    if [ $? -eq 0 ]; then
        echo "RHEL7"
        return
    fi

    grep -q "release 7\.3" /etc/redhat-release
    if [ $? -eq 0 ]; then
        echo "RHEL7-3"
        return
    fi

    grep -q "release 7" /etc/redhat-release
    if [ $? -eq 0 ]; then
        echo "RHEL7-4"
        return
    fi

    echo "${UNKNOWN_OS}"
}

detectSuseVersion() {
    grep -q "VERSION = 11" /etc/SuSE-release && grep -q "PATCHLEVEL = 4" /etc/SuSE-release
    if [ $? -eq 0 ]; then
        echo "SUSE11-4"
        return
    fi

    grep -q "VERSION = 12" /etc/SuSE-release && grep -q "PATCHLEVEL = 0" /etc/SuSE-release
    if [ $? -eq 0 ]; then
        echo "SUSE12"
        return
    fi

    grep -q "VERSION = 12" /etc/SuSE-release && grep -q "PATCHLEVEL = 1" /etc/SuSE-release
    if [ $? -eq 0 ]; then
        echo "SUSE12-1"
        return
    fi

    grep -q "VERSION = 12" /etc/SuSE-release && grep -q "PATCHLEVEL = 2" /etc/SuSE-release
    if [ $? -eq 0 ]; then
        echo "SUSE12-2"
        return
    fi

    echo "${UNKNOWN_OS}"
}

detectDebianVersion() {
    grep -q "8\." /etc/debian_version
    if [ $? -eq 0 ]; then
        echo "DEBIAN8"
        return
    fi

    grep -q "jessie/sid" /etc/debian_version
    if [ $? -eq 0 ]; then
        echo "UBUNTU14"
        return
    fi

    echo "${UNKNOWN_OS}"
}

detectOsVersion() {
    if [ -e "/etc/redhat-release" ]; then
        echo $(detectRhelVersion)
        return
    elif [ -e "/etc/SuSE-release" ]; then
        echo $(detectSuseVersion)
        return
    elif [ -e "/etc/debian_version" ]; then
         echo $(detectDebianVersion)
         return
    else
        echo "${UNKNOWN_OS}"
    fi
}

createSymlinkUsingDriver() {
    if [ -n "${CUSTOM_DRIVER_PATH}" ]; then
      DRIVER_BASE_PATH="${CUSTOM_DRIVER_PATH}"
    else
      DRIVER_BASE_PATH="${OPT_PATH}/event-generator/driver"
    fi

    DRIVER_FULL_PATH="${DRIVER_BASE_PATH}/$1"

    if [ ! -e "${DRIVER_FULL_PATH}" ]; then
        echo "Error: driver file '${DRIVER_FULL_PATH}' not found, unable to symlink into kernel modules"
        exit 1
    fi

    ln -sf "${DRIVER_FULL_PATH}" "${DRIVER_SYMLINK_PATH}"
}

symlinkDriver() {
    mkdir -p "${KERNEL_DIRECTORY}"
    case "$1" in
        'RHEL5')
            createSymlinkUsingDriver "tw-eg-driver-linux-rhel5.ko"
            ;;
        'RHEL6')
            createSymlinkUsingDriver "tw-eg-driver-linux-rhel6.ko"
            ;;
        'RHEL6-5')
            createSymlinkUsingDriver "tw-eg-driver-linux-rhel6.5.ko"
            ;;
        'RHEL7')
            createSymlinkUsingDriver "tw-eg-driver-linux-rhel7.ko"
            ;;
        'RHEL7-3')
            createSymlinkUsingDriver "tw-eg-driver-linux-rhel7.3.ko"
            ;;
        'RHEL7-4')
            createSymlinkUsingDriver "tw-eg-driver-linux-rhel7.4.ko"
            ;;
        'DEBIAN8')
            createSymlinkUsingDriver "tw-eg-driver-linux-debian8.ko"
            ;;
        'UBUNTU14')
            createSymlinkUsingDriver "tw-eg-driver-linux-ubuntu14-$(uname -r).ko"
            ;;
        'SUSE11-4')
            createSymlinkUsingDriver "tw-eg-driver-linux-suse11.4.ko"
            ;;
        'SUSE12')
            createSymlinkUsingDriver "tw-eg-driver-linux-suse12.0.ko"
            ;;
        'SUSE12-1')
            createSymlinkUsingDriver "tw-eg-driver-linux-suse12.1.ko"
            ;;
        'SUSE12-2')
            createSymlinkUsingDriver "tw-eg-driver-linux-suse12.2.ko"
            ;;
        *)
            echo "Error: do not know how to symlink driver for OSVERSION=$1"
            exit 1
            ;;
    esac
}

invokeInsmod() {
    SYSCALL_ADDR_ARG=$(grep -E " sys_call_table$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${SYSCALL_ADDR_ARG}" ]; then
        SYSCALL_ADDR_ARG="syscall_addr=0x${SYSCALL_ADDR_ARG}"
    fi

    RODATA_START_ARG=$(grep -E " __start_rodata$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${RODATA_START_ARG}" ]; then
        RODATA_START_ARG="start_rodata_addr=0x${RODATA_START_ARG}"
    fi

    RODATA_END_ARG=$(grep -E " __end_rodata$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${RODATA_END_ARG}" ]; then
        RODATA_END_ARG="end_rodata_addr=0x${RODATA_END_ARG}"
    fi

    PHYS_BASE_ARG=$(grep -E " phys_base$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${PHYS_BASE_ARG}" ]; then
        PHYS_BASE_ARG="phys_base_addr=0x${PHYS_BASE_ARG}"
    fi

    IA32_SYSCALL_ADDR_ARG=$(grep -E " ia32_sys_call_table$" /boot/System.map-`uname -r` | cut -d ' ' -f 1)
    if [ -n "${IA32_SYSCALL_ADDR_ARG}" ]; then
        IA32_SYSCALL_ADDR_ARG="ia32syscall_addr=0x${IA32_SYSCALL_ADDR_ARG}"
    fi

    INSMOD_COMMAND_LINE="/sbin/insmod ${DRIVER_SYMLINK_PATH} ${SYSCALL_ADDR_ARG} ${RODATA_START_ARG} ${RODATA_END_ARG} ${PHYS_BASE_ARG} ${IA32_SYSCALL_ADDR_ARG}"
    echo "Attemping to run command: ${INSMOD_COMMAND_LINE}"
    $INSMOD_COMMAND_LINE
}

load() {
    echo "Loading Tripwire Event Generator driver..."
    exitIfTwnotifyLoaded
    OSVERSION=$(detectOsVersion)
    if [ "$OSVERSION" = "$UNKNOWN_OS" ]; then
        echo "Error: Unable to detect the Operating System and/or version."
        exit 1
    fi
    symlinkDriver ${OSVERSION}
    invokeInsmod
}


unload() {
    echo "Unloading Tripwire Event Generator driver..."
    rmmod ${DRIVER_NAME}
    find /lib/modules -name ${DRIVER_SYMLINK_NAME} -type l -delete
}

case "${COMMAND}" in
    'load')
        load
        ;;
    'unload')
        unload
        ;;
    *)
        echo "Error: unrecognized command ${COMMAND}"
        echo "Usage: $0 [load|unload]"
        exit 1
        ;;
esac
