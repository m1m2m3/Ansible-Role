/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/security.h>
#include <linux/usb.h>
#include <linux/string.h>
#include <linux/syscalls.h>
#include <asm/page.h>
#include <asm/pgtable.h>
#include <asm/cacheflush.h>
#include <linux/compat.h>
#include <asm/unistd.h>
#include <linux/types.h>
#include <linux/delay.h>
#include <linux/highuid.h>
#include <linux/string.h>
#include <asm/uaccess.h>
#include <asm/mman.h>


#undef MY_NAME
#define MY_NAME "twnotify_handlers"

// our includes:
#include "twnotify_handlers.h"
#include "twnotify_main.h"
#include "twnotify.h"
#include "twnotify_user.h"
#include "twnotify_utils.h"


#define MAP_FAILED  (-1)

// This isn't always defined, so we will make it a no-op here if need be
#ifndef prevent_tail_call
#define prevent_tail_call(x)  // somehow not necessary on 2.6.24 and later kernels
#endif


// ***************************************************************************
// function pointers for original values in syscalltable - filled in when we hook:
// this is the list of native functions
// note: some of these are not used in the 64b syscall table

// These are declared in this header to keep maintenance simple.

// TWNOTIFY_CREAT
asmlinkage long (*original_sys_creat)(const char USERPTR *filename, int mode);
asmlinkage long (*original_sys_mkdir)(const char USERPTR *pathname, int mode);
asmlinkage long (*original_sys_mkdirat)(int dirfd, const char USERPTR *pathname, int mode);
asmlinkage long (*original_sys_mknod)(const char USERPTR *pathname, int mode, int dev);
asmlinkage long (*original_sys_mknodat)(int dirfd, const char USERPTR *pathname, int mode, int dev);
asmlinkage long (*original_sys_open)(const char USERPTR *filename, int flags, int mode);
asmlinkage long (*original_sys_openat)(int fd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
asmlinkage long (*original_sys_open_by_handle_at)(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39


// TWNOTIFY_LINK
asmlinkage long (*original_sys_link)(const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long (*original_sys_linkat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath, int flags);
asmlinkage long (*original_sys_symlink)(const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long (*original_sys_symlinkat)(const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_DELETE
asmlinkage long (*original_sys_rmdir)(const char USERPTR *pathname);
asmlinkage long (*original_sys_unlink)(const char USERPTR *pathname);
asmlinkage long (*original_sys_unlinkat)(int dirfd, const char USERPTR * pathname, int flags);

// TWNOTIFY_RENAME
asmlinkage long (*original_sys_rename)(const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long (*original_sys_renameat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_WRITE
// - 2.2 and 2.4 kernel only: static asmlinkage long (*original_sys_pwrite)(int fd, const void USERPTR *buf, int count, int offset);
asmlinkage ssize_t (*original_sys_pwrite64)(int fd, const void USERPTR *buf, size_t count, loff_t offset);
asmlinkage ssize_t (*original_sys_write)(int fd, const void USERPTR *buf, size_t count);
asmlinkage ssize_t (*original_sys_writev)(long fd, const struct iovec USERPTR * iov, long iovcnt);
asmlinkage long (*original_sys_splice)(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);
asmlinkage long (*original_sys_pwritev)(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h);


// TWNOTIFY_CHMOD
asmlinkage long (*original_sys_chmod)( const char USERPTR *path, mode_t mode);
asmlinkage long (*original_sys_fchmod)(int fd, mode_t mode);
asmlinkage long (*original_sys_fchmodat)(int dirfd, const char USERPTR *pathname, mode_t mode, int flags);

// TWNOTIFY_CHOWN
asmlinkage long (*original_sys_chown)( const char USERPTR *path, int owner, int group);
asmlinkage long (*original_sys_chown32)( const char USERPTR *path, int owner, int group);
asmlinkage long (*original_sys_fchown)(int fd, int owner, int group);
asmlinkage long (*original_sys_fchown32)(int fd, int owner, int group);
asmlinkage long (*original_sys_fchownat)(int dirfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);
asmlinkage long (*original_sys_lchown)(const char USERPTR *path, uid_t owner, gid_t group);
asmlinkage long (*original_sys_lchown32)(const char USERPTR *path, uid_t owner, gid_t group);

// TWNOTIFY_TIMES
asmlinkage long (*original_sys_futimesat)(int dirfd, const char USERPTR *pathname, const struct timeval times[2]);
asmlinkage long (*original_sys_utime)(const char USERPTR *filename, const struct utimbuf USERPTR *buf);
asmlinkage long (*original_sys_utimes)(const char USERPTR *filename, const struct timeval times[2]);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long (*original_sys_utimensat)(int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags);
#endif

// TWNOTIFY_XATTRCHANGE
asmlinkage long (*original_sys_fremovexattr)(int fd, const char USERPTR *name);
asmlinkage long (*original_sys_fsetxattr)(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long (*original_sys_lremovexattr)(const char USERPTR *path, const char USERPTR *name);
asmlinkage long (*original_sys_lsetxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long (*original_sys_removexattr)(const char USERPTR *path, const char USERPTR *name);
asmlinkage long (*original_sys_setxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);

// TWNOTIFY_TRUNCATE
asmlinkage long (*original_sys_ftruncate)(int fd, unsigned long length);
asmlinkage long (*original_sys_ftruncate64)(int fd, loff_t length);
asmlinkage long (*original_sys_truncate)(const char USERPTR *path, unsigned long length);
asmlinkage long (*original_sys_truncate64)(const char USERPTR *path, loff_t length);

// TWNOTIFY_MOUNT
asmlinkage long (*original_sys_mount)(const char USERPTR *source, const char USERPTR *target, const char USERPTR *filesystemtype,
                        unsigned long mountflags, const void USERPTR *data);

// TWNOTIFY_UNMOUNT
asmlinkage long (*original_sys_umount)(const char USERPTR *target);
asmlinkage long (*original_sys_umount2)(const char USERPTR *target, int flags);


// HOUSEKEEPING
asmlinkage long (*original_sys_close)(unsigned int fd);




#ifdef CONFIG_64BIT

// function pointers for original values in ia32 syscalltable - filled in when we hook:
// these are for the ia32 entries that are the same as the native entries
// there are not twnotify_xxxx implementations for these bacause we reuse the native ones

// TWNOTIFY_CREAT
asmlinkage long (*original32_sys_creat)(const char USERPTR *filename, int mode);
asmlinkage long (*original32_sys_mkdir)(const char USERPTR *pathname, int mode);
asmlinkage long (*original32_sys_mkdirat)(int dirfd, const char USERPTR *pathname, int mode);
asmlinkage long (*original32_sys_mknod)(const char USERPTR *pathname, int mode, int dev);
asmlinkage long (*original32_sys_mknodat)(int dirfd, const char USERPTR *pathname, int mode, int dev);

// TWNOTIFY_LINK
asmlinkage long (*original32_sys_link)(const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long (*original32_sys_linkat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath, int flags);
asmlinkage long (*original32_sys_symlink)(const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long (*original32_sys_symlinkat)(const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_DELETE
asmlinkage long (*original32_sys_rmdir)(const char USERPTR *pathname);
asmlinkage long (*original32_sys_unlink)(const char USERPTR *pathname);
asmlinkage long (*original32_sys_unlinkat)(int dirfd, const char USERPTR * pathname, int flags);

// TWNOTIFY_RENAME
asmlinkage long (*original32_sys_rename)(const char USERPTR *oldpath, const char USERPTR *newpath);
asmlinkage long (*original32_sys_renameat)(int olddirfd, const char USERPTR *oldpath, int newdirfd, const char USERPTR *newpath);

// TWNOTIFY_WRITE
// - 2.2 and 2.4 kernel only: static asmlinkage long (*original_sys_pwrite)(int fd, const void USERPTR *buf, int count, int offset);
asmlinkage ssize_t (*original32_sys_write)(int fd, const void USERPTR *buf, size_t count);
asmlinkage long (*original32_sys_splice)(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags);

// TWNOTIFY_CHMOD
asmlinkage long (*original32_sys_chmod)( const char USERPTR *path, mode_t mode);
asmlinkage long (*original32_sys_fchmod)(int fd, mode_t mode);
asmlinkage long (*original32_sys_fchmodat)(int dirfd, const char USERPTR *pathname, mode_t mode, int flags);

// TWNOTIFY_CHOWN
asmlinkage long (*original32_sys_fchownat)(int dirfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags);

// TWNOTIFY_TIMES

// TWNOTIFY_XATTRCHANGE
asmlinkage long (*original32_sys_fremovexattr)(int fd, const char USERPTR *name);
asmlinkage long (*original32_sys_fsetxattr)(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long (*original32_sys_lremovexattr)(const char USERPTR *path, const char USERPTR *name);
asmlinkage long (*original32_sys_lsetxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);
asmlinkage long (*original32_sys_removexattr)(const char USERPTR *path, const char USERPTR *name);
asmlinkage long (*original32_sys_setxattr)(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags);

// TWNOTIFY_TRUNCATE
asmlinkage long (*original32_sys_ftruncate)(int fd, unsigned long length);
asmlinkage long (*original32_sys_truncate)(const char USERPTR *path, unsigned long length);

// TWNOTIFY_MOUNT

// TWNOTIFY_UNMOUNT

// HOUSEKEEPING
asmlinkage long (*original32_sys_close)(unsigned int fd);



// These are ia32 emulation entry points that don't just call the 64b funcs
// or that aren't in the 64b syscall table but are in the 32b table


/*  now in compat.h */
/*
struct compat_utimbuf {
        compat_time_t           actime;
        compat_time_t           modtime;
};

struct compat_iovec {
        compat_uptr_t   iov_base;
        compat_size_t   iov_len;
};
*/


asmlinkage long (*original32_sys_open)(const char USERPTR *filename, int flags, int mode);
asmlinkage long (*original32_sys_openat)(unsigned int dfd, const char USERPTR *filename, int flags, int mode);
#ifdef KERNEL_GT_2_6_39
asmlinkage long (*original32_sys_open_by_handle_at)(int mount_fd, struct file_handle *handle, int flags);
#endif // KERNEL_GT_2_6_39



asmlinkage long (*original32_sys_writev)(unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen);
asmlinkage long (*original32_sys_pwritev)(unsigned long fd, const struct compat_iovec __user *vec, unsigned long vlen, u32 pos_low, u32 pos_high);
asmlinkage long (*original32_sys_pwrite64)(unsigned int fd, char USERPTR *ubuf, u32 count, u32 poslo, u32 poshi);


asmlinkage long (*original32_sys_chown)(const char USERPTR *filename, old_uid_t user, old_gid_t group);
asmlinkage long (*original32_sys_lchown)(const char USERPTR *filename, old_uid_t user, old_gid_t group);
asmlinkage long (*original32_sys_fchown)(unsigned int fd, old_uid_t user, old_gid_t group);

asmlinkage long (*original32_sys_chown32)(const char USERPTR *filename, uid_t user, gid_t group);
asmlinkage long (*original32_sys_lchown32)(const char USERPTR *filename, uid_t user, gid_t group);
asmlinkage long (*original32_sys_fchown32)(unsigned int fd, uid_t user, gid_t group);


asmlinkage long (*original32_sys_utime)(char USERPTR *filename, struct compat_utimbuf USERPTR *t);
asmlinkage long (*original32_sys_futimesat)(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t);
asmlinkage long (*original32_sys_utimes)(char USERPTR *filename, struct compat_timeval USERPTR *t);
#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long (*original32_sys_utimensat)(int dfd, char USERPTR *filename, struct compat_timespec USERPTR *utimes, int flags);
#endif


asmlinkage long (*original32_sys_truncate64)(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high);
asmlinkage long (*original32_sys_ftruncate64)(unsigned int fd, unsigned long offset_low, unsigned long offset_high);


asmlinkage long (*original32_sys_mount)(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type, unsigned long flags, void USERPTR * data);
asmlinkage long (*original32_sys_umount)(char USERPTR * name);
asmlinkage long (*original32_sys_umount2)(char USERPTR * name, int flags);


#endif // CONFIG_64_BIT





#ifdef __powerpc64__
// These are special helpers for the PPC hooking implementation

// This function returns the value stored in the processor's R2 register,
//   which is used as the TOC address in the PPC ABI spec.
noinline unsigned long getR2( void )
{
    unsigned long myr2;

    __asm__ __volatile__ ( "\n\t"

    "mr     %0,2    \n\t"

    : /* outputs */     /* %0 */ "=r" (myr2)
    : /* inputs */
    : /* clobbered */   "cc"
    );

    return myr2;
}

// This function will set a value into the processor's R2 register
noinline void setR2( unsigned long val )
{
    __asm__ __volatile__ ( "\n\t"

    "mr     2, %0    \n\t"

    : /* outputs */
    : /* inputs */   /* %0 */ "r" (val)
    : /* clobbered */   "cc"
    );


    return;
}

//  This function uses a trick to define 4 quad words with the inline assembly.
//    This is to reserve a space in memory in the code segment where we can
//    store and retrive values without their addresses being dependent on an
//    offset from the TOC or r2 value.  This gives us a way to store or retreive r2 values
//    without needing our own r2 to be set correctly, which it is not when we get called
//    from our syscall hook.  Calling the function returns the address of the first entry
noinline unsigned long  getTextAddr( void )
{
    unsigned long ptr;

    __asm__ __volatile__ ( "\n\t"

    "bl     1f      \n\t"
    ".quad  42      \n\t"
    ".quad  43      \n\t"
    ".quad  44      \n\t"
    ".quad  45      \n\t"
    "1:             \n\t"
    "mflr   %0      \n\t"

    : /* outputs */     /* %0 */ "=r" (ptr)
    : /* inputs */
    : /* clobbered */   "cc", "lr"
    );

    return ptr;
}

#endif // __powerpc64__

// Debug routine to dump some memory values from an address
void dumpAddress( void** ptr )
{
    int i;
    printk( "Dumping values at 0x%p\n", ptr );
    for( i = 0; i < 80; i += 4 )
    {
        printk( " 0x%p 0x%p 0x%p 0x%p\n",
            *(ptr+i), *(ptr+1+i), *(ptr+2+i), *(ptr+3+i) );
    }

}


// 64-bit only handlers:
#ifdef CONFIG_64BIT

/*****************************************************************************
*
* FUNCTION: twnotify32_sys_open( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_open( const char USERPTR *filename, int flags, int mode)
{
    long fd = original32_sys_open( filename, flags, mode);
    if( (fd >= 0) && !bypass_mode && (flags & O_CREAT) )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32open", TWNOTIFY_CREAT, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    // now check separately for O_TRUNC
    if( (fd >= 0) && !bypass_mode && (flags & O_TRUNC) )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32open2", TWNOTIFY_WRITE, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_openat( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_openat( unsigned int dfd, const char USERPTR *filename, int flags, int mode)
{
    long fd = original32_sys_openat( dfd, filename, flags, mode);
    if( (fd >= 0) && !bypass_mode && (flags & O_CREAT))
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32openat", TWNOTIFY_CREAT, dfd, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    // now check separately for O_TRUNC
    if( (fd >= 0) && !bypass_mode && (flags & O_TRUNC))
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32openat", TWNOTIFY_WRITE, dfd, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_open_by_handle_at( )
*
*****************************************************************************/
#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify32_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags)
{
    long fd = original32_sys_open_by_handle_at( mount_fd, handle, flags);
    if( (fd >= 0) && !bypass_mode && (flags & O_CREAT))
    {

        struct twnotify* ntf = twnotify_prep_event_1fd( "32open_by_handle_at", TWNOTIFY_CREAT, fd);
        if( ntf)
        {
            ntf->mode = 0;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    // always check for truncate separately and generate a write:
    if( (fd >= 0) && !bypass_mode && (flags & O_TRUNC))
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "32open_by_handle_at", TWNOTIFY_WRITE, fd);
        if( ntf)
        {
            ntf->mode = 0;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}
#endif // KERNEL_GT_2_6_39


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_pwrite64( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_pwrite64( unsigned int fd, char USERPTR *ubuf, u32 count, u32 poslo, u32 poshi)
{
    long ret = original32_sys_pwrite64( fd, ubuf, count, poslo, poshi);

    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "32pwrite64", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "32pwrite64", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                ntf->write_length = ret;
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_writev( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_writev( unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen)
{
    long ret = original32_sys_writev( fd, vec, vlen);

    // ignore pipes and sockets for write
    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "32writev", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "32writev", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify32_sys_pwritev( )
*
*****************************************************************************/

#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify32_sys_pwritev( unsigned long fd, const struct compat_iovec __user *vec, unsigned long vlen, u32 pos_low, u32 pos_high)
{
    long ret = original32_sys_pwritev( fd, vec, vlen, pos_low, pos_high);

    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "32pwritev", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "32pwritev", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}
#endif

/*****************************************************************************
*
* FUNCTION: twnotify32_sys_chown( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_chown(const char USERPTR * filename, old_uid_t user, old_gid_t group)
{
    long ret = original32_sys_chown( filename, user, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32chown", TWNOTIFY_CHOWN, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->owner = user;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    /* avoid REGPARM breakage on x86: */
    prevent_tail_call(ret);
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_chown32( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_chown32(const char USERPTR *filename, uid_t user, gid_t group)
{
    long ret = original32_sys_chown32( filename, user, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32chown32", TWNOTIFY_CHOWN, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->owner = user;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_fchown( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_fchown(unsigned int fd, old_uid_t user, old_gid_t group)
{
    long ret = original32_sys_fchown( fd, user, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "32fchown", TWNOTIFY_CHOWN, fd);
        if( ntf)
        {
            ntf->owner = user;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    /* avoid REGPARM breakage on x86: */
    prevent_tail_call(ret);
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_fchown32( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_fchown32(unsigned int fd, uid_t user, gid_t group)
{
    long ret = original32_sys_fchown32( fd, user, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "32fchown32", TWNOTIFY_CHOWN, fd);
        if( ntf)
        {
            ntf->owner = user;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_lchown( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_lchown(const char USERPTR * filename, old_uid_t user, old_gid_t group)
{
    long ret = original32_sys_lchown( filename, user, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_l1file( "32lchown", TWNOTIFY_CHOWN, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->owner = user;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    /* avoid REGPARM breakage on x86: */
    prevent_tail_call(ret);
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_lchown32( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_lchown32(const char USERPTR *filename, uid_t user, gid_t group)
{
    long ret = original32_sys_lchown32( filename, user, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_l1file( "32lchown32", TWNOTIFY_CHOWN, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->owner = user;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_utime( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_utime(char USERPTR *filename, struct compat_utimbuf USERPTR *t)
{
    long ret = original32_sys_utime( filename, t);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32utime", TWNOTIFY_TIMES, AT_FDCWD, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_utimes( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_utimes(char USERPTR *filename, struct compat_timeval USERPTR *t)
{
    long ret = original32_sys_utimes( filename, t);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32utimes", TWNOTIFY_TIMES, AT_FDCWD, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_futimesat( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_futimesat(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t)
{
    long ret = original32_sys_futimesat( dfd, filename, t);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32futimesat", TWNOTIFY_TIMES, dfd, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify32_sys_utimensat( )
*
*****************************************************************************/

#ifdef KERNEL_GT_2_6_24 // only on later kernels

asmlinkage long twnotify32_sys_utimensat(int dfd, char USERPTR *filename, struct compat_timespec USERPTR *utimes, int flags)
{
    long ret = original32_sys_utimensat( dfd, filename, utimes, flags);
    struct twnotify* ntf = NULL;
    if( (ret == 0) && !bypass_mode )
    {
        ntf = twnotify_prep_event_1file( "32utimensat", TWNOTIFY_TIMES, dfd, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}
#endif

/*****************************************************************************
*
* FUNCTION: twnotify32_sys_truncate64( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_truncate64(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high)
{
    long ret = original32_sys_truncate64( filename, offset_low, offset_high);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32trunate64", TWNOTIFY_TRUNCATE, AT_FDCWD, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_ftruncate64( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_ftruncate64(unsigned int fd, unsigned long offset_low, unsigned long offset_high)
{
    long ret = original32_sys_ftruncate64( fd, offset_low, offset_high);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "32ftrunate64", TWNOTIFY_TRUNCATE, fd);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_mount( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_mount(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type, unsigned long flags, void USERPTR * data)
{
    long ret = original32_sys_mount( dev_name, dir_name, type, flags, data);
    //printk( "32b orig returned %ld \n ", ret );
    if( (ret == 0) && !bypass_mode )
    {
        //printk( "32b orig calling prep2files \n " );
        struct twnotify* ntf = twnotify_prep_event_2files( "32mount", TWNOTIFY_MOUNT, AT_FDCWD, dev_name, AT_FDCWD, dir_name);
        if( ntf)
        {
            //printk( "32b orig firing event \n " );
            twnotify_fire_event(ntf);
        }
    }
    //printk( "32b orig returning %ld \n ", ret );
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_umount( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_umount(char USERPTR * name)
{
    //ret = sys_umount(name, 0);
    long ret = original32_sys_umount( name);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32umount", TWNOTIFY_UNMOUNT, AT_FDCWD, name);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify32_sys_umount2( )
*
*****************************************************************************/

asmlinkage long twnotify32_sys_umount2(char USERPTR * name, int flags)
{
    long ret = original32_sys_umount2( name, flags);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "32umount2", TWNOTIFY_UNMOUNT, AT_FDCWD, name);
        if( ntf)
        {
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


#endif // CONFIG_64BIT


// *********** Handlers used for 32 adn 64 bit:


/*****************************************************************************
*
* TWNOTIFY_CREATE
*
*****************************************************************************/



/*****************************************************************************
*
* FUNCTION: twnotify_sys_creat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_creat( const char USERPTR *filename, int mode)
{
    long fd = original_sys_creat( filename, mode);
    if( (fd >= 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "creat", TWNOTIFY_CREAT, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->fd = fd;
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
        // on calls to CREAT we always infer a write also occurred.  This is because if
        //   the file existsed already, the call to creat() will cause it to be truncated.
        ntf = twnotify_prep_event_1file( "creat", TWNOTIFY_WRITE, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->fd = fd;
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_mkdir( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_mkdir( const char USERPTR *pathname, int mode)
{
    long ret = original_sys_mkdir( pathname, mode);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "mkdir", TWNOTIFY_CREAT, AT_FDCWD, pathname);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->is_directory = 1;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_mkdirat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_mkdirat( int dfd, const char USERPTR *pathname, int mode)
{
    long ret = original_sys_mkdirat( dfd, pathname, mode);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "mkdirat", TWNOTIFY_CREAT, dfd, pathname);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->is_directory = 1;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_mknod( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_mknod( const char USERPTR *pathname, int mode, int dev)
{
    long ret = original_sys_mknod( pathname, mode, dev);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "mknod", TWNOTIFY_CREAT, AT_FDCWD, pathname);
        if( ntf)
        {
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_mknodat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_mknodat( int dfd, const char USERPTR *pathname, int mode, int dev)
{
    long ret = original_sys_mknodat( dfd, pathname, mode, dev);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "mknodat", TWNOTIFY_CREAT, dfd, pathname);
        if( ntf)
        {
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_open( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_open( const char USERPTR *filename, int flags, int mode)
{
    long fd = original_sys_open(filename, flags, mode);
    //root_spew("File: %s Flags: %x mode: %x\n", filename, flags, mode);
    if( (fd >= 0) && !bypass_mode && (flags & O_CREAT) )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "open", TWNOTIFY_CREAT, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    // always check for truncate separately and generate a write:
    if( (fd >= 0) && !bypass_mode && (flags & O_TRUNC) )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "open", TWNOTIFY_WRITE, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_openat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_openat( int dfd, const char USERPTR *filename, int flags, int mode)
{
    long fd = original_sys_openat( dfd, filename, flags, mode);
    if( (fd >= 0) && !bypass_mode && (flags & O_CREAT))
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "openat", TWNOTIFY_CREAT, dfd, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    // always check for truncate separately and generate a write:
    if( (fd >= 0) && !bypass_mode && (flags & O_TRUNC))
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "openat", TWNOTIFY_WRITE, dfd, filename);
        if( ntf)
        {
            ntf->mode = mode;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}

/*****************************************************************************
*
* FUNCTION: twnotify_sys_open_by_handle_at( )
*
*****************************************************************************/
#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags)
{
    long fd = original_sys_open_by_handle_at( mount_fd, handle, flags);
    if( (fd >= 0) && !bypass_mode && (flags & O_CREAT))
    {

        struct twnotify* ntf = twnotify_prep_event_1fd( "open_by_handle_at", TWNOTIFY_CREAT, fd);
        if( ntf)
        {
            ntf->mode = 0;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    // always check for truncate separately and generate a write:
    if( (fd >= 0) && !bypass_mode && (flags & O_TRUNC))
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "open_by_handle_at", TWNOTIFY_WRITE, fd);
        if( ntf)
        {
            ntf->mode = 0;
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return fd;
}
#endif // KERNEL_GT_2_6_39

/*****************************************************************************
*
* TWNOTIFY_LINK
*
*****************************************************************************/



/*****************************************************************************
*
* FUNCTION: twnotify_sys_link( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_link( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    long ret = original_sys_link( oldpath, newpath );
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_2files( "link", TWNOTIFY_LINK, AT_FDCWD, oldpath, AT_FDCWD, newpath);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_linkat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_linkat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags)
{
    long ret = original_sys_linkat( olddfd, oldpath, newdfd, newpath, flags);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_2files( "linkat", TWNOTIFY_LINK, olddfd, oldpath, newdfd, newpath);
        if( ntf)
        {
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_symlink( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_symlink( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    long ret = original_sys_symlink( oldpath, newpath);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_l2files( "symlink", TWNOTIFY_LINK, AT_FDCWD, oldpath, AT_FDCWD, newpath);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_symlinkat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_symlinkat( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath)
{
    long ret = original_sys_symlinkat( oldpath, newdfd, newpath);
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_l2files( "symlinkat", TWNOTIFY_LINK, AT_FDCWD, oldpath, newdfd, newpath);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}




/*****************************************************************************
*
* TWNOTIFY_DELETE
*
*****************************************************************************/




/*****************************************************************************
*
* FUNCTION: twnotify_sys_rmdir( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_rmdir( const char USERPTR *pathname)
{
    char* fullname = (bypass_mode) ? NULL : twnotify_getfilename2( "rmdir", AT_FDCWD, pathname, 0, 1);
    long ret = original_sys_rmdir( pathname);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1filex( "rmdir", TWNOTIFY_DELETE, fullname);
        fullname = NULL;
        if( ntf)
        {
            ntf->is_directory = 1;
            twnotify_fire_event(ntf);
        }
    }
    if( fullname)
        kfree( fullname);

    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_unlink( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_unlink( const char USERPTR *pathname)
{
    char* fullname = (bypass_mode) ? NULL : twnotify_getfilename2( "unlink", AT_FDCWD, pathname, 1, 1);
    long ret = original_sys_unlink( pathname);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1filex( "unlink", TWNOTIFY_DELETE, fullname);
        fullname = NULL;
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    if( fullname)
        kfree( fullname);

    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_unlinkat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_unlinkat( int dfd, const char USERPTR * pathname, int flags)
{
    char* fullname = (bypass_mode) ? NULL : twnotify_getfilename2( "unlinkat", dfd, pathname, 1, 1);
    long ret = original_sys_unlinkat( dfd, pathname, flags);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1filex( "unlinkat", TWNOTIFY_DELETE, fullname);
        fullname = NULL;
        if( ntf)
        {
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    if( fullname)
        kfree( fullname);

    return ret;
}



/*****************************************************************************
*
* TWNOTIFY_RENAME
*
*****************************************************************************/


/*****************************************************************************
*
* FUNCTION: twnotify_sys_rename( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_rename( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    char* oldname = NULL;
    long ret = 0;
    if( !bypass_mode )
    {
        // NOTE: Always no-follow on rename name in case it is a symlink itself
        oldname = twnotify_getfilename2( "rename", AT_FDCWD, oldpath, 1, 1);
    }
    // call the original handler:
    ret = original_sys_rename( oldpath, newpath );
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_2filesx( "rename", TWNOTIFY_RENAME, oldname, AT_FDCWD, newpath);
        oldname = NULL;
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    if( oldname)
        kfree( oldname);

    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_renameat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_renameat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath)
{
    char* oldname = NULL;
    long ret = 0;
    if( !bypass_mode )
    {
        // NOTE: Always no-follow on rename name in case it is a symlink itself
        oldname = twnotify_getfilename2( "renameat", olddfd, oldpath, 1, 1);
    }
    // original handler
    ret = original_sys_renameat( olddfd, oldpath, newdfd, newpath );
    if( (ret == 0) && !bypass_mode)
    {
        struct twnotify* ntf = twnotify_prep_event_2filesx( "renameat", TWNOTIFY_RENAME, oldname, newdfd, newpath);
        oldname = NULL;
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    if( oldname)
        kfree( oldname);

    return ret;
}




/*****************************************************************************
*
* TWNOTIFY_WRITE
*
*****************************************************************************/



/*****************************************************************************
*
* FUNCTION: twnotify_sys_pwrite64( )
*
*****************************************************************************/

asmlinkage ssize_t twnotify_sys_pwrite64(int fd, const void USERPTR *buf, size_t count, loff_t offset)
{
    ssize_t ret = original_sys_pwrite64( fd, buf, count, offset);
    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "pwrite64", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "pwrite64", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                ntf->write_length = ret;
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_write( )
*
*****************************************************************************/

asmlinkage ssize_t twnotify_sys_write(int fd, const void *buf, size_t count)
{

    ssize_t ret = original_sys_write( fd, buf, count);

    // ignore pipes and sockets for write
    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "write", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "write", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                ntf->write_length = ret;
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_writev( )
*
*****************************************************************************/

asmlinkage ssize_t twnotify_sys_writev(long fd, const struct iovec USERPTR * iov, long iovcnt)
{
    ssize_t ret = original_sys_writev( fd, iov, iovcnt);

    // ignore pipes and sockets for write
    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "writev", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "writev", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                ntf->write_length = ret;
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify_sys_splice( )
*
*****************************************************************************/

#ifdef KERNEL_GT_2_6_17

asmlinkage long twnotify_sys_splice(int fd_in, loff_t __user *off_in, int fd_out,
                                    loff_t __user *off_out, size_t len, unsigned int flags)
{
    long ret = original_sys_splice( fd_in, off_in, fd_out, off_out, len, flags );
    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "splice", fd_out);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "splice", TWNOTIFY_WRITE, fd_out);
            if( ntf)
            {
                ntf->write_length = ret;
                twnotify_fire_event(ntf);
            }
        }
    }

    return ret;

}

#endif


/*****************************************************************************
*
* FUNCTION: twnotify_sys_pwritev( )
*
*****************************************************************************/

#ifdef KERNEL_GT_2_6_30

asmlinkage long twnotify_sys_pwritev(unsigned long fd, const struct iovec __user *vec,
                                    unsigned long vlen, unsigned long pos_l, unsigned long pos_h)
{
    long ret = original_sys_pwritev( fd, vec, vlen, pos_l, pos_h );
    if( (ret > 0) && !bypass_mode )
    {
        int bReport = twnotify_need_write_report( "pwritev", fd);
        if( bReport )
        {
            struct twnotify* ntf = twnotify_prep_event_1fd( "pwritev", TWNOTIFY_WRITE, fd);
            if( ntf)
            {
                ntf->write_length = ret;
                twnotify_fire_event(ntf);
            }
        }
    }
    return ret;
}

#endif


/*****************************************************************************
*
* TWNOTIFY_CHMOD
*
*****************************************************************************/



/*****************************************************************************
*
* FUNCTION: twnotify_sys_chmod( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_chmod( const char USERPTR *filename, mode_t mode)
{
    long ret = 0;
/*
    unsigned long * lptr = original_sys_chmod;
    unsigned long * lptr32 = original32_sys_chmod;
    printk( "64-bit orig:   lptr=%p lptr[0]=%p lptr[1]=%p lptr[2]=%p\n", lptr, lptr[0], lptr[1], lptr[2] );
    printk( "32-bit orig:   lptr=%p lptr[0]=%p lptr[1]=%p lptr[2]=%p\n", lptr32, lptr32[0], lptr32[1], lptr32[2] );
*/

    // call original
    ret = original_sys_chmod( filename, mode );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "chmod", TWNOTIFY_CHMOD, AT_FDCWD, filename);
        if( ntf)
        {
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_fchmod( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fchmod( int fd, mode_t mode)
{
    long ret = original_sys_fchmod( fd, mode );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "fchmod", TWNOTIFY_CHMOD, fd);
        if( ntf)
        {
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_fchmodat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fchmodat( int dfd, const char USERPTR *pathname, mode_t mode, int flags)
{
    long ret = original_sys_fchmodat( dfd, pathname, mode, flags );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = NULL;
        if( flags & AT_SYMLINK_NOFOLLOW )
        {
            ntf = twnotify_prep_event_l1file( "fchmodat", TWNOTIFY_CHMOD, dfd, pathname);
        }
        else
        {
            ntf = twnotify_prep_event_1file( "fchmodat", TWNOTIFY_CHMOD, dfd, pathname);
        }
        if( ntf)
        {
            ntf->mode = mode;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}



/*****************************************************************************
*
* TWNOTIFY_CHOWN
*
*****************************************************************************/




/*****************************************************************************
*
* FUNCTION: twnotify_sys_chown( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_chown( const char USERPTR *path, uid_t owner, gid_t group)
{
    long ret = original_sys_chown( path, owner, group );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "chown", TWNOTIFY_CHOWN, AT_FDCWD, path);
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_chown32( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_chown32( const char USERPTR *path, uid_t owner, gid_t group)
{
    long ret = original_sys_chown32( path, owner, group );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "chown32", TWNOTIFY_CHOWN, AT_FDCWD, path);
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_fchown( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fchown( int fd, int owner, int group)
{
    long ret = original_sys_fchown( fd, owner, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "fchown", TWNOTIFY_CHOWN, fd);
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;

}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_fchown32( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fchown32( int fd, int owner, int group)
{
    long ret = original_sys_fchown32( fd, owner, group);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "fchown32", TWNOTIFY_CHOWN, fd);
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;

}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_fchownat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fchownat( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags)
{
    long ret = original_sys_fchownat( dfd, pathname, owner, group, flags);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = NULL;
        if( flags & AT_SYMLINK_NOFOLLOW )
        {
            ntf = twnotify_prep_event_l1file( "fchownat", TWNOTIFY_CHOWN, dfd, pathname);
        }
        else
        {
            ntf = twnotify_prep_event_1file( "fchownat", TWNOTIFY_CHOWN, dfd, pathname);
        }
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_lchown( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_lchown( const char USERPTR *path, uid_t owner, gid_t group)
{
    long ret = original_sys_lchown( path, owner, group );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_l1file( "lchown", TWNOTIFY_CHOWN, AT_FDCWD, path);
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_lchown32( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_lchown32( const char USERPTR *path, uid_t owner, gid_t group)
{
    long ret = original_sys_lchown32( path, owner, group );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_l1file( "lchown32", TWNOTIFY_CHOWN, AT_FDCWD, path);
        if( ntf)
        {
            ntf->owner = owner;
            ntf->group = group;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}




/*****************************************************************************
*
* TWNOTIFY_TIMES
*
*****************************************************************************/



/*****************************************************************************
*
* FUNCTION: twnotify_sys_futimesat( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_futimesat( int dfd, const char USERPTR *pathname, const struct timeval times[2])
{
    long ret = original_sys_futimesat( dfd, pathname, times );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "futimesat", TWNOTIFY_TIMES, dfd, pathname);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_utime( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_utime(const char USERPTR *filename, const struct utimbuf USERPTR *buf)
{
    long ret = original_sys_utime( filename, buf );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "utime", TWNOTIFY_TIMES, AT_FDCWD, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_utimes( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_utimes(const char USERPTR *filename, const struct timeval times[2])
{
    long ret = original_sys_utimes( filename, times );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "utimes", TWNOTIFY_TIMES, AT_FDCWD, filename);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify_sys_utimensat( )
*
*****************************************************************************/

#ifdef KERNEL_GT_2_6_24 // only on later kernels

asmlinkage long twnotify_sys_utimensat(int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags)
{
    long ret = original_sys_utimensat( dfd, filename, utimes, flags );

    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = NULL;
        if( flags & AT_SYMLINK_NOFOLLOW)
        {
            ntf = twnotify_prep_event_l1file( "utimensat", TWNOTIFY_TIMES, dfd, filename);
        }
        else
        {
            ntf = twnotify_prep_event_1file( "utimensat", TWNOTIFY_TIMES, dfd, filename);
        }
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}
#endif


/*****************************************************************************
*
* TWNOTIFY_XATTR
*
*****************************************************************************/



/*****************************************************************************
*
* FUNCTION: twnotify_sys_fremovexattr( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fremovexattr( int fd, const char USERPTR *name)
{
    struct twnotify *ntf;
    long ret;

    ret = original_sys_fremovexattr( fd, name );

    if (ret==0 && !bypass_mode)
    {
        int size;
        int len;
        char *kname;
        int copyret;
        char *full = twnotify_get_fd_filename( "fremovexattr", fd);

        // copy the xattr name from user space NOTE: strlen_user returns length that includes the null
        len = strnlen_user(name,PATH_MAX);
        kname = kmalloc(len, GFP_ATOMIC);
        copyret =  copy_from_user( kname, name, len );
        if( copyret )
        {
            // unable to copy something:
            kfree( kname );
            kname = NULL;
        }

        if ( full && !is_excluded(current->tgid, full))
        {
            ntf = twnotify_alloc_event( 0, full, kname, NULL, &size );

            ntf->type = TWNOTIFY_XATTRCHANGE;

            twnotify_fire_event(ntf);
        }
        if( full )
        {
            kfree(full);
            full = NULL;
        }
        if( kname )
        {
            kfree(kname);
            kname = NULL;
        }
    }

    return ret;

}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_fsetxattr( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_fsetxattr(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    struct twnotify *ntf;
    long ret;
    ret = original_sys_fsetxattr( fd, name, value, size, flags );


    if (ret==0 && !bypass_mode)
    {
        int size;
        int len;
        char *kname;
        int copyret;
        char *full = twnotify_get_fd_filename( "fsetxattr", fd);

        // copy the xattr name from user space NOTE: strlen_user returns length that includes the null
        len = strnlen_user(name,PATH_MAX);
        kname = kmalloc(len, GFP_ATOMIC);
        copyret =  copy_from_user( kname, name, len );
        if( copyret )
        {
            // unable to copy something:
            kfree( kname );
            kname = NULL;
        }

        if ( full && !is_excluded(current->tgid, full))
        {
            ntf = twnotify_alloc_event( 0, full, kname, NULL, &size );

            ntf->type = TWNOTIFY_XATTRCHANGE;

            twnotify_fire_event(ntf);
        }
        if( full )
        {
            kfree(full);
            full = NULL;
        }
        if( kname )
        {
            kfree(kname);
            kname = NULL;
        }
    }
    return ret;

}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_lremovexattr( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_lremovexattr(const char USERPTR *path, const char USERPTR *name)
{
    struct twnotify *ntf;
    long ret;

    ret = original_sys_lremovexattr(path, name );

    if (ret==0 && !bypass_mode)
    {
        int size;
        int len;
        char *kname;
        int copyret;
        char *full = twnotify_getfilename2( "lremovexattr", AT_FDCWD, path, 0, 1);

        // copy the xattr name from user space NOTE: strlen_user returns length that includes the null
        len = strnlen_user(name,PATH_MAX);
        kname = kmalloc(len, GFP_ATOMIC);
        copyret =  copy_from_user( kname, name, len );
        if( copyret )
        {
            // unable to copy something:
            kfree( kname );
            kname = NULL;
        }

        if ( full && !is_excluded(current->tgid, full))
        {
            ntf = twnotify_alloc_event( 0, full, kname, NULL, &size );

            ntf->type = TWNOTIFY_XATTRCHANGE;

            twnotify_fire_event(ntf);
        }
        if( full )
        {
            kfree(full);
            full = NULL;
        }
        if( kname )
        {
            kfree(kname);
            kname = NULL;
        }
    }

    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_lsetexattr( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_lsetxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    struct twnotify *ntf;
    long ret;
    ret = original_sys_lsetxattr( path, name, value, size, flags);

    if (ret==0 && !bypass_mode)
    {
        int size;
        int len;
        char *kname;
        int copyret;
        char *full = twnotify_getfilename2( "lsetxattr", AT_FDCWD, path, 0, 1);

        // copy the xattr name from user space NOTE: strlen_user returns length that includes the null
        len = strnlen_user(name,PATH_MAX);
        kname = kmalloc(len, GFP_ATOMIC);
        copyret =  copy_from_user( kname, name, len );
        if( copyret )
        {
            // unable to copy something:
            kfree( kname );
            kname = NULL;
        }

        if ( full && !is_excluded(current->tgid, full))
        {
            ntf = twnotify_alloc_event( 0, full, kname, NULL, &size );

            ntf->type = TWNOTIFY_XATTRCHANGE;

            twnotify_fire_event(ntf);
        }
        if( full )
        {
            kfree(full);
            full = NULL;
        }
        if( kname )
        {
            kfree(kname);
            kname = NULL;
        }
    }

    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify_sys_removexattr( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_removexattr(const char USERPTR *path, const char USERPTR *name)
{
    struct twnotify *ntf;
    long ret;

    ret = original_sys_removexattr( path, name );

    if (ret==0 && !bypass_mode)
    {
        int size;
        int len;
        char *kname;
        int copyret;
        char *full = twnotify_getfilename2( "removexattr", AT_FDCWD, path, 0, 0);

        // copy the xattr name from user space NOTE: strlen_user returns length that includes the null
        len = strnlen_user(name,PATH_MAX);
        kname = kmalloc(len, GFP_ATOMIC);
        copyret =  copy_from_user( kname, name, len );
        if( copyret )
        {
            // unable to copy something:
            kfree( kname );
            kname = NULL;
        }

        if ( full && !is_excluded(current->tgid, full))
        {
            ntf = twnotify_alloc_event( 0, full, kname, NULL, &size );

            ntf->type = TWNOTIFY_XATTRCHANGE;

            twnotify_fire_event(ntf);
        }
        if( full )
        {
            kfree(full);
            full = NULL;
        }
        if( kname )
        {
            kfree(kname);
            kname = NULL;
        }
    }

    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_setxattr( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_setxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    struct twnotify *ntf;
    long ret;
    ret = original_sys_setxattr( path, name, value, size, flags);

    if (ret==0 && !bypass_mode)
    {
        int size;
        int len;
        char *kname;
        int copyret;
        char *full = twnotify_getfilename2( "setxattr", AT_FDCWD, path, 0, 0);

        // copy the xattr name from user space NOTE: strlen_user returns length that includes the null
        len = strnlen_user(name,PATH_MAX);
        kname = kmalloc(len, GFP_ATOMIC);
        copyret =  copy_from_user( kname, name, len );
        if( copyret )
        {
            // unable to copy something:
            kfree( kname );
            kname = NULL;
        }

        if ( full && !is_excluded(current->tgid, full))
        {
            ntf = twnotify_alloc_event( 0, full, kname, NULL, &size );

            ntf->type = TWNOTIFY_XATTRCHANGE;

            twnotify_fire_event(ntf);
        }
        if( full )
        {
            kfree(full);
            full = NULL;
        }
        if( kname )
        {
            kfree(kname);
            kname = NULL;
        }
    }

    return ret;
}




/*****************************************************************************
*
* TWNOTIFY_TRUNCATE
*
*****************************************************************************/




/*****************************************************************************
*
* FUNCTION: twnotify_sys_ftruncate( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_ftruncate( int fd, unsigned long length)
{
    long ret = original_sys_ftruncate( fd, length );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "ftruncate", TWNOTIFY_TRUNCATE, fd);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_ftruncate64( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_ftruncate64( int fd, loff_t length)
{
    long ret = original_sys_ftruncate64( fd, length);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1fd( "ftruncate64", TWNOTIFY_TRUNCATE, fd);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_truncate( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_truncate( const char USERPTR *path, unsigned long length)
{
    long ret = original_sys_truncate( path, length );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "truncate", TWNOTIFY_TRUNCATE, AT_FDCWD, path);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_truncate64( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_truncate64( const char USERPTR *path, loff_t length)
{
    long ret = original_sys_truncate64( path, length );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "truncate64", TWNOTIFY_TRUNCATE, AT_FDCWD, path);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}




/*****************************************************************************
*
* TWNOTIFY_MOUNT
*
*****************************************************************************/




/*****************************************************************************
*
* FUNCTION: twnotify_sys_mount( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_mount( const char USERPTR *source, const char USERPTR *target,
                                    const char USERPTR *filesystemtype,
                                    unsigned long mountflags, const void USERPTR *data)
{
    long ret = original_sys_mount( source, target, filesystemtype, mountflags, data);
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_2files( "mount", TWNOTIFY_MOUNT, AT_FDCWD, source, AT_FDCWD, target);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}




/*****************************************************************************
*
* TWNOTIFY_UNMOUNT
*
*****************************************************************************/




/*****************************************************************************
*
* FUNCTION: twnotify_sys_umount( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_umount(const char USERPTR *target)
{
    long ret = original_sys_umount( target );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "umount", TWNOTIFY_UNMOUNT, AT_FDCWD, target);
        if( ntf)
        {
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* FUNCTION: twnotify_sys_umount2( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_umount2(const char USERPTR *target, int flags)
{
    long ret = original_sys_umount2( target, flags );
    if( (ret == 0) && !bypass_mode )
    {
        struct twnotify* ntf = twnotify_prep_event_1file( "umount2", TWNOTIFY_UNMOUNT, AT_FDCWD, target);
        if( ntf)
        {
            ntf->flags = flags;
            twnotify_fire_event(ntf);
        }
    }
    return ret;
}


/*****************************************************************************
*
* HOUSEKEEPING
*
*****************************************************************************/

/*****************************************************************************
*
* FUNCTION: twnotify_sys_close( )
*
*****************************************************************************/

asmlinkage long twnotify_sys_close(unsigned int fd)
{
    // Here is where we would drop the tracking context for this file descriptor
    long ret = 0;

    // We no longer do any processing on close.  This was a decision to try to reduce
    //  overhead on massivily parallel systems whose "innocent bystanders" were suffering
    //  the overhead of having to look through the cache only to not end up doing anything,
    //  Now, the cache aging that has always been there will just take care of creating
    //  open slots in the cache rather than explcitly removing them here at close() time.

    // Latest breaking news...DO NOT empty this function, even though the following
    //  code looks like it's not doing anything.  We discovered a problem with the PPC
    //  RHEL compiler which was optimizing the trampoline for this handler, causing a
    //  kernel crash.  This code defeats the tail-call optimization in the trampoline
    //  code and ensures the trampoline epilog is honored.


    if( !bypass_mode )
    {
        // call the original close last, when we're done processing anything needing this handle:
        ret = original_sys_close( fd );
    }
    else
    {
        // call the original close last, when we're done processing anything needing this handle:
        ret = original_sys_close( fd );
    }

    return ret;
}





/*****************************************************************************
*
* EXTRA Power PC Architecture handler helpers
*
*****************************************************************************/

#ifdef __powerpc64__

/*

noinline void setup_chmod_funcdesc( unsigned long kernel_r2 )
{
    // setup the kernel's TOC address in the handler's function descriptor
    // grab the address of the function descriptor
    unsigned long * fptr = (unsigned long *)original_sys_chmod;
    // increment [1] to locate the TOC address in our hookent struct
    // stash the kernel's r2 value there for the function descriptor
    fptr[1] = kernel_r2;

    // call our actual handler
    printk( "setup_chmod_funcdesc: kernel_r2=%p\n", kernel_r2 );
    printk( "setup_chmod_funcdesc: Hello. original_sys_chmod=%p \n",&original_sys_chmod );
}


#define PPC_FUNCDESC_SETUP_HELPER(syscall)  \

    // setup the kernel's TOC address in the handler's function descriptor
    // grab the address of the function descriptor
    void** fptr = (void**)original_sys_chmod;
    // increment to locate the TOC address in our hookent struct
    fptr += 1;
    // stash the kernel's r2 value there for the function descriptor
    *fptr = (void**)kernel_r2;


*/

// helper that will detect a condition where our assumed kernel R2 value is not correct.
//   Attempt to disable ourselves and NOT call the original function hander with the wrong one

// global instance of save r2 value:
unsigned long saved_kernel_r2 = 0;

noinline int check_kernel_r2( unsigned long kernel_r2 )
{
    if( kernel_r2 != saved_kernel_r2 )
    {
        root_err( "******************************\n" );
        root_err( "ERROR!!!! twnotify.ko driver detected inconsistent kernel R2 value - disabling...\n" );
        root_err( "******************************\n" );
        bypass_mode = 1;
        return -1;
    }
    else
    {
        return 0;
    }
}

// These macros represent the common code between all of the PPC trampolines.  These trampolines are
//  the actual handlers whose address get inserted into the syscall table for the kernel to call.  We
//  need thse because we have to fix up the RTOC value in the processor's regiters before calling the
//  handler implemenatations which are shared between Intel and PPC architectures.
#define PPC_TRAMPOLINE_PROLOG               \
    /* save R2 value:*/                     \
    unsigned long kernel_r2, txt, my_r2;    \
    long ret = 0;                           \
    kernel_r2 = getR2( );                   \
    /* set R2 to our saved R2 value:*/      \
    txt = getTextAddr( );                   \
    my_r2 = *(long*)txt;                    \
    setR2( my_r2 );                         \
    if( 0 == check_kernel_r2(kernel_r2)){


#define PPC_TRAMPOLINE_EPILOG   \
    /* restore the kernel's r2 value before returning */  \
    }                           \
    setR2( kernel_r2 );         \
    return ret;


/////////////////////////////////////////////////
// the 64 bit PPC syscall table entry trampolines
asmlinkage long twnotify_ppc_sys_creat( const char USERPTR *filename, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_creat( filename, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_open( const char USERPTR *filename, int flags, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_open( filename, flags, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_openat( int dfd, const char USERPTR *filename, int flags, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_openat( dfd, filename, flags, mode );
    PPC_TRAMPOLINE_EPILOG;
}

#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify_ppc_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_open_by_handle_at( mount_fd, handle, flags );
    PPC_TRAMPOLINE_EPILOG;
}
#endif

asmlinkage long twnotify_ppc_sys_mkdir( const char USERPTR *pathname, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mkdir( pathname, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_mkdirat( int dfd, const char USERPTR *pathname, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mkdirat( dfd, pathname, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_mknod( const char USERPTR *pathname, int mode, int dev)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mknod( pathname, mode, dev );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_mknodat( int dfd, const char USERPTR *pathname, int mode, int dev)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mknodat( dfd, pathname, mode, dev );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_link( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_link( oldpath, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_linkat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_linkat( olddfd, oldpath, newdfd, newpath, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_symlink( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_symlink( oldpath, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_symlinkat( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_symlinkat( oldpath, newdfd, newpath);
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_rmdir( const char USERPTR *pathname)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_rmdir( pathname );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_unlink( const char USERPTR *pathname)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_unlink( pathname );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_unlinkat( int dfd, const char USERPTR * pathname, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_unlinkat( dfd, pathname, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_rename( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_rename( oldpath, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_renameat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_renameat( olddfd, oldpath, newdfd, newpath);
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage ssize_t twnotify_ppc_sys_pwrite64(int fd, const void USERPTR *buf, size_t count, loff_t offset)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_pwrite64( fd, buf, count, offset );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage ssize_t twnotify_ppc_sys_write(int fd, const void *buf, size_t count)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_write( fd, buf, count );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage ssize_t twnotify_ppc_sys_writev(long fd, const struct iovec USERPTR * iov, long iovcnt)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_writev( fd, iov, iovcnt );
    PPC_TRAMPOLINE_EPILOG;
}

#ifdef KERNEL_GT_2_6_17
asmlinkage long twnotify_ppc_sys_splice(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_splice( fd_in, off_in, fd_out, off_out, len, flags );
    PPC_TRAMPOLINE_EPILOG;
}
#endif

#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify_ppc_sys_pwritev(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_pwritev( fd, vec, vlen, pos_l, pos_h );
    PPC_TRAMPOLINE_EPILOG;
}
#endif


asmlinkage long twnotify_ppc_sys_truncate( const char USERPTR *path, unsigned long length)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_truncate( path, length );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_truncate64( const char USERPTR *path, loff_t length)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_truncate64( path, length );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_ftruncate( int fd, unsigned long length)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_ftruncate( fd, length );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_ftruncate64( int fd, loff_t length)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_ftruncate64( fd, length );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_chmod( const char USERPTR *filename, mode_t mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_chmod( filename, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_fchmod( int fd, mode_t mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchmod( fd, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_fchmodat( int dfd, const char USERPTR *pathname, mode_t mode, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchmodat( dfd, pathname, mode, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_chown( const char USERPTR *path, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_chown( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_chown32( const char USERPTR *path, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_chown32( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_fchown( int fd, int owner, int group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchown( fd, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_fchown32( int fd, int owner, int group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchown32( fd, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_fchownat( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchownat( dfd, pathname, owner, group, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_lchown( const char USERPTR *path, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_lchown( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_lchown32( const char USERPTR *path, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_lchown32( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_utime(const char USERPTR *filename, const struct utimbuf USERPTR *buf)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_utime( filename, buf );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_utimes(const char USERPTR *filename, const struct timeval times[2])
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_utimes( filename, times );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_futimesat( int dfd, const char USERPTR *pathname, const struct timeval times[2])
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_futimesat( dfd, pathname, times );
    PPC_TRAMPOLINE_EPILOG;
}

#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long twnotify_ppc_sys_utimensat(int dfd, char USERPTR *filename, struct timespec USERPTR *utimes, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_utimensat( dfd, filename, utimes, flags );
    PPC_TRAMPOLINE_EPILOG;
}
#endif

asmlinkage long twnotify_ppc_sys_fremovexattr( int fd, const char USERPTR *name)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fremovexattr( fd, name );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_fsetxattr(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fsetxattr( fd, name, value, size, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_lremovexattr(const char USERPTR *path, const char USERPTR *name)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_lremovexattr( path, name );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_lsetxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_lsetxattr( path, name, value, size, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_removexattr(const char USERPTR *path, const char USERPTR *name)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_removexattr( path, name );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_setxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_setxattr( path, name, value, size, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_mount( const char USERPTR *source, const char USERPTR *target,
                                    const char USERPTR *filesystemtype,
                                    unsigned long mountflags, const void USERPTR *data)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mount( source, target, filesystemtype, mountflags, data );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_umount(const char USERPTR *target)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_umount( target );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_umount2(const char USERPTR *target, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_umount2( target, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify_ppc_sys_close(unsigned int fd)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_close( fd );
    PPC_TRAMPOLINE_EPILOG;
}

//////////////////////////////////////////////////////////////////////////////////
// and the 32-bit PPC syscall table entry trampolines .
asmlinkage long twnotify32_ppc_sys_creat( const char USERPTR *filename, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_creat( filename, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_open( const char USERPTR *filename, int flags, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_open( filename, flags, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_openat( unsigned int dfd, const char USERPTR *filename, int flags, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_openat( dfd, filename, flags, mode );
    PPC_TRAMPOLINE_EPILOG;
}

#ifdef KERNEL_GT_2_6_39
asmlinkage long twnotify32_ppc_sys_open_by_handle_at(int mount_fd, struct file_handle *handle, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_open_by_handle_at( mount_fd, handle, flags );
    PPC_TRAMPOLINE_EPILOG;
}
#endif

asmlinkage long twnotify32_ppc_sys_mkdir( const char USERPTR *pathname, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mkdir( pathname, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_mkdirat( int dfd, const char USERPTR *pathname, int mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mkdirat( dfd, pathname, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_mknod( const char USERPTR *pathname, int mode, int dev)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mknod( pathname, mode, dev );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_mknodat( int dfd, const char USERPTR *pathname, int mode, int dev)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_mknodat( dfd, pathname, mode, dev );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_link( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_link( oldpath, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_linkat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_linkat( olddfd, oldpath, newdfd, newpath, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_symlink( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_symlink( oldpath, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_symlinkat( const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_symlinkat( oldpath, newdfd, newpath);
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_rmdir( const char USERPTR *pathname)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_rmdir( pathname );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_unlink( const char USERPTR *pathname)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_unlink( pathname );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_unlinkat( int dfd, const char USERPTR * pathname, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_unlinkat( dfd, pathname, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_rename( const char USERPTR *oldpath, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_rename( oldpath, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_renameat( int olddfd, const char USERPTR *oldpath, int newdfd, const char USERPTR *newpath)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_renameat( olddfd, oldpath, newdfd, newpath );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage ssize_t twnotify32_ppc_sys_pwrite64( int fd, void USERPTR *buf, u32 count, u32 poslo, u32 poshi)  // size_t count, loff_t offset);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_pwrite64( fd, buf, count, poslo, poshi );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage ssize_t twnotify32_ppc_sys_write(int fd, const void *buf, size_t count)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_write( fd, buf, count );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage ssize_t twnotify32_ppc_sys_writev( unsigned long fd, const struct compat_iovec USERPTR *vec, unsigned long vlen) //(long fd, const struct iovec USERPTR * iov, long iovcnt);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_writev( fd, vec, vlen );
    PPC_TRAMPOLINE_EPILOG;
}
#ifdef KERNEL_GT_2_6_17
asmlinkage long twnotify32_ppc_sys_splice(int fd_in, loff_t __user *off_in, int fd_out, loff_t __user *off_out, size_t len, unsigned int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_splice( fd_in, off_in, fd_out, off_out, len, flags );
    PPC_TRAMPOLINE_EPILOG;
}
#endif

#ifdef KERNEL_GT_2_6_30
asmlinkage long twnotify32_ppc_sys_pwritev(unsigned long fd, const struct iovec __user *vec, unsigned long vlen, unsigned long pos_l, unsigned long pos_h)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_pwritev( fd, vec, vlen, pos_l, pos_h );
    PPC_TRAMPOLINE_EPILOG;
}
#endif


asmlinkage long twnotify32_ppc_sys_truncate( const char USERPTR *path, unsigned long length)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_truncate( path, length );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_truncate64(char USERPTR * filename, unsigned long offset_low, unsigned long offset_high) //( const char USERPTR *path, loff_t length);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_truncate64( filename, offset_low, offset_high );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_ftruncate( int fd, unsigned long length)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_ftruncate( fd, length );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_ftruncate64(unsigned int fd, unsigned long offset_low, unsigned long offset_high) // ( int fd, loff_t length);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_ftruncate64( fd, offset_low, offset_high );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_chmod( const char USERPTR *filename, mode_t mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_chmod( filename, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_fchmod( int fd, mode_t mode)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchmod( fd, mode );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_fchmodat( int dfd, const char USERPTR *pathname, mode_t mode, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchmodat( dfd, pathname, mode, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_chown(const char USERPTR * filename, old_uid_t user, old_gid_t group) // ( const char USERPTR *path, uid_t owner, gid_t group);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_chown( filename, user, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_chown32( const char USERPTR *path, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_chown32( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_fchown(unsigned int fd, old_uid_t user, old_gid_t group) // ( int fd, int owner, int group);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_fchown( fd, user, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_fchown32( int fd, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_fchown32( fd, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_fchownat( int dfd, const char USERPTR *pathname, uid_t owner, gid_t group, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fchownat( dfd, pathname, owner, group, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_lchown( const char USERPTR *path, old_uid_t owner, old_gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_lchown( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_lchown32( const char USERPTR *path, uid_t owner, gid_t group)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_lchown32( path, owner, group );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_utime( char USERPTR *filename, struct compat_utimbuf USERPTR *buf)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_utime( filename, buf );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_utimes( char USERPTR *filename, struct compat_timeval USERPTR *t)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_utimes( filename, t );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_futimesat(unsigned int dfd, char USERPTR *filename, struct compat_timeval USERPTR *t) //( int dfd, const char USERPTR *pathname, const struct timeval times[2]);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_futimesat( dfd, filename, t );
    PPC_TRAMPOLINE_EPILOG;
}

#ifdef KERNEL_GT_2_6_24 // only on later kernels
asmlinkage long twnotify32_ppc_sys_utimensat(int dfd, char USERPTR *filename, struct compat_timespec USERPTR *utimes, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_utimensat( dfd, filename, utimes, flags );
    PPC_TRAMPOLINE_EPILOG;
}
#endif

asmlinkage long twnotify32_ppc_sys_fremovexattr( int fd, const char USERPTR *name)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fremovexattr( fd, name );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_fsetxattr(int fd, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_fsetxattr( fd, name, value, size, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_lremovexattr(const char USERPTR *path, const char USERPTR *name)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_lremovexattr( path, name );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_lsetxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_lsetxattr( path, name, value, size, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_removexattr(const char USERPTR *path, const char USERPTR *name)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_removexattr( path, name );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_setxattr(const char USERPTR *path, const char USERPTR *name, const void USERPTR *value, size_t size, int flags)
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_setxattr( path, name, value, size, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_mount(char USERPTR * dev_name, char USERPTR * dir_name, char USERPTR * type,
                                         unsigned long flags, void USERPTR * data) // ( const char USERPTR *source, const char USERPTR *target, const char USERPTR *filesystemtype, unsigned long mountflags, const void USERPTR *data);
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_mount( dev_name, dir_name, type, flags, data );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_umount( char USERPTR *target )
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_umount( target );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_umount2( char USERPTR *target, int flags )
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify32_sys_umount2( target, flags );
    PPC_TRAMPOLINE_EPILOG;
}

asmlinkage long twnotify32_ppc_sys_close( unsigned int fd )
{
    PPC_TRAMPOLINE_PROLOG;
    ret = twnotify_sys_close( fd );
    PPC_TRAMPOLINE_EPILOG;
}



#endif // __powerpc64__

