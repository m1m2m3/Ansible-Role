/*
 * Tripwire realtime notification module
 *
 * Copyright (C) 2008-2011 Tripwire, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not,
 * write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */


#include <linux/module.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/interrupt.h>
#include <linux/sched.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/string.h>
#include <linux/types.h>
#include <linux/slab.h>
#include "twnotify.h"

#define DEVICE_MAJOR 32
#define DEVICE_NAME "twnotify"

#undef MY_NAME
#define MY_NAME "twnotify_user"

// our other includes:
#include "twnotify_main.h"
#include "twnotify_utils.h"
#include "twnotify_user.h"


DECLARE_WAIT_QUEUE_HEAD(twnotify_wait);


#define QSEQUENCE_START 1000


/////////////////////////////////////////////////////////
// Begin items protected by "qprotect"
struct twnotify_queue
{
    struct twnotify_queue *next;
    struct twnotify *data;
    int size;
} *qhead, *qtail, *readhead;

int qsize;
int readqsize;

// max size of qlimit (currently 100K in tesvc)
#define MAX_QLIMIT_SIZE 250000

int qlimit = 0;         // see last_qlimit init below
int qsequence = QSEQUENCE_START;
DEFINE_SPINLOCK(qprotect);
// end items protected by "qprotect"
/////////////////////////////////////////////////////////

DEFINE_SPINLOCK(ioctl_protect);

// remember the last queue size for releasing bypass
int last_qlimit = 0;    // see qlimit init above

// flag to tell reads to finish with 0 lth
static int finish_read = 0;


// local exclude struct

struct twnotify_exclude
{
    struct twnotify_exclude *next;
    enum exclude_type { EXCLUDE_PID, EXCLUDE_PATH } type;
    union {
        long pid;
        char path[1];
    } x;
} *ehead, *etail;

// lock to protect exclude queue
rwlock_t eprotect;

// count of exclude list length
int excludeCount = 0;
#define MAX_EXCLUDE_COUNT 1000

// Sane values for max qlimit size



/*****************************************************************************
*
* FUNCTION: twnotify_open( )
*
*****************************************************************************/
// open function - called when the "file" /dev/twnotify is opened in userspace

int twnotify_open (struct inode *inode, struct file *file)
{
    root_dbg("opened from %d\n", current->tgid);
    // we could do some checking on the flags supplied by "open"
    // i.e. O_NONBLOCK
    // -> set some flag to disable interruptible_sleep_on in twnotify_read
    return 0;
}


/*****************************************************************************
*
* FUNCTION: twnotify_release( )
*
*****************************************************************************/
// close function - called when the "file" /dev/twnotify is closed in userspace

int twnotify_release (struct inode *inode, struct file *file)
{
    root_dbg("closed from %d\n", current->tgid);
    return 0;
}

/*****************************************************************************
*
* FUNCTION: twnotify_read( )
*
*****************************************************************************/
// read function called when from /dev/twnotify is read

ssize_t twnotify_read (struct file *file, char *buf,
        size_t count, loff_t *ppos)
{
    int total = 0;
    struct twnotify_queue *del = NULL;

    root_spewuser("qsize: %d qhead: %p\n", qsize, qhead);

    while( 1 )
    {
        if( NULL == readhead && NULL == qhead )
        {
            // wait until the driver wakes us up, nothing to do right now...
            wait_event_interruptible(twnotify_wait, (qhead != NULL || finish_read != 0 ) );
            if( finish_read )
            {
                finish_read = 0;
                root_warn( "finish read set - aborted request\n");
                total = 0;
                break;
            }
            else if( signal_pending(current))
            {
                // just return if a signal is present
                root_warn("signal pending - aborted request\n");
                total = -EINTR;
                break;
            }
        }

        // check if we have data - if so, read it into the bufffer and return it
        if( readhead )
        {
            // read data from list copy set aside:

            // we use buf like a local... (why not count?)
            int left = count;
            int remainder;

            // copy as many items as possible to the output buffer
            while( 1)
            {
                // check for an item and that it will fit
                if( readhead != NULL &&  readhead->size <= left)
                {
                    del = readhead;
                    del->data->qsize = readqsize;
                    readhead = readhead->next;
                    --readqsize;
                }
                else
                {
                    // bail from entire loop.  We have no more items that fit
                    del = NULL;
                }
                if( del)
                {
                    // got an item and it *should* fit
                    root_spewuser( "sending back %d bytes\n", del->size);
                    remainder = copy_to_user(buf, del->data, del->size);
                    buf += del->size - remainder;
                    left -= del->size - remainder;
                    total += del->size - remainder;
                    *ppos = total;

                    // if there were bytes left over on the copy, then something bad happened
                    if (remainder != 0)
                    {
                        root_err("copy_to_user didn't copy all data!\n");
                    }
                    kfree(del->data);
                    kfree(del);
                    del = NULL;
                }
                else
                {
                    // no more items to send back or not enough room
                    break;
                }
            }
            // when we get here we're done with what we can do, return the data.
            //  readhead will either be left NULL if we cleared the list, or teh new head of the data
            //  that we'll get next time.  Break out to the reaturn at the bottom.
            break;
        }

        // if we get here, then readhead is NULL so we just set readhead to qhead
        //  and clear qhead for teh driver threads to continue adding stuff
        if( qhead )
        {
            // protect the head pointer
            spin_lock(&qprotect);

            // swap pointers for the lists:
            readhead = qhead;
            readqsize = qsize;
            qhead = NULL;
            qsize = 0;

            // unlock
            spin_unlock(&qprotect);
            // fall through and loop around again
        }
    }
    // get out with results or not
    return total;
}


/*****************************************************************************
*
* FUNCTION: twnotify_set_qlimit( )
*
*****************************************************************************/

void twnotify_set_qlimit(int newsize)
{
    struct twnotify_queue *del;
    int dropped_events=0;

    // protect against max:
    if( newsize > MAX_QLIMIT_SIZE )
        newsize = MAX_QLIMIT_SIZE;

    // make sure positive, ifnore if not
    if( newsize < 0 )
        return;


    root_dbg( "Starting set qlimit=%d (was %d with %d active entries)\n", newsize, qlimit, qsize);
    // Since items can be on the queue when we set it to a smaller number
    // we need to clear off any
    // protect the queue with a spinner
    do
    {
        del = NULL;
        spin_lock(&qprotect);
        qlimit = newsize;

        // If we are over the limit
        if (qsize > qlimit)
        {
            del = qhead;
            --qsize;
            qhead = qhead->next;
            dropped_events++;
        }
        spin_unlock(&qprotect);

        // done with protection, clean up and notify
        if (del)
        {
            kfree(del->data);
            kfree(del);
        }

        
    } while (del);

    if (dropped_events)
        root_warn("dropped %d events while resizing event queue\n", dropped_events);

    root_dbg( "Done in set qlimit %d with %d active entries)\n", qlimit, qsize);
}


/*****************************************************************************
*
* FUNCTION: twnotify_exclude_path( )
*
*****************************************************************************/

int twnotify_exclude_path(int size, void *name)
{

    int len = 0;
    struct twnotify_exclude *exc = NULL;
    int ret = 0;

    // make sure we won't exceed count:
    if( excludeCount + 1 > MAX_EXCLUDE_COUNT )
    {
        return 0;
    }
    excludeCount++;


    len = strnlen_user(name, PATH_MAX);
    exc = kmalloc(sizeof(struct twnotify_exclude)+len, GFP_ATOMIC);

    ret = copy_from_user(exc->x.path, name, len);

    if (ret)
    {
        kfree(exc);
        return -EFAULT;
    }
    root_dbg( "Adding exclude path %s\n", exc->x.path);
    exc->type = EXCLUDE_PATH;
    exc->next = NULL;

    // add this to the list
    write_lock(&eprotect);
    if (ehead)
    {
        etail->next = exc;
        etail=exc;
    }
    else
    {
        ehead = etail = exc;
    }
    write_unlock(&eprotect);

    return 0;

}

/*****************************************************************************
*
* FUNCTION: twnotify_exclude_pid( )
*
*****************************************************************************/

void twnotify_exclude_pid(int pid)
{
    struct twnotify_exclude *exc = NULL;

    // make sure we won't exceed count:
    if( excludeCount + 1 > MAX_EXCLUDE_COUNT )
    {
        return;
    }
    excludeCount++;

    exc = kmalloc(sizeof(struct twnotify_exclude), GFP_ATOMIC);

    exc->x.pid = pid;
    exc->type = EXCLUDE_PID;
    exc->next = NULL;
    root_dbg( "Adding Exclude PID %lx\n", exc->x.pid);

    // add this to the list
    write_lock(&eprotect);
    if (ehead)
    {
        etail->next = exc;
        etail=exc;
    }
    else
    {
        ehead = etail = exc;
    }
    write_unlock(&eprotect);

}


/*****************************************************************************
*
* FUNCTION: twnotify_clear_all_exclusions( )
*
*****************************************************************************/

void twnotify_clear_all_exclusions (void)
{
    struct twnotify_exclude *exc,*next;

    write_lock(&eprotect);
    exc = ehead;
    ehead = etail = NULL;
    write_unlock(&eprotect);
    while (exc)
    {
        next = exc->next;
        kfree(exc);
        exc = next;
    }
    excludeCount = 0;
}

/*****************************************************************************
*
* FUNCTION: twnotify_clear_exclusions( )
*
*****************************************************************************/

void twnotify_clear_exclusions (int type)
{
    struct twnotify_exclude *exc,*last,*del;

    // This is kinda inefficient, but optimized to
    // only hold the write lock till we find an entry
    // to delete
    do
    {
        write_lock(&eprotect);
        exc = ehead;
        del = last = NULL;
        while (exc)
        {
            if (exc->type == type)
            {
                // Unlink the item
                if (last)
                {
                    last->next = exc->next;
                }
                else
                {
                    ehead = exc->next;
                }
                // correct the tail
                if (etail == exc)
                {
                    etail = last;
                }
                del = exc;
                if( excludeCount > 0 )
                    excludeCount --;
                break;
            }
            last = exc;
            exc = exc->next;
        }
        // don't hold the write lock while calling memory functions
        write_unlock(&eprotect);
        if (del)
            kfree(del);
    }
    while(del);
}


/*****************************************************************************
*
* FUNCTION: path_match( )
*
*****************************************************************************/

int path_match( const char *path, const char *pattern)
{
    while (*path && *path == *pattern) ++path,++pattern;

    // exact match
    if (*pattern == '\0' && *path == '\0')
        return 1;

    // if we ended the match on a star, then it's a good match
    if (*pattern == '*')
        return 1;

    return 0;  // no match
}


/*****************************************************************************
*
* FUNCTION: is_excluded( )
*
*****************************************************************************/

int is_excluded( long pid, const char *path)
{
    // check the exclusion list, but keep a read lock on the list so it
    // can't be modified while we are looking

    struct twnotify_exclude *cur;
    int ret = 0;

    read_lock(&eprotect);

    // walk the exclusion list looking for a match
    cur = ehead;
    while (cur && !ret)
    {
        ret = (cur->type == EXCLUDE_PATH && path_match(path, cur->x.path));
        if (!ret)
            ret = (cur->type == EXCLUDE_PID && pid == cur->x.pid);
        cur = cur->next;
    }

    read_unlock(&eprotect);
    if (ret)
    {
        root_spewuser("Excluded %s\n", path);
    }

    return ret;
}

/*****************************************************************************
*
* FUNCTION: twnotify_ioctl( )
*
*****************************************************************************/

long twnotify_ioctl( struct file *file, unsigned int cmd, unsigned long arg)
{
    int retval = 0;
    int data = 0;

    // When called from a userland process without write permission,
    // the only permitted operations are:
    //  - get version
    //  - get hooked
    if (!(file->f_mode & FMODE_WRITE) &&
        (TWNOTIFY_IOCTL_GET_VERSION != cmd &&
         TWNOTIFY_IOCTL_GET_HOOKED != cmd)) {
        return -EACCES;
    }

    spin_lock(&ioctl_protect);

    // Get arg for ioctl
    retval = copy_from_user(&data, (int *)arg, sizeof(int));
    if( retval )
    {
        root_warn( "twnotify_ioclt() COPY FROM USER FAILED retval=%d\n", (int)retval );
        spin_unlock(&ioctl_protect);
        return -EFAULT;
    }

    root_dbg( "In ioctl. cmd=%x, Data=%x\n", cmd, data);

    switch ( cmd )
    {
    case TWNOTIFY_IOCTL_SETQLIMIT:
        {

            twnotify_set_qlimit(data);
            last_qlimit = data;
        }
        break;

    case TWNOTIFY_IOCTL_SETBYPASS:
        if( data && !bypass_mode)
        {
            // coordinate setting bypass and qsequence...
            spin_lock(&qprotect);
            bypass_mode = data;
            qsequence = QSEQUENCE_START;
            spin_unlock(&qprotect);

            // This clears any entries in the queue
            // and keeps pending ones from being added
            twnotify_set_qlimit(0);
        }
        if( !data && bypass_mode)
        {
            // releasing bypass so restore the qlimit
            twnotify_set_qlimit( last_qlimit);

            // coordinate setting bypass and qsequence...
            spin_lock(&qprotect);
            bypass_mode = data;
            qsequence = QSEQUENCE_START;
            spin_unlock(&qprotect);
        }
        break;

    case TWNOTIFY_IOCTL_EXCLUDE_PID:
        twnotify_exclude_pid(data);
        break;

    case TWNOTIFY_IOCTL_EXCLUDE_PATH:
        if (data < MAX_EXCLUDE_PATH_SIZE)
        {
            retval = twnotify_exclude_path(data, (void *)(arg + sizeof(int)));
        }
        else
        {
            retval = -EINVAL;
        }
        break;

    case TWNOTIFY_IOCTL_CLEAR_EXCLUSIONS:
        twnotify_clear_all_exclusions();
        break;

    case TWNOTIFY_IOCTL_CLEAR_PID_EXCLUSIONS:
        twnotify_clear_exclusions(EXCLUDE_PID);
        break;

    case TWNOTIFY_IOCTL_CLEAR_PATH_EXCLUSIONS:
        twnotify_clear_exclusions(EXCLUDE_PATH);
        break;

    case TWNOTIFY_IOCTL_GET_VERSION:
        if (copy_to_user((void *)arg, &version, sizeof(int)))
            retval = 0;
        else
            retval = -EINVAL;
        break;

    case TWNOTIFY_IOCTL_GET_HOOKED:
        if (copy_to_user((void *)arg, &ishooked, sizeof(int)))
            retval = 0;
        else
            retval = -EINVAL;
        break;

    case TWNOTIFY_IOCTL_SET_HOOK_ADDR:
        // TODO: try hooking at specified address
        break;

    case TWNOTIFY_IOCTL_SET_WRITE_INTERVAL:
        write_interval = msecs_to_jiffies( data);
        break;

    case TWNOTIFY_IOCTL_FINISH_READ:
        root_dbg( "   waking the waiter\n");
        finish_read = data;
        wake_up_interruptible( &twnotify_wait);
        root_dbg( "   woke the waiter\n");
        break;


    default:
        retval = -EINVAL;
    }

    spin_unlock(&ioctl_protect);

    root_dbg("ioctl done, returning %d\n", retval);
    return retval;
}

/*****************************************************************************
*
* FUNCTION: twnotify_fire_event( )
*
*****************************************************************************/

void twnotify_fire_event(struct twnotify *xd)
{
    struct twnotify_queue *del = NULL;
    int needWakeup = 0;
    int dropped_events = 0;
    struct twnotify_queue *x = kmalloc(sizeof(struct twnotify_queue), GFP_ATOMIC);

    // fill in struct
    x->next = NULL;
    x->data = xd;
    x->size = xd->size;

    root_spewuser( "firing event %lx:%d (size %d)\n", (long)x, xd->type, x->size);

    // protect the queue with a spinner
    spin_lock(&qprotect);

    // fill in event sequence number:
    x->data->sequence = qsequence++;

    // if the limit is zero, then we are in "bypass" mode
    //  so just nuke the entry we just made.  This
    //  is required because there is no force syncronizaiton
    //  in setting the bypass_mode flag.
    if (qlimit == 0 || bypass_mode)
    {
        del = x;
    }
    else
    {
        // if we exceeded our count, then nuke the entire
        // queue and just add the current item
        if (qsize > qlimit)
        {
            // save head for cleanup
            del = qhead;

            // nuke the queue
            qhead = NULL;
            dropped_events = qsize;
            qsize = 0;
        }

        // find where we are going to add
        if (qhead)
        {
            qtail->next = x;
            qtail=x;
        }
        else
        {
            // In this case, we are adding a new entry to a previously empty list:
            qhead = qtail = x;
            needWakeup = 1;
        }

        ++qsize;
    }
    spin_unlock(&qprotect);

    // done with protection, clean up and notify

    // here, we don't need protection (we unlinked the entire list)
    // so just walk the entries and delete them
    while( del)
    {
        struct twnotify_queue* next = del->next;
        kfree(del->data);
        kfree(del);
        del = next;
    }
 
    if (dropped_events)
      root_warn("driver queue size exceeded; dropped %d events\n", dropped_events);

    root_spewuser( "stats qsize: %d qhead: %p\n", qsize, qhead);

    if( needWakeup )
    {
        // signal read thread to grab some stuff
        wake_up_interruptible(&twnotify_wait);
    }
}


// define which file operations are supported
struct file_operations twnotify_fops =
{
    .owner  =   THIS_MODULE,
    .llseek =   NULL,
    .read   =   twnotify_read,
    .write  =   NULL,
#ifndef KERNEL_GT_3_5_0  //This breaks in Kerenel 3.12 and Kernel 4.0
    .readdir=   NULL,
#endif
    .poll   =   NULL,
    .unlocked_ioctl  =   twnotify_ioctl,
    .mmap   =   NULL,
    .open   =   twnotify_open,
    .flush  =   NULL,
    .release=   twnotify_release,
    .fsync  =   NULL,
    .fasync =   NULL,
    .lock   =   NULL,
#ifndef KERNEL_GT_2_6_24
    .readv  =   NULL,
    .writev =   NULL,
#endif // later kernel has no such
};


/*****************************************************************************
*
* FUNCTION: twnotify_init_module( )
*
*****************************************************************************/

int __init twnotify_init_module (void)
{
    int err = 0;

    root_dbg("starting... \n");

    qhead = qtail = readhead = NULL;
    qsize = readqsize = 0;

    ehead = etail = NULL;
    rwlock_init(&eprotect);

    root_dbg("  registering ... \n");
    err = register_chrdev( DEVICE_MAJOR, DEVICE_NAME, &twnotify_fops);
    if( err)
    {
        root_err( "register failed %d \n", err);
    }

    root_dbg("  done. \n");
    return err;
}


/*****************************************************************************
*
* FUNCTION: twnotify_cleanup_module( )
*
*****************************************************************************/

void twnotify_cleanup_module (void)
{
    root_dbg("starting... \n");

    bypass_mode = 1;
    twnotify_set_qlimit(0);
    twnotify_clear_all_exclusions();

    root_dbg("  unregistering ... \n");
    unregister_chrdev (DEVICE_MAJOR, DEVICE_NAME);

    root_dbg("  done. \n");
}
